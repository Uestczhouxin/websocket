<?php
$lock_file = realpath($_SERVER['PHP_SELF']).'.lock';
$lock_file_handle = fopen($lock_file, 'w');
if($lock_file_handle === false)
	die("Can not create lock file $lock_file\n");
if(!flock($lock_file_handle, LOCK_EX + LOCK_NB)){
	die(date("Y-m-d H:i:s")."Process already exists.\n");
}