<?php
/**
 * Created by PhpStorm.
 * User: songjingjing
 * Date: 2017/12/2
 */

define('ROOT_PATH', dirname(__FILE__));
$config = MobilePHPLib\Config\Configuration::getInstance();
defined('ENV') or define("ENV", $config->getEnvironment());

class ClassLoader
{
    public static function load($className)
    {
        $fileName = str_replace('\\', '/', $className) . '.php';
        $confFileName = str_replace('\\', '/' . ENV . '/', $className) . '.php';
        $filePath = ROOT_PATH . '/App/';
        if (file_exists($filePath . $confFileName)) {
            require_once $filePath . $confFileName;
        } elseif (file_exists($filePath . $fileName)) {
            require_once $filePath . $fileName;
        } elseif ($className == 'Ths_GetHqServer_Tool') {
            require_once '/var/www/phplib/Ths_GetHqServer_Tool/Ths_GetHqServer_Tool.php';
        }
    }
}

spl_autoload_register('ClassLoader::load');