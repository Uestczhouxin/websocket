<?php
/**
 * Created by PhpStorm.
 * User: winne
 * Date: 2018/7/30
 * Time: 7:28
 */

namespace Model\GameModel;

use Conf\Redis;
use Controller\WSController\MatchTable;
use Helper\Log;
use Helper\RedisHelper;

class UserData
{
    protected $userInfo;

    protected $userGameId;

    protected $connectTimeStamp;

    protected $actions;

    const USER_ACTION_BUY = 'buy';
    const USER_ACTION_SELL = 'sell';
    const USER_ACTION_PASS = 'pass';

    protected static function getFdToGameIdHashKey()
    {
        return Redis::KEY_PREFIX . 'fd_to_game_id_hash_key';
    }

    public static function getGameIdToFdHashKey()
    {
        return Redis::KEY_PREFIX . 'game_id_to_fd_hash_key';
    }

    public static function getUserDataHashKey($userGameId)
    {
        return Redis::KEY_PREFIX . 'user_data_' . $userGameId;
    }

    public function updateFdAndGameIdRelation($fd)
    {
        $redis = RedisHelper::getRedisHelperInstance();
        $redis->hSet(static::getGameIdToFdHashKey(), $this->userGameId, $fd);
        $redis->hSet(static::getFdToGameIdHashKey(), $fd, $this->userGameId);
    }

    public function __construct($userInfo, $fd)
    {
        $this->userInfo = $userInfo;
        $this->connectTimeStamp = time();
        $this->userGameId = $userInfo['userId'] . '_' . time() . rand(0, 99);
        $this->actions = [];
        $this->updateFdAndGameIdRelation($fd);
    }

    /**
     * @param $data
     * @param $server \swoole_websocket_server
     */
    public function sendToUser($data, $server)
    {
        $fd = $this->getUserFd();
        Log::setLog( 'push|' . 'userId ' . $this->userGameId . '|fd ' . $fd.'|'. json_encode($data), 'socketStream');
        if ($server->exist($fd)) {
            Log::setLog( 'push exist|'
                . 'userId ' . $this->userGameId . '|fd ' . $fd.'|'. json_encode($data), 'socketStream');
            $server->push($fd, json_encode($data));
        }
    }
    protected function getUserFd()
    {
        $redis = RedisHelper::getRedisHelperInstance();
        return $redis->hGet(static::getGameIdToFdHashKey(), $this->userGameId);
    }


    public function getUserLevel()
    {
        return $this->userInfo['level'];
    }

    public function getUserInfo()
    {
        return $this->userInfo;
    }

    public function getUserGameId()
    {
        return $this->userGameId;
    }

    public static function getUserGameIdByFd($fd)
    {
        $redis = RedisHelper::getRedisHelperInstance();
        $userGameId = $redis->hGet(static::getFdToGameIdHashKey(), $fd);
        if (empty($userGameId)) {
            return false;
        } else {
            return $userGameId;
        }
    }

    public function setReady()
    {
        $redis = RedisHelper::getRedisHelperInstance();
        $redis->hIncrBy(static::getUserDataHashKey($this->userGameId), 'is_ready', 1);
        $this->updateLastActionTime();
    }

    public function isReady()
    {
        $redis = RedisHelper::getRedisHelperInstance();
        $isReady = $redis->hGet(static::getUserDataHashKey($this->userGameId), 'is_ready');
        if (empty($isReady)) {
            return false;
        }
        return true;
    }

    public function cancelReady()
    {
        $redis = RedisHelper::getRedisHelperInstance();
        $redis->hDel(static::getUserDataHashKey($this->userGameId), 'is_ready');
    }


    /**
     * @param $action string 具体操作
     * @param $times int 第几次操作
     */
    public function setAction($action, $times)
    {
        if (!in_array($action, [static::USER_ACTION_BUY, static::USER_ACTION_SELL, static::USER_ACTION_PASS])) {
            return false;
        }

        $redis = RedisHelper::getRedisHelperInstance();
        if ($redis->hSetNx(static::getUserDataHashKey($this->userGameId), 'action_lock_' . $times, 1)) {
            $lastActionTime = $this->getLastActionTime();
            $allActions = json_decode($redis->hGet(static::getUserDataHashKey($this->userGameId), 'actions'), true);
            $allActions[$times] = ['action' => $action, 'waitTime' => time() - $lastActionTime];
            $redis->hSet(static::getUserDataHashKey($this->userGameId), 'actions', json_encode($allActions));
            $this->updateLastActionTime();
            return true;
        }
        return false;
    }

    /**
     * 某次是否已经操作过了
     * @param $times int 第几次操作
     */
    public function isOperateAction($times)
    {
        $redis = RedisHelper::getRedisHelperInstance();
        return !empty($redis->hGet(self::getUserDataHashKey($this->userGameId), 'action_lock_' . $times));
    }

    protected function updateLastActionTime()
    {
        $redis = RedisHelper::getRedisHelperInstance();
        $redis->hSet(static::getUserDataHashKey($this->userGameId), 'last_action_time', time());
    }

    protected function getLastActionTime()
    {
        $redis = RedisHelper::getRedisHelperInstance();
        $lastActionTime = $redis->hGet(static::getUserDataHashKey($this->userGameId), 'last_action_time');
        return $lastActionTime;
    }

    public function getActions($limitTimes)
    {
        $redis = RedisHelper::getRedisHelperInstance();
        $allActions = json_decode($redis->hGet(static::getUserDataHashKey($this->userGameId), 'actions'), true);
        $resultActions = [];
        foreach ($allActions as $times => $action) {
            if ($times > $limitTimes) {
                break;
            }
            $resultActions[] = $action['action'];
        }
        return $resultActions;
    }

    public function getConnectTime()
    {
        return $this->connectTimeStamp;
    }

    public function countIncomeRate($lastActionTimes, $stockPriceList)
    {
        $userActions = $this->getActions($lastActionTimes);
        $stockPriceList = array_slice($stockPriceList, -31, 31);
        $nowIncomeRate = 0;
        $lastAction = UserData::USER_ACTION_PASS;
        foreach ($userActions as $actionTimes => $userAction) {
            if ($userAction != UserData::USER_ACTION_PASS) {
                $lastAction = $userAction;
            }
            if ($lastAction == UserData::USER_ACTION_BUY) {
                $todayPrice = $stockPriceList[$actionTimes + 1][11];
                $lastDayPrice = $stockPriceList[$actionTimes][11];
                $nowIncomeRate += ($todayPrice - $lastDayPrice) / $lastDayPrice;
            }
        }
        return $nowIncomeRate;
    }

    public static function clearFdToUserGameId($fd)
    {
        $redis = RedisHelper::getRedisHelperInstance();
        /**
         * @var $redis \Redis
         */
        $redis->hDel(static::getFdToGameIdHashKey(), $fd);
    }

    public function clearUserGameIdToFd()
    {
        $redis = RedisHelper::getRedisHelperInstance();
        /**
         * @var $redis \Redis
         */
        $redis->hDel(static::getGameIdToFdHashKey(), $this->userGameId);
    }

    public function clearFromRedis()
    {
        $fd = $this->getUserFd();
        static::clearFdToUserGameId($fd);
        $this->clearUserGameIdToFd();
        $redis = RedisHelper::getRedisHelperInstance();
        $redis->hDel(MatchTable::getUserGameIdToTableIdHashKey(), $this->userGameId);
        $redis->del(static::getUserDataHashKey($this->userGameId));
        Log::setLog('user|' . $this->userGameId, 'clearLog');
    }
}