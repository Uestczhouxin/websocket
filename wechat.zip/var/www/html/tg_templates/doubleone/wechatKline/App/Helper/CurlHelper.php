<?php
/**
 *
 *
 * @user: songjingjing
 * @date: 2018/7/6
 */

namespace Helper;

use MobilePHPLib\Ths\Curl\CurlClient;
use MobilePHPLib\Ths\Curl\CurlRequest;

class CurlHelper
{
    /**
     * @var CurlClient
     */
    protected static $curlClient = null;

    public static function execute(CurlRequest $request)
    {
        self::initClient();
        return self::$curlClient->execute($request);
    }

    public static function doGet($url)
    {
        self::initClient();
        $curlRequest = new CurlRequest();
        $curlRequest->setUrl($url);
        return self::$curlClient->execute($curlRequest);
    }

    protected static function initClient()
    {
        if (self::$curlClient === null) {
            self::$curlClient = new CurlClient();
        }
    }
}