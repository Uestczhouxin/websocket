<?php
/**
 *
 *
 * @user: songjingjing
 * @date: 2018/7/16
 */

namespace Cron;

use Conf\Normal;
use Helper\FileSystem;
use Helper\OpenApiNPLUtil;
use MobilePHPLib\Config\Configuration;
use MobilePHPLib\Ths\TradeDate\TradeDateUtil;
use Model\StockPool100;
use MobilePHPLib\Service\Quote\Param\CodeList;
use MobilePHPLib\Service\Quote\Param\DataType;
use MobilePHPLib\Service\Quote\Param\DateTime;
use MobilePHPLib\Service\Quote\QuoteUtil;
use MobilePHPLib\Service\Quote\Request\BaseRequest;
use MobilePHPLib\Service\Quote\Request\CommonRequest;

class UpdateStockPool extends BaseCron
{
    /**
     * @var int 每次跑脚本最多尝试请求数量
     */
    protected $maxCountStockNum = 1000;

    protected $stockDayLimit = 100;

    public function cronHandle($argv)
    {
        $limitDateTime = strtotime('-180 days');
        $tradeDateUtil = TradeDateUtil::getInstance();

        $baseStockList = $this->getBaseStockList($limitDateTime);
        shuffle($baseStockList);
        $allDateStockPool = [];
        $newUserStockPool = [];

        foreach ($baseStockList as $index => $stockData) {
            if ($index >= $this->maxCountStockNum) {
                break;
            }
            echo ($index + 1) . "/{$this->maxCountStockNum}, stockCode:{$stockData['stockCode']}" . PHP_EOL;

            $startDateTime = rand(strtotime($stockData['dateToMarket']), $limitDateTime);
            if (!$tradeDateUtil->isSomedayTradeDay(date('Y-m-d', $startDateTime))) {
                $startDateTime = strtotime($tradeDateUtil->getNextTradeDate(date('Y-m-d', $startDateTime)));
            }
            $endDate = strtotime($tradeDateUtil->getNextTradeDate(date('Y-m-d', $startDateTime), $this->stockDayLimit));
            if ($resultData = $this->getReservationStock($startDateTime, $endDate, $stockData)) {
                $fileName = StockPool100::setCacheData($resultData);
                $allDateStockPool[] = $fileName;
            }

            if ($stockData['dateToMarket'] <= '20141121') {
                $startDateTime = rand(strtotime('20141121'), strtotime('20150401'));
                if (!$tradeDateUtil->isSomedayTradeDay(date('Y-m-d', $startDateTime))) {
                    $startDateTime = strtotime($tradeDateUtil->getNextTradeDate(date('Y-m-d', $startDateTime)));
                }
                $endDate = strtotime(
                    $tradeDateUtil->getNextTradeDate(date('Y-m-d', $startDateTime), $this->stockDayLimit)
                );
                if ($resultData = $this->getReservationStock($startDateTime, $endDate, $stockData)) {
                    $fileName = StockPool100::setCacheData($resultData);
                    $newUserStockPool[] = $fileName;
                }
            }
            usleep(500);
        }
        StockPool100::updateCacheFile($allDateStockPool, $newUserStockPool);
    }

    /**
     * 返回股票数据
     * @param $startDate int 开始时间戳
     * @param $endDate int 结束日期时间戳
     * @param $stockData array 股票信息
     * @return false|array
     */
    protected function getReservationStock($startDate, $endDate, $stockData)
    {
        $tradeDateUtil = TradeDateUtil::getInstance();
        if ($this->isSuspensionStockFilter($startDate, $endDate, $stockData)) {
            echo "filter {$stockData['stockCode']}: isSuspensionStockFilter" . PHP_EOL;
            return false;
        }
        if ($this->isOneLineStockFilter($startDate, $endDate, $stockData)) {
            echo "filter {$stockData['stockCode']}: isOneLineStockFilter" . PHP_EOL;
            return false;
        }
        $last30TradeDate = strtotime($tradeDateUtil->getPrevTradeDate(date('Y-m-d', $endDate), 30));
        if ($this->isAmplitudeFilter($last30TradeDate, $endDate, $stockData)) {
            echo "filter {$stockData['stockCode']}: isAmplitudeFilter" . PHP_EOL;
            return false;
        }
        try {
            $quoteUtil = new QuoteUtil();
            $request = new CommonRequest();
            $request->setDateTime(
                new DateTime(DateTime::DAY, date('Ymd', $startDate), date('Ymd', $endDate))
            )
                ->setCodeList(new CodeList(array($stockData['marketId'] => array($stockData['stockCode'])), false))
                ->setDataType(new DataType(DataType::CLOSE))
                ->setUrlType(BaseRequest::URL_TYPE_QUOTE)
                ->setFuquanQ();
            $result = $quoteUtil->execute($request);
            $result = $result->parseResponse();
            if (!isset($result[$stockData['stockCode']]) || count($result[$stockData['stockCode']]['data']) < 100) {
                echo "filter {$stockData['stockCode']}: isHqError" . PHP_EOL;
                return false;
            }
            if (count($result[$stockData['stockCode']]['data']) > 100) {
                $result[$stockData['stockCode']]['data'] = array_slice($result[$stockData['stockCode']]['data'], -100, 100);
            }
        } catch (\Exception $e) {
            echo "filter {$stockData['stockCode']}: Exception" . PHP_EOL;
            \Helper\Log::setErrorLog('UpdateStockPool|' . $e->getMessage());
            return false;
        }
        return [
            'stockCode' => $stockData['stockCode'],
            'stockName' => $stockData['stockName'],
            'marketId' => $stockData['marketId'],
            'startDate' => strtotime($result[$stockData['stockCode']]['data'][0]['1']),
            'endDate' => strtotime($result[$stockData['stockCode']]['data'][99]['1']),
            'price' => $result[$stockData['stockCode']]['data'],
        ];
    }

    /**
     * 时间段内是否停牌
     * @param $startDate int 开始时间戳
     * @param $endDate int 结束日期时间戳
     * @param $stockData array 股票信息
     * @return bool
     */
    protected function isSuspensionStockFilter($startDate, $endDate, $stockData)
    {
        $query = sprintf("%s %s到%s 停牌次数", $stockData['stockCode'], date('Y-m-d', $startDate), date('Y-m-d', $endDate));

        try {
            $queryResult = OpenApiNPLUtil::getData($query);
            if (1 == count($queryResult['datas']) && null == array_values($queryResult['datas'][0])[2]) {
                //查询到这只股票停牌数据只有一条,并且停牌日期字段为null, 只则这个时间段内他没有停牌, 不需要过滤
                return false;
            }
        } catch (\Exception $e) {
            \Helper\Log::setErrorLog('UpdateStockPool|' . $e->getMessage());
            return true;
        }
        return true;
    }

    /**
     * 时间段内是否连续4天1字线
     * @param $startDate
     * @param $endDate
     * @param $stockDate
     * @return bool
     */
    protected function isOneLineStockFilter($startDate, $endDate, $stockDate)
    {
        $query = sprintf('%s到%s 连续4天一字线', date('Y-m-d', $startDate), date('Y-m-d', $endDate));
        try {
            $queryResult = OpenApiNPLUtil::getData($query);
            foreach ($queryResult['datas'] as $resultData) {
                $stockCode = explode('.', array_values($resultData)[0]);
                if ($stockCode == $stockDate['stockCode']) {
                    //在连续4天一字线的列表里
                    return true;
                }
            }
        } catch (\Exception $e) {
            //todo log
            \Helper\Log::setErrorLog('UpdateStockPool|' . $e->getMessage());
            return true;
        }
        return false;
    }

    /**
     * 时间段内区间振幅低于8%
     * @param $startDate
     * @param $endDate
     * @param $stockDate
     * @return bool
     */
    protected function isAmplitudeFilter($startDate, $endDate, $stockDate)
    {
        $query = sprintf('%s %s到%s 区间振幅', $stockDate['stockCode'], date('Y-m-d', $startDate), date('Y-m-d', $endDate));
        try {
            $queryResult = OpenApiNPLUtil::getData($query);
            if (isset($queryResult['datas'][0]) && array_values($queryResult['datas'][0])[2] > 8) {
                //有区间振幅字段且区间振幅>8, 不需要过滤
                return false;
            } else {
                return true;
            }
        } catch (\Exception $e) {
            \Helper\Log::setErrorLog('UpdateStockPool|' . $e->getMessage());
            return true;
        }
    }

    /**
     * 获取基本股票代码
     * @param $startDateTime
     * @return array
     */
    protected function getBaseStockList($startDateTime)
    {
        $queryStr = date('Y年m月d日前上市股票', $startDateTime);
        $queryResult = OpenApiNPLUtil::getData($queryStr);

        $baseStockList = [];
        foreach ($queryResult['datas'] as $queryData) {
            $queryData = array_values($queryData);
            $stockCodeData = $this->formatStockCode($queryData[0]);
            $baseStockList[] = [
                'stockCode' => $stockCodeData['stockCode'],
                'marketId' => $stockCodeData['marketId'],
                'stockName' => $queryData[1],
                'dateToMarket' => ($queryData[2] > 20100105) ? $queryData[2] : 20100105,
            ];
        }
        return $baseStockList;
    }

    /**
     * 将股票代码.市场(603993.SH)格式字符串转成股票代码对应市场Id
     * @param $str
     * @return array
     */
    protected function formatStockCode($str)
    {
        $explodeData = explode('.', $str);
        return [
            'stockCode' => $explodeData[0],
            'marketId' => 'SZ' == $explodeData[1] ? '33' : '17',
        ];
    }
}
