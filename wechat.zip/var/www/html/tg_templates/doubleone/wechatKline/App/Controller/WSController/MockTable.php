<?php
/**
 *
 *
 * @user: songjingjing
 * @date: 2018/8/8
 */

namespace Controller\WSController;

use Helper\RedisHelper;
use Model\FriendList;
use Model\GameModel\MockUserData;
use Model\GameModel\UserData;
use Model\Rank;
use Model\ScoreRank;
use Model\UserInfo;

class MockTable extends MatchTable
{
    /**
     * @var MockUserData
     */
    protected $user2Data;

    /**
     * @param \Model\GameModel\UserData $user1Data
     * @param \Model\GameModel\MockUserData $user2Data
     * @param null $tableId
     */
    public static function createTable($user1Data, $user2Data, $tableId = null)
    {
        $table = new static();
        $redis = RedisHelper::getRedisHelperInstance();
        $table->tableId = (string)$redis->incr(static::getTableIncrKey());

        $table->user1Data = $user1Data;
        $table->user2Data = $user2Data;
        $table->userGameIdToPosition = [
            $user1Data->getUserGameId() => 'user1Data',
        ];
        $table->stockData = $user2Data->getStockData();
        $table->tableStatus = static::TABLE_STATUS_IN_PROGRESS;
        $redis->hSet(static::getUserGameIdToTableIdHashKey(), $table->user1Data->getUserGameId(), $table->tableId);
        $redis->hSet(static::getTableDataHashKey($table->tableId), 'table', serialize($table));
        return $table;
    }

    public function setReady($userGameId, $server)
    {
        $sendMessage = [
            'status' => 'start',
        ];
        $this->sendToAllUser($sendMessage, $server);
        $this->setAutoAction(0, 8, $server);
    }

    public function setAction($action, $times, $userGameId, $server)
    {
        $this->user1Data->setAction($action, $times);
        if ($this->user2Data->getAction($times) != UserData::USER_ACTION_PASS) {
            go(function () use ($times, $server) {
                $sleepTime = rand(0, 2);
                if ($sleepTime > 0) {
                    \co::sleep($sleepTime);
                }
                $this->updateVarFromRedis();//防止在sleep期间, 其他进程有更新table数据
                if (!$this->isSendActionAndSetNx($times)) {
                    $this->sendUserAction($server, $times);
                }
            });
        }
    }

    public function sendUserAction($server, $times)
    {
        $sendMessage = [
            'status' => 'playAction',
            'data' =>
            [
                $this->user1Data->getUserInfo()['userId'] => $this->user1Data->getActions($times),
                $this->user2Data->getUserInfo()['userId'] => $this->user2Data->getActions($times),
            ]
        ];
        $redis = RedisHelper::getRedisHelperInstance();
        $redis->hSet(static::getTableDataHashKey($this->tableId), 'lastSendTimes', $times);

        if (29 == $times) {
            $mockUserData1 = new MockUserData($this->user1Data, $this->stockData);
            MockUserData::pushMockUserList($mockUserData1);

            $this->updateTableData(['tableStatus' => static::TABLE_STATUS_FINISH]);
            $user1Id = $this->user1Data->getUserInfo()['userId'];
            $user2Id = $this->user2Data->getUserInfo()['userId'];
            $user1IncomeRate = $this->user1Data->countIncomeRate(29, $this->stockData['price']);
            $user2IncomeRate = $this->user2Data->getIncomeRate();
            Rank::updateRankScore($user1Id, $user1IncomeRate);
            if ($user1IncomeRate > $user2IncomeRate) {
                $this->gameResult = [
                    $user1Id => '1',
                    $user2Id => '2',
                ];
                $user1Score = 1;
                $user1SaveInfo = ['playNum' => 1, 'winNum' => 1];
            } else {
                $user1Score = -1;
                $user1SaveInfo = ['playNum' => 1];
                if ($user1IncomeRate < $user2IncomeRate) {
                    $this->gameResult = [
                        $user1Id => '2',
                        $user2Id => '1',
                    ];
                } else {
                    $this->gameResult = [
                        $user1Id => '0',
                        $user2Id => '0',
                    ];
                }
            }

            ScoreRank::incrByScore($user1Id, $user1Score);
            UserInfo::updateUserInfo($user1Id, $user1SaveInfo);
            $sendMessage['data']['gameResult'] = $this->gameResult;
            $this->updateTableData(['gameResult' => $this->gameResult]);
            FriendList::addFriend($user1Id, $user2Id, false);
        } else {
            $this->setAutoAction($times + 1, 5.0, $server);
        }
        $this->sendToAllUser($sendMessage, $server);
        $this->sendReconnectMessage($times, $server);
    }

    protected function setAutoAction($nextTimes, $waitTime, $server)
    {
        go(function () use ($nextTimes, $waitTime, $server) {
            \co::sleep($waitTime);
            $this->updateVarFromRedis();//防止在sleep期间, 其他进程有更新table数据
            $this->user1Data->setAction(UserData::USER_ACTION_PASS, $nextTimes);
            if (!$this->isSendActionAndSetNx($nextTimes)) {
                $this->sendUserAction($server, $nextTimes);
            }
        });
    }
    public function quit($userGameId, $server) {
        if ($this->tableStatus != static::TABLE_STATUS_IN_PROGRESS) {
            return;
        }
        $lastSendTimes = $this->getLastSendTimes();
        if ($lastSendTimes < 29) {
            for ($i = $lastSendTimes; $i <= 29; $i++) {
                $this->isSendActionAndSetNx($i);
            }
        }
        ScoreRank::incrByScore($this->user1Data->getUserInfo()['userId'], -1);
    }

    protected function sendToAllUser($data, $server)
    {
        $this->user1Data->sendToUser($data, $server);
    }

    /**
     * 清理redis中的数据
     */
    public function clearTable()
    {
        $this->user1Data->clearFromRedis();
        $redis = RedisHelper::getRedisHelperInstance();
        $redis->del(static::getTableDataHashKey($this->tableId));
    }
}
