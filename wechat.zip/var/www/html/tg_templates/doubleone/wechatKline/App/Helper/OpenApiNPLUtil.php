<?php

namespace Helper;

use MobilePHPLib\Service\OpenApi\Client;
use MobilePHPLib\Service\OpenApi\Request\NPL\DataQueryRequest;

/**
 * openApi自然语言查询接口工具
 *
 * @user: songjingjing
 * @date: 2018/3/8
 */
class OpenApiNPLUtil
{
    /**
     * 使用问句直接查询结果
     * @param $queryStr
     * @return mixed
     * @throws \Exception
     */
    public static function getData($queryStr, $domain = '')
    {
        $openApiClient = new Client();
        $openApiRequest = new DataQueryRequest();
        $openApiRequest->setParams($queryStr, $domain);
        $resultData = $openApiClient->execute($openApiRequest)->getResponseParsed();
        if (!isset($resultData['status_code']) || $resultData['status_code'] !== 0) {
            throw new \Exception(static::class . '问财数据错误, 问句: ' . $queryStr . '返回值: ' . json_encode($resultData));
        }

        return $resultData;
    }
}
