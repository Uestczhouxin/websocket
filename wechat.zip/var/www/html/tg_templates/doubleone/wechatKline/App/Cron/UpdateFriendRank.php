<?php
/**
 *
 *
 * @user: songjingjing
 * @date: 2018/8/13
 */

namespace Cron;


use Model\FriendList;

class UpdateFriendRank extends BaseCron
{
    public function cronHandle($argv)
    {

        FriendList::updateAllFriendRank();
    }
}