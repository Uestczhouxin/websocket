<?php
/**
 *
 *
 * @user: songjingjing
 * @date: 2018/7/3
 */

namespace Controller;


use Conf\WeChat;
use Helper\FieldHelper;
use Helper\Message;
use MobilePHPLib\Ths\Curl\CurlClient;
use MobilePHPLib\Ths\Curl\CurlRequest;
use Model\Rank;
use Model\ScoreRank;
use Model\UserInfo;

class IndexController2 extends BaseController
{
    public function getUserId()
    {
        $userCode = FieldHelper::getOrPost('code');
        if ($userCode === null) {
            $message = new Message(-1, 'code参数错误');
            $message->doReturn();
        }

        $curlClient = new CurlClient();
        $curlRequest = new CurlRequest();
        $url = WeChat::getJsCode2SessionUrl($userCode);
        $curlRequest->setUrl($url);
        $curlResult = $curlClient->execute($curlRequest);

        $baseUserData = $curlResult->decodeBodyByJson();
        if (isset($baseUserData['error_code']) || !isset($baseUserData['openid']) || !isset($baseUserData['session_key'])) {
            throw new \Helper\InterfaceException("getUserId接口请求{$url}报错: " . json_encode($baseUserData), 500);
        }

        $openId = $baseUserData['openid'];
        $sessionKey = $baseUserData['sessionKey'];
        $userId = UserInfo::getUserIdByOpenId($openId);
        UserInfo::updateUserInfo($userId, ['sessionKey' => $sessionKey]);

        $message = new Message(0, null, array('userId' => (string)$userId));
        $message->doReturn();
    }

    public function getRank()
    {
        $rankUserIncome = Rank::getRankUserIdList();
        $rankUserIdList = array_keys($rankUserIncome);
        $baseUserInfoList = UserInfo::getUserInfoList($rankUserIdList);

        $maxLevelWinNum = ScoreRank::getMaxLevelScore();
        $resultData = array();
        foreach ($baseUserInfoList as $baseUserInfo) {
            $resultData[] = [
                'userId' => $baseUserInfo['userId'],
                'userName' => $baseUserInfo['userName'],
                'avatar' => $baseUserInfo['avatar'],
                'incomeRate' => (string)$rankUserIncome[$baseUserInfo['userId']],
                'level' => UserInfo::getLevelByScore($baseUserInfo['winNum'], $maxLevelWinNum),
            ];
        }
        $message = new Message(0, null, $resultData);
        $message->doReturn();
    }

    public function getUserInfo() {
        $this->isLogin();
        $baseUserInfo = UserInfo::getUserInfoList([$this->userId])[0];
        $maxLevelWinNum = ScoreRank::getMaxLevelScore();
        $resultData = [
            'userId' => $baseUserInfo['userId'],
            'userName' => $baseUserInfo['userName'],
            'avatar' => $baseUserInfo['avatar'],
            'playNum' => (string)$baseUserInfo['playNum'],
            'winNum' => (string)$baseUserInfo['winNum'],
        ];

        $score =ScoreRank::getScoreByUerId($baseUserInfo['userId']);
        if ($score === false) {
            $score = 0;
        }
        $resultData['level'] = UserInfo::getLevelByScore($score, $maxLevelWinNum);

        $rankData = Rank::getRankDataByUserId($this->userId);
        if ($rankData === false) {
            $resultData['rankNum'] = '-1';
            $resultData['incomeRate'] = '0';
        } else {
            $resultData['rankNum'] = (string)$rankData['rankNum'];
            $resultData['incomeRate'] = (string)$rankData['incomeRate'];
        }

        $message = new Message(0, null, $resultData);
        $message->doReturn();
    }

    public function updateUserBaseData()
    {
        $this->isLogin();
        $userName = FieldHelper::getOrPost('userName');
        $avatar = FieldHelper::getOrPost('avatar');

        foreach (['userName', 'avatar'] as $paramName) {
           if ($$paramName === null) {
               $message = new Message(-1, $$paramName . '参数错误');
               $message->doReturn();
           }
        }

        UserInfo::updateUserInfo($this->userId, ['userName' => $userName, 'avatar' => $avatar]);

        $message = new Message(0);
        $message->doReturn();
    }

    public function sendAlphaHuaResult()
    {
        $this->isLogin();
        $data = FieldHelper::getOrPost('data', null, null, false);
        $data = json_decode($data, true);
        if (!isset($data[0][$this->userId]) || !isset($data[0]['robot'])) {
            $message = new Message(-1, 'data' . '参数错误');
            $message->doReturn();
        }
        foreach ($data as $gameResult) {
            $userIncomeRate = $gameResult[$this->userId];
            $robotIncomeRate = $gameResult['robot'];
            $saveUserInfo = [];
            if ($userIncomeRate === false) {//逃跑
                var_dump(ScoreRank::incrByScore($this->userId, -1));
            } else {
                $saveUserInfo['playNum'] = 1;
                if ($userIncomeRate > $robotIncomeRate) { //赢
                    $saveUserInfo['winNum'] = 1;
                    ScoreRank::incrByScore($this->userId, 1);
                } elseif ($userIncomeRate < $robotIncomeRate) {//输
                    ScoreRank::incrByScore($this->userId, -1);
                } else {
                    //平局 不扣分也不加胜利局数
                }
                UserInfo::updateUserInfo($this->userId, $saveUserInfo);
                Rank::updateRankScore($this->userId, $userIncomeRate);
            }
        }

        $message = new Message(0);
        $message->doReturn();
    }
}
