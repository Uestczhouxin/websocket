<?php
/**
 * 常规配置
 *
 * @user: songjingjing
 * @date: 2018/7/3
 */

namespace Conf;

class Normal
{
    const LOG_PATH = 'D:/workProject/kline_wechat/log';
    const DATA_PATH = '/tmp';
    const APP_NAME = 'wechatKline';
    const MOCK_PATH = 'D:/workProject/kline_wechat/doc/mockData';
    const ERROR_ALARM_MAILS = ['songjingjing@myhexin.com'];
}
