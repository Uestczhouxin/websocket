<?php

namespace Conf;

/**
 * 微信配置文件
 *
 * @user: songjingjing
 * @date: 2018/6/30
 */
class WeChat
{
//    private static $appId = 'wx1c4fc74e535158a6';
    private static $appId = 'wx061a72e86ef66dbc';
//    private static $appSecret = 'f8ad63e415331a6efff768f3281587b4';
    private static $appSecret = 'a33b8e7d5b36d90b2365a4242b5f378d';

    public static function getJsCode2SessionUrl($userCode)
    {
        return 'https://api.weixin.qq.com/sns/jscode2session?'
            . 'appid=' . self::$appId
            . '&secret=' . self::$appSecret
            . '&js_code=' . $userCode
            . '&grant_type=authorization_code';
    }
}