<?php
/**
 * 常规配置
 *
 * @user: songjingjing
 * @date: 2018/7/3
 */

namespace Conf;

class Normal
{
    const LOG_PATH = '/var/www/log/wechatKline';
    const DATA_PATH = '/var/www/data';
    const APP_NAME = 'wechatKline';
    const ERROR_ALARM_MAILS = ['songjingjing@myhexin.com'];
}
