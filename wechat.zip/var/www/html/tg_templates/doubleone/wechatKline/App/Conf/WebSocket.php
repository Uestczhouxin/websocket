<?php
/**
 * Created by PhpStorm.
 * UserInfo: winne
 * Date: 2018/7/2
 * Time: 1:26
 */

namespace Conf;


class WebSocket
{
    public static function getPort()
    {
        return '30000';
    }
}