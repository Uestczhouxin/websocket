<?php
/**
 * redis工具
 * UserInfo: songjingjing@myhexin.com
 * Date: 2018/7/1
 * Time: 23:11
 */

namespace Helper;

use MobilePHPLib\Ths\Redis\RedisUtil;

/**
 * Class RedisHelper
 * @package Helper
 * @method bool rename( $srcKey, $dstKey ) {} Redis方法 rename
 * @method bool expire( $key, $ttl ) {}
 * @method bool incr( $key ) {}
 * @method bool hSet( $key, $hashKey, $value ) {}
 * @method string hGet($key, $hashKey ) {}
 * @method int hIncrBy( $key, $hashKey, $value ) {}
 * @method bool hSetNx( $key, $hashKey, $value ) {}
 * @method int rPush( $key, $value1, $value2 = null, $valueN = null ) {}
 * @method string|false lPop( $key ) {}
 * @method int del( $key1, $key2 = null, $key3 = null ) {}
 * @method int hDel( $key, $hashKey1, $hashKey2 = null, $hashKeyN = null ) {}
 */
class RedisHelper extends RedisUtil
{
    protected static $redisHelper = null;

    public static function getRedisHelperInstance()
    {
        if (self::$redisHelper === null) {
            self::$redisHelper = new RedisHelper();
            self::$redisHelper->setConfig(\Conf\Redis::CONFIG);
            self::$redisHelper->connect();
        }
        return self::$redisHelper;
    }

    public function __call($name, $arguments)
    {
        try {
            return $this->callRedis($name, $arguments);
        } catch (\Exception $e) {
            $this->needReconnect = true;
            $this->connect();
            return $this->callRedis($name, $arguments);
        }
    }

    protected function callRedis($name, $arguments)
    {
        if (in_array($name, array('scan', 'hScan', 'zScan', 'hScan'))) {
            throw new \Exception('需要使用指针的方法不支持直接调用, 请使用getRedis获取到Redis基本类后调用');
        }
        if (is_callable(array($this->getRedis(), $name), true)) {
            return call_user_func_array(array($this->getRedis(), $name), $arguments);
        }

        throw new \Exception('not redis function');
    }
}