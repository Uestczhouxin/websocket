<?php
/**
 * 70天股票数据股票池, 股票池数据不再更新,只用来提供老版本客户端使用
 *
 * @user: songjingjing
 * @date: 2018/7/17
 */

namespace Model;

use Conf\Normal;
use Helper\FileSystem;

class StockPool
{
    /**
     * @var string 股票池文件缓存文件地址
     */
    protected static $stockPoolFilePath = Normal::DATA_PATH . '/stockPool.json';

    /**
     * @var null|int 加载的缓存文件更新时间
     */
    protected static $lodeCacheFileTime = null;

    /**
     * @var null|array 所有时间段股票池数据
     */
    protected static $allStockPoolData = null;

    /**
     * @var null|array 低段位用户股票池数据
     */
    protected static $newUserStockPoolData = null;


    /**
     * 根据用户等级从股票池里获取一只股票的数据
     * @param $userLevel
     * @return array
     */
    public static function getStockDataByUserLevel($userLevel)
    {
        static::loadPool();

        $stockData = null;
        if ($userLevel <= 2) {
            $index = array_rand(static::$newUserStockPoolData);
            if (isset(static::$newUserStockPoolData[$index])) {
                $stockData = static::$newUserStockPoolData[$index];
            }
        }
        if (empty($stockData)) {
            $index = array_rand(static::$allStockPoolData);
            if (isset(static::$allStockPoolData)) {
                $stockData = static::$allStockPoolData[$index];
            }
        }
        if (empty($stockData)) {
            $stockData = static::getDefaultStockData();
        }


        return $stockData;
    }

    /**
     * @return array 默认的股票配置
     */
    protected static function getDefaultStockData()
    {
        return [
            'stockCode' => '600106',
            'stockName' => '重庆路桥',
            'marketId' => '17',
            'startDate' => strtotime('20180326'),
            'endDate' => strtotime('20180706'),
        ];
    }

    /**
     * 更新缓存文件数据
     * @param $allDateStockPool
     * @param $newUserStockPool
     * @return bool
     */
    public static function updateCacheFile($allDateStockPool, $newUserStockPool)
    {
        if (empty($allDateStockPool) || empty($newUserStockPool)) {
            return false;
        }
        $cacheData = FileSystem::getContents(static::$stockPoolFilePath);
        if (!isset($cacheData['allDateStockPool'])) {
            $cacheData['allDateStockPool'] = [];
        }
        if (!isset($cacheData['newUserStockPool'])) {
            $cacheData['newUserStockPool'] = [];
        }

        array_unshift($cacheData['allDateStockPool'], $allDateStockPool);
        array_unshift($cacheData['newUserStockPool'], $newUserStockPool);

        if (count($cacheData['allDateStockPool']) >= 5) {
            array_pop($cacheData['allDateStockPool']);
        }
        if (count($cacheData['newUserStockPool']) >= 5) {
            array_pop($cacheData['newUserStockPool']);
        }

        return FileSystem::setContents(static::$stockPoolFilePath, $cacheData);
    }

    /**
     * 从缓存文件加载股票池数据
     */
    protected static function loadPool()
    {
        if (!static::needLoadPool()) {
            return;
        }

        $allCacheData = FileSystem::getContents(static::$stockPoolFilePath);
        static::$allStockPoolData = [];
        foreach ($allCacheData['allDateStockPool'] as $cacheDate) {
            static::$allStockPoolData = array_merge(static::$allStockPoolData, $cacheDate);
        }
        static::$newUserStockPoolData = [];
        foreach ($allCacheData['newUserStockPool'] as $cacheDate) {
            static::$newUserStockPoolData = array_merge(static::$newUserStockPoolData, $cacheDate);
        }

        static::$lodeCacheFileTime = FileSystem::getMTime(static::$stockPoolFilePath);
    }

    /**
     * 是否需要从缓存文件加载股票池数据
     * @return bool
     */
    protected static function needLoadPool()
    {
        if (static::$allStockPoolData === null || static::$newUserStockPoolData) {
            return true;
        }

        if (static::$lodeCacheFileTime < FileSystem::getMTime(static::$stockPoolFilePath)) {
            return true;
        }

        return false;
    }
}