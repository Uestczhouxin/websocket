<?php
namespace Controller;

use Helper\Message;
use Model\UserInfo;

/**
 * Created by PhpStorm.
 * UserInfo: winne
 * Date: 2018/7/2
 * Time: 0:44
 */
class BaseController
{
    protected $userId = null;

    protected $userTicket = null;

    /**
     * @var int 接口版本号
     */
    protected $version = 1;

    public function __construct()
    {
        if (isset($_REQUEST['userId']) && is_numeric($_REQUEST['userId'])) {
            $this->userId = $_REQUEST['userId'];
        }
        if (isset($_REQUEST['userTicket'])) {
            $this->userTicket = $_REQUEST['userTicket'];
        }
    }

    protected function isLogin($existIfError = true)
    {
        $isLogIn = true;
        if ($this->version == 2) {
            if (!UserInfo::authUser($this->userId, $this->userTicket)) {
                $isLogIn = false;
            }
        }
        if (!$isLogIn && $existIfError) {
            $message = new Message(401);
            $message->doReturn();
        }
        return $isLogIn;
    }
}