<?php
/**
 * 字段验证类（待扩展）
 *
 * UserInfo: Chen Congying <chencongying@myhexin.com>
 * Date: 2017/5/26
 * Time: 9:13
 */

namespace Helper;

class FieldHelper
{
    protected static $fields = null;
    protected static $hasJsonGot = false; // 标记是否已经获取过Json

    /**
     * 从input里获取数据
     *
     * @param string|null $default 默认值
     */
    public static function input($default = null)
    {
        if (!self::$hasJsonGot) {
            self::$fields = file_get_contents('php://input');
            if (self::$fields === false) {
                self::$fields = $default;
            }
            self::$hasJsonGot = true;
        }
        return self::$fields;
    }

    /**
     * 获取post过来的字段数据
     *
     * @param string $name    字段名 传入null或者空字符串将返回所有字段，形式为array(name => value)
     * @param string $default 默认值
     * @param bool   $isEscape 是否转义html特殊字符
     * @return null|string
     */
    public static function post($name = null, $default = null, $isEscape = true)
    {
        if ($name === '' || $name === null) {
            return $_POST;
        }
        $result = isset($_POST[$name]) ? $_POST[$name] : $default;
        if (is_string($result) && $isEscape) {
            $result = self::escape($result);
        }
        return $result;
    }

    /**
     * 获取get过来的字段数据
     *
     * @param string $name    字段名 传入null或者空字符串将返回所有字段，形式为array(name => value)
     * @param string $default 默认值
     * @param bool   $isEscape 是否转义html特殊字符
     * @return null|string
     */
    public static function get($name = null, $default = null, $isEscape = true)
    {
        if ($name === '' || $name === null) {
            return $_GET;
        }
        $result = isset($_GET[$name]) ? $_GET[$name] : $default;
        if (is_string($result) && $isEscape) {
            $result = self::escape($result);
        }
        return $result;
    }

    /**
     * 获取get和post过来的字段数据
     *
     * @param string $name    字段名 传入null或者空字符串将返回所有字段，形式为array(name => value)
     * @param string $default 默认值
     * @param array||null $enum 是否为某个枚举内容
     * @param bool   $isEscape 是否转义html特殊字符
     * @return mixed
     */
    public static function getOrPost($name = null, $default = null, $enum = null, $isEscape = true)
    {
        if ($name === '' || $name === null) {
            return $_REQUEST;
        }
        $result = isset($_REQUEST[$name]) ? $_REQUEST[$name] : $default;
        if (is_string($result) && $isEscape) {
            $result = self::escape($result);
        }
        if (is_array($enum)) {
            if (!in_array($result, $enum)) {
                $result = $default;
            }
        }
        return $result;
    }

    /**
     * 判断是否为空（）
     *
     * @param $str
     * @return bool
     */
    public static function isEmpty($str)
    {
        if (is_string($str)) {
            return !isset($str{0});
        }
        if (!is_int($str) && !is_float($str)) {
            return empty($str);
        }
        return false;
    }

    /**
     * 判断是否为url地址
     *
     * @param $url
     * @return bool
     */
    public static function isUrl($url)
    {
        $regex = '@(?i)\b((?:[a-z][\w-]+:(?:/{1,3}|[a-z0-9%])|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}/)(?:[^\s()<>]+|\(([^\s()<>]+|(\([^\s()<>]+\)))*\))+(?:\(([^\s()<>]+|(\([^\s()<>]+\)))*\)|[^\s`!()\[\]{};:\'".,<>?«»“”‘’]))@';
        // 正则判断
        if (preg_match($regex, $url)) {
            return true;
        }
        return false;
    }

    /**
     * 判断是否为整数
     *
     * @param $str
     * @return bool
     */
    public static function isInt($str)
    {
        return self::isDigits($str);
    }

    /**
     * 判断是否为数字
     *
     * @param $str
     * @return bool
     */
    public static function isNumber($str)
    {
        return is_numeric($str);
    }

    /**
     * 判断是否都为数字
     *
     * @param $str
     * @return bool
     */
    public static function isDigits($str)
    {
        if ($str === '0') {
            return true;
        }
        return ctype_digit($str);
    }

    /**
     * 防止html和js注入
     *
     * @param string $str
     * @return string
     */
    public static function escape($str)
    {
        return htmlspecialchars($str);
    }
}