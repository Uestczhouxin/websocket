<?php
/**
 *
 *
 * @user: songjingjing
 * @date: 2018/8/8
 */

namespace Model\GameModel;

use Conf\Redis;
use Helper\RedisHelper;

class MockUserData
{
    protected $userInfo;

    protected $actions;

    protected $stockData;

    protected $incomeRate;

    protected static function getMockUserListKey()
    {
        return Redis::KEY_PREFIX . 'mock_user_list';
    }
//    public function __construct($userInfo, $actions, $stockData, $incomeRate)

    /**
     * MockUserData constructor.
     * @param $userData UserData
     * @param $stockData
     */
    public function __construct($userData, $stockData)
    {
        $this->userInfo = $userData->getUserInfo();
        $this->actions = $userData->getActions(29);
        $this->stockData = $stockData;
        $this->incomeRate = $userData->countIncomeRate(29, $stockData['price']);
    }

    public function getUserInfo()
    {
        return $this->userInfo;
    }

    public function getAction($times)
    {
        return $this->actions[$times];
    }

    public function getIncomeRate()
    {
        return $this->incomeRate;
    }
    public function getStockData()
    {
        return $this->stockData;
    }

    public function getActions($limitTimes)
    {
        $resultActions = [];
        foreach ($this->actions as $times => $action) {
            if ($times > $limitTimes) {
                break;
            }
            $resultActions[] = $action;
        }
        return $resultActions;
    }

    /**
     * @param $mockUserData MockUserData
     * @param $stockData
     */
    public static function pushMockUserList(MockUserData $mockUserData)
    {
        if (!($mockUserData instanceof static)) {
            return;
        }
        $redis = RedisHelper::getRedisHelperInstance();
        $actions = $mockUserData->getActions(29);
        if (count($actions)  < 30) {
            return;
        }
        $redis->rPush(static::getMockUserListKey(), serialize($mockUserData));
    }

    /**
     * @return static|null
     */
    public static function popMockUserList()
    {
        $redis = RedisHelper::getRedisHelperInstance();
        $mockUserData = $redis->lPop(static::getMockUserListKey());
        if (!empty($mockUserData)) {
            $mockUserData = unserialize($mockUserData);
        }
        if ($mockUserData instanceof static) {
            return $mockUserData;
        } else {
            return null;
        }
    }

    public static function clearMockUserList()
    {

        $redisHelper = RedisHelper::getRedisHelperInstance();
        $redisHelper->rename(self::getMockUserListKey(), self::getMockUserListKey().'bak');
        $redisHelper->expire(self::getMockUserListKey() . 'bak', 0);
    }
}