<?php
/**
 *
 *
 * @user: songjingjing
 * @date: 2018/7/3
 */

namespace Model;

use Conf\Redis;
use Helper\RedisHelper;

class UserInfo
{
    /**
     * @var string 用来做用户验证的salt, ticket为hash(userId . salt)
     */
    private static $userAuthSalt = '10jqka@123';

    /**
     * @return string redis hash表  保存用户数据
     */
    public static function getUserInfoHashKey()
    {
        return Redis::KEY_PREFIX . 'userInfo_hash';
    }

    /**
     * @return string openid->userId hash表
     */
    public static function getOpenId2UserIdHashKey()
    {
        return Redis::KEY_PREFIX . 'openId2UserId_hash';
    }

    /**
     * 使用openId获取用户对应userId
     * 如果没有对应关系, 则获取一个自增id作为userId, 并保存
     * @param $openId
     * @return string
     */
    public static function getUserIdByOpenId($openId)
    {
        $redisUtil = RedisHelper::getRedisHelperInstance();
        /**
         * @var $redisUtil \Redis
         */
        $userId = $redisUtil->hGet(self::getOpenId2UserIdHashKey(), $openId);
        if (!is_numeric($userId)) {
            $userId = $redisUtil->hIncrBy(self::getOpenId2UserIdHashKey(), 'userIdIncrKey', 1);
            $redisUtil->hSet(self::getOpenId2UserIdHashKey(), $openId, $userId);
        }

        return (string)$userId;
    }

    public static function updateUserInfo($userId, $updateUserInfoData)
    {
        $redisUtil = RedisHelper::getRedisHelperInstance();

        /**
         * @var $redisUtil \Redis
         */
        $oldUserInfo = json_decode($redisUtil->hGet(self::getUserInfoHashKey(), $userId), true);
        if (empty($oldUserInfo)) {
            $oldUserInfo = self::getEmptyUserInfo($userId);
        }

        foreach ($updateUserInfoData as $userInfoKey => $userInfoData) {
            if (in_array($userInfoKey, ['playNum', 'winNum'])) {
                $oldUserInfo[$userInfoKey] += $userInfoData;
            } else {
                $oldUserInfo[$userInfoKey] = $userInfoData;
            }
        }
        $redisUtil->hSet(self::getUserInfoHashKey(), $userId, json_encode($oldUserInfo));
    }

    public static function getEmptyUserInfo($userId)
    {
        return [
            'userId' => $userId,
            'userName' => '',
            'avatar' => '',
            'playNum' => '0',
            'winNum' => '0',
            'sessionKey' => '',
        ];
    }

    /**
     * 通过用户胜利次数获取用户等级
     * @userScore int 用户当前分数
     * @param $maxLevelScore bool|int 最大等级需要的积分(胜利次数) 不为数字时还没出现达到最大等级的胜利次数
     * @return string 用户等级
     */
    public static function getLevelByScore($userScore, $maxLevelScore)
    {
        if ($userScore <= 5) {
            $level = 0;
        } elseif ($userScore <= 15) {
            $level = 1;
        } elseif ($userScore <= 30) {
            $level = 2;
        } elseif ($userScore <= 50) {
            $level = 3;
        } elseif ($userScore <= 80) {
            $level = 4;
        } else {
            $level = 5;
        }

//        if (is_numeric($maxLevelScore) && $userScore >= $maxLevelScore) {
//            $level = 6;
//        }

        return (string)$level;
    }

    /**
     * 批量返回用户数据
     * @param $userIdList array 需要取的用户列表
     * @return array
     */
    public static function getUserInfoList($userIdList)
    {
        $redisHelper = RedisHelper::getRedisHelperInstance();

        $resultData = array();
        /**
         * @var $redisHelper \Redis
         */
        $userInfoList = $redisHelper->hMGet(self::getUserInfoHashKey(), $userIdList);

        foreach ($userIdList as $userId) {
            if (!isset($userInfoList[$userId]) || !is_string($userInfoList[$userId])) {
                $baseUserInfo = self::getEmptyUserInfo($userId);
            } else {
                $baseUserInfo = json_decode($userInfoList[$userId], true);
            }

            $resultData[] = $baseUserInfo;
        }

        return $resultData;
    }

    /**
     * 用户认证
     * @param $userId
     * @param $userTicket
     */
    public static function authUser($userId, $userTicket)
    {
        return $userTicket == self::getUserTicket($userId);
    }

    /**
     * 获取userTicket
     * @param $userId
     * @return string
     */
    public static function getUserTicket($userId)
    {
        return md5($userId . self::$userAuthSalt);
    }
}