<?php

/**
 * 文件操作类
 *
 * UserInfo: songjingjing
 * Date: 2018/1/2
 */
namespace Helper;

class FileSystem
{

    /**
     * 获取文件内容
     * @param $path string 文件路径
     * @param bool $json 是否是json
     * @param bool $throwException
     * @return array|bool|mixed|string
     */
    public static function getContents($path, $json = true, $throwException = false)
    {
        if (file_exists($path)) {
            $contents = file_get_contents($path);
            if ($json) {
                return json_decode($contents, true);
            } else {
                return $contents;
            }
        } else {
            if ($throwException) {
                throw new \Exception($path . '');
            } else {
                return ($json) ? [] : '';
            }
        }
    }

    /**
     * @description: 数据存到文件中，会自动创建目录
     * @params: path 文件路径
     * @params: json 是否是json
     */
    /**
     * 将数据保存到文件里, 目录不存在时会自动创建目录
     * @param $path string 文件路径
     * @param $content string 内容
     * @param bool $json 是否是json
     * @return bool
     */
    public static function setContents($path, $content, $json = true)
    {
        $dir = dirname($path);
        if (!is_dir($dir)) {
            mkdir($dir);
        }

        if ($json) {
            file_put_contents($path, json_encode($content));
        } else {
            file_put_contents($path, $content);
        }

        return true;
    }

    /**
     * @description: 追加内容
     * @PS::默认不是json
     */
    public static function appendContents($path, $content)
    {
        if (file_exists($path)) {
            file_put_contents($path, $content, FILE_APPEND);
        } else {
            self::setContents($path, $content, false);
        }
    }

    /**
     * @description: 获取文件修改的时间戳
     * @params: path 文件路径
     */
    public static function getMTime($path)
    {
        if (file_exists($path)) {
            return filemtime($path);
        } else {
            return -1;
        }
    }

    public static function chOwnAndGroup($path, $owner = 'www', $group = 'www')
    {
        if (file_exists($path)) {
            chown($path, $owner);
            chgrp($path, $group);
            return true;
        } else {
            return false;
        }
    }

    /**
     * 删除指定路径的文件
     *
     * @param $path string 需要删除文件的位置
     * @return bool 删除结果
     */
    public static function unlinkFile($path)
    {
        if (!file_exists($path)) {
            return false;
        } else {
            return unlink($path);
        }
    }
}
