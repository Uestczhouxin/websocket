<?php
/**
 *
 *
 * @user: songjingjing
 * @date: 2018/7/4
 */

namespace Cron;

use Conf\Normal;
use MobilePHPLib\Ths\Curl\CurlClient;
use MobilePHPLib\Ths\Curl\CurlRequest;

class RobotDataReptile extends BaseCron
{
    protected $originalDataPath;
    protected $nickNameUrl = 'http://t.10jqka.com.cn/api.php?method=user.getNickname&userid=%s';
    protected $userAvatarUrl = 'http://u.thsi.cn/avatar/%s1000/%s.gif';

    public function __construct()
    {
        $this->originalDataPath = Normal::LOG_PATH . '/wlhOrderQuery20180703';
    }

    public function CronHandle($argv)
    {
        $originalFile = new \SplFileObject($this->originalDataPath);

        $userIdList = [];
        while ($lineStr = $originalFile->fgets()) {
            if (empty($lineStr)) {
                continue;
            }
            $userId = explode('|', $lineStr)[1];
            $userIdList[] = $userId;
        }
        $userNameList = json_decode(file_get_contents('./userName'), true);
        foreach ($userNameList as $userName) {
            echo $userName . PHP_EOL;
        }
        $this->userNameReptile($userIdList);
//        $this->avatarReptile($userIdList);
    }

    protected function avatarReptile($userIdList)
    {
        $curlClient = new CurlClient();
        $curlRequest = new CurlRequest();
        $fileMd5 = array();
        foreach ($userIdList as $userId) {
            $url = sprintf($this->userAvatarUrl, $userId, $userId);
            $curlRequest->setUrl($url);
            $curlResult = $curlClient->execute($curlRequest);
            $md5Code = md5($curlResult->getBody());
            if (in_array($md5Code, $fileMd5)) {
                continue;
            }
            $fileMd5[] = $md5Code;
            file_put_contents('./userAvatar/' . $userId . '.gif', $curlResult->getBody());
            if (count($fileMd5) > 1000) {
                break;
            }
        }
    }

    protected function userNameReptile($userIdList)
    {
        $userIdList = array_values(array_unique($userIdList));
        $curlClient = new CurlClient();
        $curlRequest = new CurlRequest();
        $userNameList = array();
        foreach ($userIdList as $userId) {
            $url = sprintf($this->nickNameUrl, $userId);
            $curlRequest->setUrl($url);
            $resultData = $curlClient->execute($curlRequest)->decodeBodyByJson();
            if ($resultData['errorCode'] !== 0 || !isset($resultData['result'])) {
                continue;
            }
            $userName = array_values($resultData['result'])[0];
            if (count(explode('*', $userName)) > 1) {
                continue;
            }
            if (count(explode('mx_', $userName)) > 1) {
                continue;
            }
            if (count(explode('mo_', $userName)) > 1) {
                continue;
            }
            if (is_numeric($userName)) {
                continue;
            }
            $userNameList[] = $userName;
            echo $userName . "\n";
            if (count($userNameList) > 500) {
                break;
            }
        }
        file_put_contents('./userName', json_encode($userNameList));
    }
}