<?php

namespace Cron\Game;

use Cron\BaseCron;
use Helper\Log;

/**
 * 给游戏数据设置过期时间
 *
 * @user: songjingjing
 * @date: 2018/8/10
 */
class ClearGameData extends BaseCron
{
    /**
     * @var int 游戏数据保留1小时
     */
    protected $gameCacheTime = 3600;

    /**
     * @var array 需要设置过期时间的key
     */
    protected $needSetTtlKeys = [];

    public function __construct()
    {
        $this->needSetTtlKeys = [
        ];
    }

    public function cronHandle($argv)
    {
        // TODO: Implement cronHandle() method.
        $redis = \Helper\RedisHelper::getRedisHelperInstance();
        $it = null;
        $gameTablePrefix = \Conf\Redis::KEY_PREFIX . 'table_data_hash';
        do {
            /**
             * @var $redis \Redis
             */
            $redisKeys = $redis->getRedis()->scan($it);
            foreach ($redisKeys as $redisKey) {
                if (strpos($redisKey, $gameTablePrefix) === 0) {
                    $this->clearTable($redisKey);
                }
            }
        } while ($it > 0);

    }

    protected function clearTable($redisKey)
    {
        $redis = \Helper\RedisHelper::getRedisHelperInstance();
        $tableStr = $redis->hGet($redisKey, 'table');
        $table = unserialize($tableStr);
        if (is_callable([get_class($table), 'needClearTable']) && is_callable([get_class($table), 'clearTable'])) {
            if ($table->needClearTable()) {
                $table->clearTable();
            }
        }
        Log::setLog('clear table |' . $redisKey, 'clearGameData.log');
    }
}