<?php
/**
 *
 *
 * @user: songjingjing
 * @date: 2018/7/3
 */

namespace Helper;

use Conf\ErrorInfo;

class Message
{
    protected $statusCode = 0;
    protected $data = null;
    protected $msg = null;



    public function __construct($statusCode = 0, $msg = null, $data = null)
    {
        $this->statusCode = $statusCode;
        $this->data = $data;
        $this->msg = $msg === null ? ErrorInfo::getMsgByCode($statusCode) : $msg;
    }

    public function doReturn($isExit = true)
    {
        $returnData = [
            'status_code' => $this->statusCode,
        ];
        if ($this->data !== null) {
            $returnData['data'] = $this->data;
        }
        if ($this->msg !== null) {
            $returnData['msg'] = $this->msg;
        }

        echo json_encode($returnData);
        if ($isExit) {
            exit;
        }
    }
}