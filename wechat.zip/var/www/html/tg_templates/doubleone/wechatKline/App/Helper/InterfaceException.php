<?php
/**
 *
 *
 * @user: songjingjing
 * @date: 2018/7/3
 */

namespace Helper;

class InterfaceException extends \Exception
{
}