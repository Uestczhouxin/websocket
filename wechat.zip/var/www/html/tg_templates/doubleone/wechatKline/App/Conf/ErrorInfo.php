<?php
/**
 *
 *
 * @user: songjingjing
 * @date: 2018/7/3
 */

namespace Conf;


class ErrorInfo
{
    public static function getMsgByCode($statusCode)
    {
       $msgInfo = [
           // 通用错误
           404 => '接口不存在',
           401 => '用户验证失败',
           500 => '服务器内部错误',
           -1 => '接口参数错误',
       ];

       if (isset($msgInfo[$statusCode])) {
           return $msgInfo[$statusCode];
       }

       return null;
    }
}