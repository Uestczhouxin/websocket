<?php
/**
 * Created by PhpStorm.
 * User: winne
 * Date: 2018/7/30
 * Time: 7:26
 */

namespace Controller\WSController;

use Helper\Log;
use Helper\RedisHelper;
use Model\FriendList;
use Model\GameModel\MockUserData;
use Model\GameModel\UserData;
use Model\Rank;
use Model\ScoreRank;
use Model\StockPool100;
use Model\UserInfo;

class MatchTable
{
    protected $tableId;

    /**
     * @var UserData
     */
    protected $user1Data;

    /**
     * @var UserData
     */
    protected $user2Data;

    protected $userGameIdToPosition;

    /**
     * @var array 股票数据
     */
    protected $stockData;

    /**
     * @var string 当前桌状态
     */
    protected $tableStatus;

    /**
     * @var null|array 游戏结果
     */
    protected $gameResult;

    protected $reconnectData = [];

    /**
     * @var int 创建table时间
     */
    protected $createTime;

    /**
     * @var int table过期时间, 超过这个时间会被清除
     */
    protected $expiredTime = 3600;


    /**
     * @var string 当前桌状态-正在游戏
     */
    const TABLE_STATUS_IN_PROGRESS = 'inProgress';
    /**
     * @var string 当前桌状态-游戏结束
     */
    const TABLE_STATUS_FINISH = 'finish';

    public function __construct()
    {
        $this->createTime = time();
    }
    /**
     * @return string 用来获取自增tableId的key
     */
    protected static function getTableIncrKey()
    {
        return \Conf\Redis::KEY_PREFIX . 'table_id_incr';
    }

    public static function getUserGameIdToTableIdHashKey()
    {
        return \Conf\Redis::KEY_PREFIX . 'user_game_id_to_table_id_hash';
    }

    /**
     * @return string 用来保存table数据的key
     */
    protected static function getTableDataHashKey($tableId)
    {
        return \Conf\Redis::KEY_PREFIX . 'table_data_hash' . $tableId;
    }

    /**
     * @param null $tableId
     * @param $user1Data UserData
     * @param $user2Data UserData
     * @return static
     */
    public static function createTable($user1Data, $user2Data, $tableId = null)
    {
        $redis = RedisHelper::getRedisHelperInstance();
        $table = new static();
        if ($tableId === null) {
            $tableId = $redis->incr(static::getTableIncrKey());
        }
        $table->tableId = (string)$tableId;
        $minUserLevel = $user1Data->getUserLevel() > $user2Data->getUserLevel()
            ? $user2Data->getUserLevel() : $user1Data->getUserLevel();
        $table->stockData = StockPool100::getStockDataByUserLevel($minUserLevel);
        $table->user1Data = $user1Data;
        $table->user2Data = $user2Data;
        $table->userGameIdToPosition = [
            $user1Data->getUserGameId() => 'user1Data',
            $user2Data->getUserGameId() => 'user2Data',
        ];
        $table->tableStatus = static::TABLE_STATUS_IN_PROGRESS;
        $redis->hSet(static::getUserGameIdToTableIdHashKey(), $table->user1Data->getUserGameId(), $table->tableId);
        $redis->hSet(static::getUserGameIdToTableIdHashKey(), $table->user2Data->getUserGameId(), $table->tableId);
        $redis->hSet(static::getTableDataHashKey($table->tableId), 'table', serialize($table));

        return $table;
    }

    /**
     * @param $server \swoole_websocket_server
     */
    public function sendMatch($server)
    {
        $sendMessage = [
            'status' => 'matchSuccess',
            'data' => [
                'tableId' => $this->tableId,
                'stockData' => $this->stockData,
                'userData' => [
                    $this->user1Data->getUserInfo(),
                    $this->user2Data->getUserInfo(),
                ],
            ],
        ];
        $this->sendToAllUser($sendMessage, $server);
        //todo n秒后自动开始
    }

    /**
     * @param $userGameId string
     */
    public function setReady($userGameId, $server)
    {
        if (!isset($this->userGameIdToPosition[$userGameId])) {
            return false;
        }

        $userPosition = $this->userGameIdToPosition[$userGameId];

        /**
         * @var $this ->$userPosition UserData
         */
        $this->{$userPosition}->setReady();
        /**
         * @var $this ->$battleUserPosition UserData
         */
        $battleUserPosition = $this->getBattleUserPosition($userGameId);
        if ($this->$battleUserPosition->isReady()) {
            if (!$this->isSendStart()) {
                $sendMessage = [
                    'status' => 'start',
                ];
                $this->$userPosition->sendToUser($sendMessage, $server);
                $this->$battleUserPosition->sendToUser($sendMessage, $server);
                $this->setAutoAction(0, 8, $server);
            }
        }
    }


    /**
     * @param $action string 用户具体操作
     * @param $times int 第几次操作
     * @param $userGameId
     * @param $server
     * @return bool
     */
    public function setAction($action, $times, $userGameId, $server)
    {
        if (!isset($this->userGameIdToPosition[$userGameId])) {
            return false;
        }

        /**
         * @var $this ->$userPosition UserData
         */
        $userPosition = $this->userGameIdToPosition[$userGameId];
        $this->$userPosition->setAction($action, $times);
        if ($this->user1Data->isOperateAction($times) && $this->user2Data->isOperateAction($times)) {
            if (!$this->isSendActionAndSetNx($times)) {
                $this->sendUserAction($server, $times);
            }
        }
        return true;
    }

    /**
     * @param $fd
     * @param $server \swoole_websocket_server
     */
    public function restore($fd, $server)
    {
        $times = $this->getLastSendTimes();
        $sendMessage = [
            'status' => 'restore',
            'data' => [
                $this->user1Data->getUserInfo()['userId'] => $this->user1Data->getActions($times),
                $this->user2Data->getUserInfo()['userId'] => $this->user2Data->getActions($times),
            ]
        ];
        if (!empty($this->gameResult)) {
            $sendMessage['data']['gameResult'] = $this->gameResult;
        }
        $server->push($fd, json_encode($sendMessage));
    }

    protected function sendUserAction($server, $times)
    {
        $sendMessage = [
            'status' => 'playAction',
            'data' => [
                $this->user1Data->getUserInfo()['userId'] => $this->user1Data->getActions($times),
                $this->user2Data->getUserInfo()['userId'] => $this->user2Data->getActions($times),
            ]
        ];
        $redis = RedisHelper::getRedisHelperInstance();
        $redis->hSet(static::getTableDataHashKey($this->tableId), 'lastSendTimes', $times);
        if ($times == 29) {
            $mockUserData1 = new MockUserData($this->user1Data, $this->stockData);
            MockUserData::pushMockUserList($mockUserData1);
            $mockUserData2 = new MockUserData($this->user2Data, $this->stockData);
            MockUserData::pushMockUserList($mockUserData2);
            //todo 胜负
            $user1IncomeRate = $this->user1Data->countIncomeRate(29, $this->stockData['price']);
            $user2IncomeRate = $this->user2Data->countIncomeRate(29, $this->stockData['price']);
            $user1Id = $this->user1Data->getUserInfo()['userId'];
            $user2Id = $this->user2Data->getUserInfo()['userId'];
            Rank::updateRankScore($user1Id, $user1IncomeRate);
            Rank::updateRankScore($user2Id, $user2IncomeRate);
            if ($user1IncomeRate > $user2IncomeRate) {
                $user1Score = 1;
                $user2Score = -1;
                $user2SaveInfo = ['playNum' => 1];
                $user1SaveInfo = ['playNum' => 1, 'winNum' => 1];
                $this->gameResult = [
                    $user1Id => '1',
                    $user2Id => '2'
                ];
            } elseif ($user1IncomeRate < $user2IncomeRate) {
                $user1Score = -1;
                $user2Score = 1;
                $user2SaveInfo = ['playNum' => 1, 'winNum' => 1];
                $user1SaveInfo = ['playNum' => 1];
                $this->gameResult = [
                    $user1Id => '2',
                    $user2Id => '1'
                ];
            } else {
                $user1Score = 0;
                $user2Score = 0;
                $user1SaveInfo = ['playNum' => 1];
                $user2SaveInfo = ['playNum' => 1];
                $this->gameResult = [
                    $user1Id => '0',
                    $user2Id => '0'
                ];
            }
            ScoreRank::incrByScore($user1Id, $user1Score);
            ScoreRank::incrByScore($user2Id, $user2Score);
            UserInfo::updateUserInfo($user1Id, $user1SaveInfo);
            UserInfo::updateUserInfo($user2Id, $user2SaveInfo);
            $sendMessage['data']['gameResult'] = $this->gameResult;
            $this->updateTableData(['gameResult' => $this->gameResult, 'tableStatus' => static::TABLE_STATUS_FINISH]);
            FriendList::addFriend($user1Id, $user2Id);
        } else {
            $this->setAutoAction($times + 1, 5.0, $server);
        }

        $this->sendToAllUser($sendMessage, $server);
        $this->sendReconnectMessage($times, $server);
    }

    /**
     * 返回某次买卖操作是否发送过，如果没发送过设置为已发送过
     * @param $times
     * @return bool
     */
    protected function isSendActionAndSetNx($times)
    {
        $redis = RedisHelper::getRedisHelperInstance();
        return !$redis->hSetNx(static::getTableDataHashKey($this->tableId), 'is_send_action_nx_' . $times, 1);
    }

    protected function setAutoAction($nextTimes, $waitTime, $server)
    {
        go(function () use ($nextTimes, $waitTime, $server) {
            \co::sleep($waitTime);
            $this->updateVarFromRedis();//防止在sleep期间, 其他进程有更新table数据
            $this->user1Data->setAction(UserData::USER_ACTION_PASS, $nextTimes);
            $this->user2Data->setAction(UserData::USER_ACTION_PASS, $nextTimes);
            if (!$this->isSendActionAndSetNx($nextTimes)) {
                $this->sendUserAction($server, $nextTimes);
            }
        });
    }

    /**
     * @return bool 是否发送过开始
     */
    protected function isSendStart()
    {
        $redis = RedisHelper::getRedisHelperInstance();
        return !$redis->hSetNx(static::getTableDataHashKey($this->tableId), 'send_ready_nx', 1);
    }

    protected function getBattleUserPosition($nowUserGameId)
    {
        foreach ($this->userGameIdToPosition as $gameId => $position) {
            if ($gameId == $nowUserGameId) {
                continue;
            }
            return $position;
        }
    }

    /**
     * @param $userGameId
     * @return false|MatchTable
     */
    public static function getTableByUserGameId($userGameId)
    {
        $redis = RedisHelper::getRedisHelperInstance();
        /**
         * @var \Redis $redis
         */
        $tableId = $redis->hGet(static::getUserGameIdToTableIdHashKey(), $userGameId);
        if (empty($tableId)) {
            return false;
        }

        return static::getTableById($tableId);
    }

    /**
     * @param $tableId
     * @return false|static::class
     */
    public static function getTableById($tableId)
    {
        $redis = RedisHelper::getRedisHelperInstance();
        $table = $redis->hGet(static::getTableDataHashKey($tableId), 'table');
        if (empty($table)) {
            return false;
        } else {
            $table = unserialize($table);
            return $table;
        }
    }

    /**
     * @param $userId
     * @param $fd
     * @param $server \swoole_websocket_server
     */
    public function reconnect($userId, $fd, $server)
    {
        $sendMessage = [
            'status' => 'reconnect',
            'data' => [
                'stockData' => $this->stockData,
                'userData' => [
                    $this->user1Data->getUserInfo(),
                    $this->user2Data->getUserInfo(),
                ],
                'tableStatus' => $this->tableStatus,
                'tableId' => $this->tableId,
            ]
        ];
        $redis = RedisHelper::getRedisHelperInstance();
        $lastSendTimes = $redis->hGet(static::getTableDataHashKey($this->tableId), 'lastSendTimes');
        if ($this->tableStatus == static::TABLE_STATUS_FINISH) {
            $sendMessage['data']['tableStatus'] = $this->tableStatus;
            $sendMessage['data']['gameResult'] = $this->gameResult;
            $sendMessage['data']['userData'][0]['actions'] = $this->user1Data->getActions($lastSendTimes);
            $sendMessage['data']['userData'][1]['actions'] = $this->user2Data->getActions($lastSendTimes);
            $server->push($fd, json_encode($sendMessage));
        } else {
            $this->reconnectData[] = [
                'sendMessage' => $sendMessage,
                'fd' => $fd,
                'userId' => $userId,
                'sendTimes' => $lastSendTimes + 1,
            ];
            $this->updateTableData(['reconnectData' => $this->reconnectData]);
        }
    }

    /**
     * 发送延迟发送的重连消息
     * @param int $nowTimes
     * @param \swoole_websocket_server $server
     */
    protected function sendReconnectMessage($nowTimes, $server)
    {
        foreach ($this->reconnectData as $reconnectDatum) {
            if ($reconnectDatum['sendTimes'] == $nowTimes) {
                $fd = $reconnectDatum['fd'];
                $userId = $reconnectDatum['userId'];
                $sendMessage = $reconnectDatum['sendMessage'];
                $sendMessage['data']['tableStatus'] = $this->tableStatus;
                $sendMessage['data']['gameResult'] = $this->gameResult;
                $sendMessage['data']['userData'][0]['actions'] = $this->user1Data->getActions($nowTimes);
                $sendMessage['data']['userData'][1]['actions'] = $this->user2Data->getActions($nowTimes);
                $server->push($fd, json_encode($sendMessage));
                $this->updateUserRelation($userId, $fd);
            }
        }
    }

    /**
     * @param $userId
     * @param $fd
     */
    protected function updateUserRelation($userId, $fd) {
        if ($this->user1Data->getUserInfo()['userId'] == $userId) {
            $this->user1Data->updateFdAndGameIdRelation($fd);
        } elseif ($this->user2Data->getUserInfo()['userId'] == $userId) {
            $this->user2Data->updateFdAndGameIdRelation($fd);
        }
    }

    protected function updateTableData($data)
    {
        foreach ($data as $key => $value) {
            $this->$key = $value;
        }
        $redis = RedisHelper::getRedisHelperInstance();
        $redis->hSet(static::getTableDataHashKey($this->tableId), 'table', serialize($this));
    }

    protected function sendToAllUser($data, $server)
    {
        $this->user1Data->sendToUser($data, $server);
        $this->user2Data->sendToUser($data, $server);
    }

    public function quit($userGameId, $server)
    {
        if ($this->tableStatus != static::TABLE_STATUS_IN_PROGRESS) {
            return;
        }
        $lastSendTimes = $this->getLastSendTimes();
        if ($lastSendTimes < 29) {
            for ($i = $lastSendTimes; $i <= 29; $i++) {
                $this->isSendActionAndSetNx($i);
            }
        }
        //逃跑用户-1分，收益率局数不算；另一个用户+1分，收益率，局数，都算
        $userPosition = $this->userGameIdToPosition[$userGameId];
        $battleUserPosition = $this->getBattleUserPosition($userGameId);
        $nowUserId = $this->$userPosition->getUserInfo()['userId'];
        $battleUserId = $this->$battleUserPosition->getUserInfo()['userId'];
        $incomeRate = $this->$battleUserPosition->countIncomeRate($this->getLastSendTimes(), $this->stockData['price']);
        ScoreRank::incrByScore($nowUserId, -1);
        ScoreRank::incrByScore($battleUserId, 1);

        UserInfo::updateUserInfo($battleUserId, ['playNum' => 1, 'winNum' => 1]);
        Rank::updateRankScore($battleUserId, $incomeRate);
        /*
         * @var $this ->$battleUserPosition UserData
         */
        $userIncomeRate = $this->$battleUserPosition->countIncomeRate($lastSendTimes, $this->stockData['price']);
        Rank::updateRankScore($battleUserId, $userIncomeRate);
        $this->gameResult = [
            $nowUserId => '2',
            $battleUserId => '1',
        ];
        $this->tableStatus = static::TABLE_STATUS_FINISH;
        $this->updateTableData(['tableStatus' => $this->tableStatus, 'gameResult' => $this->gameResult]);
        $sendMessage = [
            'status' => 'playAction',
            'data' => [
                $this->user1Data->getUserInfo()['userId'] => $this->user1Data->getActions($lastSendTimes),
                $this->user2Data->getUserInfo()['userId'] => $this->user2Data->getActions($lastSendTimes),
                'gameResult' => $this->gameResult,
            ]
        ];
        static::sendToAllUser($sendMessage, $server);
    }

    protected function getLastSendTimes()
    {
        $redis = RedisHelper::getRedisHelperInstance();
        $times = $redis->hGet(static::getTableDataHashKey($this->tableId), 'lastSendTimes');
        if (empty($times)) {
            $times = 0;
        }
        return $times;
    }

    protected function setLastSendTimes($times)
    {
        $redis = RedisHelper::getRedisHelperInstance();
        $redis->hSet(static::getTableDataHashKey($this->tableId), 'lastSendTimes', $times);
    }

    protected function updateVarFromRedis()
    {
        $redisTable = static::getTableById($this->tableId);
        if (!empty($redisTable)) {
            $redisVar = get_class_vars(get_class($redisTable));
            foreach ($redisVar as $key => $value) {
                $this->{$key} = $redisTable->{$key};
            }
        }
    }

    /**
     * table是需要清除
     * @return bool
     */
    public function needClearTable()
    {
        if ((time() - $this->createTime) > $this->expiredTime) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 清理redis中数据
     */
    public function clearTable()
    {
        if (!empty($this->user1Data)) {
            $this->user1Data->clearFromRedis();
        }
        if (!empty($this->user2Data)) {
            $this->user2Data->clearFromRedis();
        }
        $redis = RedisHelper::getRedisHelperInstance();
        $redis->del(static::getTableDataHashKey($this->tableId));
        Log::setLog('table|'. $this->tableId, 'clearLog');
    }
}
