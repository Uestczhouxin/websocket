<?php
/**
 *
 *
 * @user: songjingjing
 * @date: 2018/7/4
 */

namespace Cron;

use Conf\Normal;
use Helper\FileSystem;
use Model\FriendList;
use Model\GameModel\MockUserData;
use Model\Rank;

class ClearRank extends BaseCron
{
    private $updateTimestamp = Normal::DATA_PATH . '/lastClearRank.txt';
    public function cronHandle($argv)
    {
        Rank::clearRank();
        FriendList::clearRank();
        MockUserData::clearMockUserList();//清空错位匹配数据, 不然会出现还有榜单里有空名额的情况
        FileSystem::setContents($this->updateTimestamp, time());
    }
}