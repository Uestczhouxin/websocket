<?php
/**
 * Created by PhpStorm.
 * User: winne
 * Date: 2018/7/30
 * Time: 7:55
 */

namespace Controller\WSController;

use Conf\Normal;
use Model\StockPool;
use Model\StockPool100;

class MatchAlphaHuaTable
{
    protected static $robotData = null;

    protected static function getRobotDataFilePath()
    {
        return Normal::DATA_PATH . '/robotData.json';
    }
    
    protected static function getRobotAvatarBaseUrl()
    {
        return 'https://testm.10jqka.com.cn/tg_templates/doubleone/wechatKline/userAvatar/';
    }


    public static function getMatchedData($userInfo, $version = 1)
    {
        if (static::$robotData == null) {
            static::$robotData = \Helper\FileSystem::getContents(\Conf\Normal::DATA_PATH . '/robotData.json');
        }
        $minRobotLevel = $userInfo['level'] <= 5 ? $userInfo['level'] : 5;
        $robotLevel = rand($minRobotLevel, 5);
        $robotNum = count(static::$robotData[$robotLevel]);
        $robotData = static::$robotData[$robotLevel][rand(0, $robotNum - 1)];
        $robotData['avatar'] = static::getRobotAvatarBaseUrl() . $robotData['avatar'];
        $robotData['userId'] = 'robot';
        $robotData['actions'] = [];

        if ($version == 1) {
            $stockData = StockPool::getStockDataByUserLevel($userInfo['level']);
        } else {
            $stockData = StockPool100::getStockDataByUserLevel($userInfo['level']);
        }


        $allUserData = [
            $userInfo,
            $robotData
        ];
        
        return [
            'stockData' => $stockData,
            'userData' => $allUserData,
        ];
    }
}
