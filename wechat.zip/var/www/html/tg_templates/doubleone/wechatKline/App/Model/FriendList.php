<?php
/**
 * Created by PhpStorm.
 * User: winne
 * Date: 2018/8/6
 * Time: 0:59
 */

namespace Model;

use Conf\Redis;
use Helper\RedisHelper;

class FriendList
{
    protected static function getFriendListKey()
    {
        return Redis::KEY_PREFIX . 'friend_list';
    }

    public static function addFriend($userId1, $userId2, $isEach = true)
    {
        $user1Rate = Rank::getRankDataByUserId($userId1);
        $user2Rate = Rank::getRankDataByUserId($userId2);

        $user1FriendList = static::getFriendList($userId1);
        $user1FriendList[$userId2] = $user2Rate;
        static::updateFriendList($userId1, $user1FriendList);

        if ($isEach) {
            $user2FriendList = static::getFriendList($userId2);
            $user2FriendList[$userId1] = $user1Rate;
            static::updateFriendList($userId2, $user2FriendList);
        }
    }

    public static function getFriendList($userId)
    {
        $redis = RedisHelper::getRedisHelperInstance();
        $friendList = $redis->hGet(static::getFriendListKey(), $userId);
        $friendList = empty($friendList) ? [] : json_decode($friendList, true);
        return $friendList;
    }

    public static function updateFriendList($userId, $friendList)
    {
        $redis = RedisHelper::getRedisHelperInstance();
        if (empty($friendList)) {
            $friendList = [];
        }
        static::sortList($friendList);
        $redis->hSet(static::getFriendListKey(), $userId, json_encode($friendList));
    }

    protected static function sortList(&$sortAry)
    {
        uasort($sortAry, function ($a, $b) {
            if (empty($a)) {
                return true;
            } elseif (empty($b)) {
                return false;
            } else {
                return $a['incomeRate'] < $b['incomeRate'];
            }
        });
    }

    public static function getFriendRankNum($userId, $incomeRate)
    {
        $friendList = static::getFriendList($userId);
        $friendRankNum = 1;
        foreach ($friendList as $friendData) {
            if ($friendData['incomeRate'] > $incomeRate) {
                $friendRankNum += 1;
            }
        }
        return $friendRankNum;
    }

    public static function clearRank()
    {
        $redisHelper = RedisHelper::getRedisHelperInstance();
        $redisHelper->rename(self::getFriendListKey(), self::getFriendListKey().'bak');
        $redisHelper->expire(self::getFriendListKey() . 'bak', 0);
    }

    public static function updateAllFriendRank()
    {
        $redis = RedisHelper::getRedisHelperInstance();
        $it = null;
        do{
            $friendHashData = $redis->getRedis()->hScan(static::getFriendListKey(), $it);
            foreach ($friendHashData as $userId => $friendList) {
               $friendList = json_decode($friendList, true);
               foreach ($friendList as $friendUserId => $friendRate) {
                    $friendRank = Rank::getRankDataByUserId($friendUserId);
                    if ($friendRank) {
                        $friendList[$friendUserId] = $friendRank;
                    }
               }
               static::updateFriendList($userId, $friendList);
            }
        } while ($it > 0);
    }

}
