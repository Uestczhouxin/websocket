<?php

/**
 * 日志类, 读写日志, 监控日志并报警
 * UserInfo: songjingjing
 * Date: 2018/1/2
 */

namespace Helper;

use Conf\Normal;

class Log
{
    const ERROR_LEVEL_WARNING = 'warning';
    const ERROR_LEVEL_ERROR = 'error';


    /**
     * 错误日志
     * @param $content string|array 日志内容
     * @param string $logLevel 日志等级, warning日志会进行邮件报警
     */
    public static function setErrorLog($content, $logLevel = self::ERROR_LEVEL_WARNING)
    {
        $logFileName = "error_$logLevel.log";
        self::setLog($content, $logFileName);
    }


    /**
     * @param $content
     * @param null|string $logFileName 日志文件名
     */
    public static function setLog($content, $logFileName = null)
    {
        if ($logFileName === null) {
            $logFilePath = Normal::LOG_PATH . '/log' . date('Ymd');
        } else {
            $logFilePath = Normal::LOG_PATH . '/' . $logFileName . date('Ymd');
        }

        $dir = dirname($logFilePath);
        if (!is_dir($dir)) {
            mkdir($dir);
            FileSystem::chOwnAndGroup($dir);
        }
        $fileExits = file_exists($logFilePath);

        if (is_array($content)) {
            $content = json_encode($content);
        }

        $contents = date('Y-m-d H:i:s') . '|' . $content . "\n";
        file_put_contents($logFilePath, $contents, FILE_APPEND);
        if (!$fileExits) {
            FileSystem::chOwnAndGroup($logFilePath);
        }
    }
}