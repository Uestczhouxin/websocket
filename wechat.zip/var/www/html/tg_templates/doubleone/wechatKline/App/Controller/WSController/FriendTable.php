<?php
/**
 *
 *
 * @user: songjingjing
 * @date: 2018/8/1
 */

namespace Controller\WSController;

use Helper\RedisHelper;
use Model\GameModel\UserData;
use Model\StockPool100;

class FriendTable extends MatchTable
{
    /**
     * @var string 房主用户位置
     */
    protected $ownerUserPosition;

    /**
     * @var string 对战用户位置
     */
    protected $battleUserPosition;

    /**
     * @var array 观战用户列表
     */
    protected $watchUserDataList = [];

    /**
     * @var null|int 房主开始游戏的时间
     */
    protected $gameStartDateTime;

    /**
     * @var string 当前桌状态-等待用户
     */
    const TABLE_STATUS_WAIT_USER = 'waitUser';

    public static function createTable($user1Data, $user2Data = null, $tableId = null)
    {
        $redis = RedisHelper::getRedisHelperInstance();

        $table = new static();
        $table->tableId = $tableId;
        $table->user1Data = $user1Data;
        $table->ownerUserPosition = 'user1Data';
        $table->stockData = StockPool100::getStockDataByUserLevel($user1Data->getUserLevel());

        $table->tableStatus = static::TABLE_STATUS_WAIT_USER;
        $table->userGameIdToPosition = [
            $user1Data->getUserGameId() => 'user1Data',
        ];

        $redis->hSet(static::getUserGameIdToTableIdHashKey(), $user1Data->getUserGameId(), $table->tableId);
        $redis->hSet(static::getTableDataHashKey($table->tableId), 'table', serialize($table));

        return $table;
    }

    protected function updateUserRelation($userId, $fd)
    {
        $isWatchUser = false;
        foreach ($this->watchUserDataList as $userData) {
            /**
             * @var $userData UserData
             */
            if ($userData->getUserInfo()['userId'] == $userId) {
                $userData->updateFdAndGameIdRelation($fd);
                $isWatchUser = true;
            }
        }
        if (!$isWatchUser) {
            parent::updateUserRelation($userId, $fd);
        }
    }

    public function sendMatch($server)
    {
        $ownerPosition = $this->ownerUserPosition;
        $sendData = $this->getTableData($this->$ownerPosition->getUserGameId());
        $sendMessage = [
            'status' => 'matchFriend',
            'data' => $sendData,
        ];
        $this->$ownerPosition->sendToUser($sendMessage, $server);
    }

    /**
     * @param $userInfo array userInfo
     * @param $fd int fd
     * @param $server
     */
    public function addUser($userInfo, $fd, $server)
    {
        $ownerUserPosition = $this->ownerUserPosition;
        $battleUserPosition = $ownerUserPosition == 'user1Data' ? 'user2Data' : 'user1Data';
        if ($this->$ownerUserPosition->getUserInfo()['userId'] == $userInfo['userId']) {
            $this->$ownerUserPosition->updateFdAndGameIdRelation($fd);
            $userData = $this->$ownerUserPosition;
        } elseif (!empty($this->$battleUserPosition)
            && $this->$battleUserPosition->getUserInfo()['userId'] == $userInfo['userId']
        ) {
            $this->$battleUserPosition->updateFdAndGameIdRelation($fd);
            $userData = $this->$battleUserPosition;
            /**
             * @var $userData UserData
             */
            $userData->cancelReady();
        } else {
            foreach ($this->watchUserDataList as $watchUserData) {
                /**
                 * @var $watchUserData UserData
                 */
                if ($watchUserData->getUserInfo()['userId'] == $userInfo['userId']) {
                    $watchUserData->updateFdAndGameIdRelation($fd);
                    $userData = $watchUserData;
                }
            }
        }
        if (empty($userData)) {//用户原本不在桌上
            $userData = new UserData($userInfo, $fd);
            $sendMessage = [
                'status' => 'changeUser',
                'data' => [
                    'action' => 'join',
                    'userData' => $userData->getUserInfo()
                ]
            ];

            if (empty($this->$battleUserPosition)) { //对战位置是空的
                $sendMessage['data']['userData']['userType'] = 'battle';
                $this->userGameIdToPosition[$userData->getUserGameId()] = $battleUserPosition;
                $this->sendToAllUser($sendMessage, $server);
                $this->updateTableData([
                    'battleUserPosition' => $battleUserPosition,
                    $battleUserPosition => $userData,
                    'userGameIdToPosition' => $this->userGameIdToPosition,
                ]);
            } else {
                $sendMessage['data']['userData']['userType'] = 'watch';
                $this->sendToAllUser($sendMessage, $server);
                $this->watchUserDataList[] = $userData;
                $this->updateTableData([
                    'watchUserDataList' => $this->watchUserDataList
                ]);
            }
        }
        $sendData = $this->getTableData($userData->getUserGameId());
        $sendMessage = [
            'status' => 'matchFriend',
            'data' => $sendData,
        ];
        $redis = RedisHelper::getRedisHelperInstance();
        $redis->hSet(static::getUserGameIdToTableIdHashKey(), $userData->getUserGameId(), $this->tableId);
        $userData->sendToUser($sendMessage, $server);
    }

    protected function getTableData($userGameId)
    {
        $ownerPosition = $this->ownerUserPosition;
        $battlePosition = $this->battleUserPosition;
        $data = [
            'stockData' => $this->stockData,
            'userData' => [
                'owner' => $this->$ownerPosition->getUserInfo(),
            ],
            'watchUserData' => [],
            'tableStatus' => $this->tableStatus,
            'tableId' => $this->tableId,
        ];
        foreach ($this->watchUserDataList as $watchUserData) {
            /**
             * @var $watchUserData UserData
             */
            $data['watchUserData'][] = $watchUserData->getUserInfo();
        }
        if ($userGameId == $this->$ownerPosition->getUserGameId()) {
            $data['userType'] = 'owner';
        } 
        if (!empty($battlePosition) && !empty($this->$battlePosition)) {
            $data['userData']['battle'] = $this->$battlePosition->getUserInfo();
            if ($userGameId == $this->$battlePosition->getUserGameId()) {
                $data['userType'] = 'battle';
            }
        }
        if (!isset($data['userType'])) {
            $data['userType'] = 'watch';
        }

        return $data;
    }

    protected function sendToAllUser($data, $server)
    {
        if (!empty($this->user1Data)) {
            $this->user1Data->sendToUser($data, $server);
        }
        if (!empty($this->user2Data)) {
            $this->user2Data->sendToUser($data, $server);
        }
        foreach ($this->watchUserDataList as $watUserData) {
            /**
             * @var $waitUserData UserData
             */
            $watUserData->sendToUser($data, $server);
        }
    }

    public function setReady($userGameId, $server)
    {
        $battlePosition = $this->battleUserPosition;
        $ownPosition = $this->ownerUserPosition;
        if (empty($battlePosition) || empty($ownPosition)) {
            return;
        }
        if ($this->$battlePosition->getUserGameId() == $userGameId) {
            $this->$battlePosition->setReady();
        }
        if ($this->$battlePosition->isReady()) {
            $ownPosition = $this->ownerUserPosition;
            $sendMessage = [
                'status' => 'ready',
                'data' => ['userId' => $this->$battlePosition->getUserInfo()['userId']],
            ];
            $this->$ownPosition->sendToUser($sendMessage, $server);
        }
    }

    public function setStart($userGameId, $server)
    {
        $ownerPosition = $this->ownerUserPosition;
        $battleUserPosition = $this->battleUserPosition;
        if (empty($this->$battleUserPosition)
            || empty($this->$ownerPosition)
            || !$this->$battleUserPosition->isReady()
            || $this->$ownerPosition->getUserGameId() != $userGameId
        ) {
            return;
        }
        $this->gameStartDateTime = time();
        $this->updateTableData(
            [
                'tableStatus' => static::TABLE_STATUS_IN_PROGRESS,
                'gameStartDateTime' => $this->gameStartDateTime,
            ]
        );
        $sendMessage = [
            'status' => 'start',
        ];
        $this->setAutoAction(0, 8, $server);
        $this->sendToAllUser($sendMessage, $server);
    }

    public function quit($userGameId, $server)
    {
        $redis = RedisHelper::getRedisHelperInstance();
        $needClearTable = false;
        $quitUserData;
        /**
         * @var $redis \Redis;
         */
        if ($this->tableStatus == static::TABLE_STATUS_WAIT_USER) {
            $ownerUserPosition = $this->ownerUserPosition;
            $battleUserPosition = $this->battleUserPosition;
            if ($userGameId == $this->$ownerUserPosition->getUserGameId()) {
                if (empty($battleUserPosition)) {//房主走了，没有对战用户,直接散了, 删除这个table
                    $sendMessage = ['status' => 'battleTerminateBeforeStart'];
//                    $redis->del(static::getTableDataHashKey($this->tableId));
                    $needClearTable = true;
                } else {//房主走了，有对战用户，对战用户成为房主
                    $sendMessage = [
                        'status' => 'changeUser',
                        'data' => [
                            'action' => 'quit',
                            'userData' => $this->$ownerUserPosition->getUserInfo(),
                        ]
                    ];
                    $quitUserData = $this->$ownerUserPosition;
                    $sendMessage['data']['userData']['userType'] = 'owner';
                    unset($this->userGameIdToPosition[$userGameId]);
                    $this->updateTableData(
                        [
                            'ownerUserPosition' => $battleUserPosition,
                            'battleUserPosition' => null,
                            'userGameIdToPosition' => $this->userGameIdToPosition,
                            $ownerUserPosition => null,
                        ]
                    );
                }
            } elseif (!empty($this->$battleUserPosition)
                && $userGameId == $this->$battleUserPosition->getUserGameId()
            ) {
                $sendMessage = [
                    'status' => 'changeUser',
                    'data' => [
                        'action' => 'quit',
                        'userData' => $this->$battleUserPosition->getUserInfo(),
                    ]
                ];
                $quitUserData = $this->$battleUserPosition;
                $sendMessage['data']['userData']['userType'] = 'battle';
                unset($this->userGameIdToPosition[$userGameId]);
                $this->updateTableData(
                    [
                        $battleUserPosition => null,
                        'battleUserPosition' => null,
                        'userGameIdToPosition' => $this->userGameIdToPosition,
                    ]
                );
            } else {
                $sendMessage = $this->watchUserQuit($userGameId);
            }
        } elseif ($this->tableStatus == static::TABLE_STATUS_IN_PROGRESS) {
            if (!isset($this->userGameIdToPosition[$userGameId])) {
                $sendMessage = $this->watchUserQuit($userGameId);
            } else {
                $quitWaitTime = ($this->gameStartDateTime + 3) - time();
                if ($quitWaitTime > 0) {
                   go(function () use ($quitWaitTime, $userGameId, $server) {
                       \co::sleep($quitWaitTime);
                       $this->updateVarFromRedis();
                       parent::quit($userGameId, $server);
                   });
                } else {
                    parent::quit($userGameId, $server);
                }
            }
        }
        if (!empty($sendMessage)) {
            $this->sendToAllUser($sendMessage, $server);
        }
        /**
         * @var $quitUserData UserData
         */
        if (!empty($quitUserData)) {
            $quitUserData->clearFromRedis();
        }
        if ($needClearTable) {
            $this->clearTable();
        }
    }

    protected function watchUserQuit($userGameId)
    {
        $sendMessage = [];
        foreach ($this->watchUserDataList as $index => $watchUserData) {
            /**
             * @var $watchUserData UserData
             */
            if ($watchUserData->getUserGameId() == $userGameId) {
                $sendMessage = [
                    'status' => 'changeUser',
                    'data' => [
                        'action' => 'quit',
                        'userData' => $watchUserData->getUserInfo(),
                    ]
                ];
                $watchUserData->clearFromRedis();
                $sendMessage['data']['userData']['userType'] = 'watch';
                unset($this->watchUserDataList[$index]);
                $this->updateTableData(['watchUserDataList' => array_values($this->watchUserDataList)]);
            }
        }
        return $sendMessage;
    }

    public function clearTable()
    {
        foreach ($this->watchUserDataList as $userData) {
            /**
             * @var $userData UserData
             */
            $userData->clearFromRedis();
        }
        parent::clearTable();
    }
}
