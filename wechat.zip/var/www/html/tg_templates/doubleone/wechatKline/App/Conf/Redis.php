<?php
/**
 *
 *
 * @user: songjingjing
 * @date: 2018/7/3
 */

namespace Conf;


class Redis
{
    const CONFIG = 'main';
    const KEY_PREFIX = 'mobile_web_kline_wechat_';
}