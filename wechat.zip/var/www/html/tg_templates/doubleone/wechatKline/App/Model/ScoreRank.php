<?php
/**
 * 根据用户积分进行排名的排行榜
 *
 * @user: songjingjing
 * @date: 2018/7/3
 */

namespace Model;

use Conf\Redis;
use Helper\RedisHelper;

class ScoreRank
{
    protected static function getRankSortedSetKey()
    {
        return Redis::KEY_PREFIX . 'sortRank_soredSet';
    }

    public static function incrByScore($userId, $score = 1)
    {
        $redisHelper = RedisHelper::getRedisHelperInstance();
        /**
         * @var $redisHelper \Redis
         */
        $redisHelper->zIncrBy(self::getRankSortedSetKey(), $score, $userId);
    }

    public static function getScoreByUerId($userId)
    {
        $redisHelper = RedisHelper::getRedisHelperInstance();
        /**
         * @var $redisHelper \Redis
         */
        return $redisHelper->zScore(self::getRankSortedSetKey(), $userId);
    }
    /**
     * 获取达到等级6需要的积分, 不存在等级6的时候返回false
     */
    public static function getMaxLevelScore()
    {
        $redisHelper = RedisHelper::getRedisHelperInstance();
        /**
         * @var $redisHelper \Redis
         */

        $maxScore = $redisHelper->zRevRange(self::getRankSortedSetKey(), 0, 0, true);
        if (empty($maxScore)) {//排行榜为空
            return false;
        }

        $maxScore = array_values($maxScore)[0];
        if ($maxScore < 80) { // 最高分没到80分
            return false;
        }

        $ableUserList = $redisHelper->zRevRangeByScore(self::getRankSortedSetKey(), $maxScore, 80);
        if (count($ableUserList) < 30) {//达到等级5的用户没到30个
            return false;
        }

        $rankUserNum = $redisHelper->zCount(self::getRankSortedSetKey(), 0, $maxScore);

        $minScoreRankPosition = round($rankUserNum * 0.1);//符合前10%积分的排行榜位置
        $maxLevelWinNum = array_values(
            $redisHelper->zRevRange(
                self::getRankSortedSetKey(),
                $minScoreRankPosition,
                $minScoreRankPosition
            )
        )[0];
        return $maxLevelWinNum;
    }
}