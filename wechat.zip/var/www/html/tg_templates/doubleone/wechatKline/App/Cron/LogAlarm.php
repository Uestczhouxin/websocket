<?php
/**
 * 日志报警
 * UserInfo: songjingjing
 * Date: 2018/4/25
 */

namespace Cron;

use Conf\Normal;
use Helper\FileSystem;
use Helper\Log;

class LogAlarm extends BaseCron
{

    /**
     * @var string 记录报警信息的文件
     */
    protected $lastAlarmFile = Normal::DATA_PATH . '/lastLogAlarm.txt';

    public function cronHandle($skipTimeLimit = false)
    {
        $cronStartTime = time();

        $warningFilePath = Normal::LOG_PATH . '/error_' . Log::ERROR_LEVEL_ERROR . '.log' . date('Ymd');

        $lastUpdateData = $this->getLastAlarmData($cronStartTime);
        $lastUpdateTime = $lastUpdateData['lastUpdateTime'];
        $alarmEndLine = $lastUpdateData['lastEndLine'];


        $warningFileTime = FileSystem::getMTime($warningFilePath);
        if ($warningFileTime <= $lastUpdateTime) {
            Log::setLog(
                array(
                    'class' => self::class,
                    'warningFileTime' => $warningFileTime,
                    'lastUpdateTime' => $lastUpdateTime,
                    'message' => '没有新的日志, 不需要报警'
                )
            );
            return;
        }

        $logHandle = fopen($warningFilePath, 'r');
        if (!$logHandle) {
            Log::setLog(
                array(
                    'class' => self::class,
                    'filePath' => $warningFilePath,
                    'message' => '当天没有错误文件 不需要报警'
                )
            );
            return;
        }

        for ($i = 1; ($i < $alarmEndLine) && (!feof($logHandle)); $i++) {
            fgets($logHandle);
        }

        $mailContent = null;

        while (!feof($logHandle)) {
            $alarmEndLine++;
            $logContent = fgets($logHandle);
            if (empty($logContent)) {
                continue;
            }
            $mailContent .= $logContent . '<br/>';
        }

        if ($mailContent === null) {
            Log::setLog(array(
                'class' => self::class,
                'message' => 'mail Content empty 不需要报警'
            ));
            return;
        }

        $ipUtil = new \MobilePHPLib\Ths\IP\IPUtil();
        $mailer = new \MobilePHPLib\Ths\Mail\Mailer();

        $mailContent = '报警服务器: ' . $ipUtil->getServerIP() . '<br/>' . $mailContent;
        try {
            $result = $mailer->setReceivers(Normal::ERROR_ALARM_MAILS)
                ->setSubject(Normal::APP_NAME . '日志报警邮件')
                ->setContent($mailContent)
                ->setFromName($ipUtil->getServerIP())
                ->send();
            Log::setLog(array(
                'class' => self::class,
                'message' => 'send alarm mail result:' . json_encode($result)
            ));
        } catch (\Exception $e) {
            Log::setLog($e->getTraceAsString(), 'alarmMailError');
        }

        $this->saveLastAlarmData($cronStartTime, $alarmEndLine);
    }

    protected function getLastAlarmData($cronStartTime)
    {
        $lastAlarmData = FileSystem::getContents($this->lastAlarmFile);
        if (!is_array($lastAlarmData)) {
            $lastAlarmData = array();
        }
        if (!isset($lastAlarmData['lastUpdateTime'])) {
            $lastAlarmData['lastUpdateTime'] = 3;
        }
        if (!isset($lastAlarmData['lastEndLine']) || date('Ymd', $cronStartTime) != date(
            'Ymd',
                $lastAlarmData['lastUpdateTime']
        )
        ) {
            $lastAlarmData['lastEndLine'] = 0;
        }
        return $lastAlarmData;
    }

    protected function saveLastAlarmData($cronStartTime, $endLine)
    {
        FileSystem::setContents(
            $this->lastAlarmFile,
            array('lastUpdateTime' => $cronStartTime, 'lastEndLine' => $endLine)
        );
    }
}