<?php

/**
 * Created by PhpStorm.
 * UserInfo: songjingjing
 * Date: 2018/4/17
 */

namespace Cron;

abstract class BaseCron
{
    abstract public function cronHandle($argv);
}