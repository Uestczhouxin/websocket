<?php
namespace Model;

use Conf\Redis;
use Helper\RedisHelper;

/**
 * 根据用户总收益率进行排名的排行版
 * Date: 2018/7/2
 * Time: 0:48
 */
class Rank
{
    const SHOW_RANK_NUM = 100;

    protected static function getRankSortedSetKey()
    {
        return Redis::KEY_PREFIX . 'rank_soredSet';
    }

    public static function getRankUserIdList()
    {
        $redisHelper = RedisHelper::getRedisHelperInstance();
        /**
         * @var $redisHelper \Redis
         */
        return $redisHelper->zRevRange(self::getRankSortedSetKey(), 0, 99, true);
    }

    public static function getRankDataByUserId($userId)
    {
        $redisHelper = RedisHelper::getRedisHelperInstance();
        /**
         * @var $redisHelper \Redis
         */
        $rankNum = $redisHelper->zRevRank(self::getRankSortedSetKey(), $userId);
        if ($rankNum === false) {
            return false;
        }
        $rankNum += 1;

        $incomeRate = $redisHelper->zScore(self::getRankSortedSetKey(), $userId);
        return ['rankNum' => $rankNum, 'incomeRate' => $incomeRate];
    }

    public static function updateRankScore($userId, $incomeRate)
    {
        $redisHelper = RedisHelper::getRedisHelperInstance();
        /**
         * @var $redisHelper \Redis
         */

        $oldMaxRateIncome = $redisHelper->zScore(self::getRankSortedSetKey(), $userId);

        if ($oldMaxRateIncome === false || $oldMaxRateIncome < $incomeRate) {
            $redisHelper->zAdd(self::getRankSortedSetKey(), $incomeRate, $userId);
        }
    }

    public static function clearRank()
    {
        $redisHelper = RedisHelper::getRedisHelperInstance();
        $redisHelper->rename(self::getRankSortedSetKey(), self::getRankSortedSetKey().'bak');
        $redisHelper->expire(self::getRankSortedSetKey() . 'bak', 0);
    }
}