<?php
use Conf\Normal;
use Controller\WSController\MatchAlphaHuaTable;
use Controller\WSController\MatchTable;
use Controller\WSController\FriendTable;
use Controller\WSController\MockTable;
use Model\GameModel\MockUserData;
use Swoole\Coroutine\Channel;

require_once '/var/www/MobilePHPLib/autoload.php';
require_once __DIR__ . '/ClassLoader.php';

/**
 * Created by PhpStorm.
 * UserInfo: winne
 * Date: 2018/7/2
 * Time: 1:23
 */
class WebSocketServer
{
    protected $server;

    private $robotData;

    /**
     * @var Channel
     */
    protected $matchChannel;

    public function __construct()
    {
        $this->server = new \swoole_websocket_server('0.0.0.0', Conf\WebSocket::getPort(), SWOOLE_PROCESS);
        $this->server->set(array(
            'worker_num' => 8,
            'daemonize' => true,
            'reactor_num' => 8,
            'max_coro_num' => 2000,
            'log_file' => Normal::LOG_PATH . '/ws.log',
        ));
        $this->server->on('Open', array($this, 'onOpen'));
        $this->server->on('message', array($this, 'onMessage'));
        $this->server->on('close', array($this, 'onClose'));
        $this->server->on('workerStart', array($this, 'onWorkerStart'));
        $this->server->start();
    }

    public function onWorkerStart()
    {
        //todo 开进程处理匹配

        $this->matchChannel = new Channel(1);

        go(function () {
            $userMaxWaitTime = 5;//todo 不写死在这里
            $waitMatchUser = [];
            /**
             * @var \Redis $redis
             */
            while (1) {
                if ($this->matchChannel->length() > 0) {
                    $userData = $this->matchChannel->pop();
                    $waitMatchUser[] = $userData;
                }
                if (count($waitMatchUser) == 2) {
                    //todo 匹配成功, 发送新一桌的数据;
                    /**
                     * @var $user1Data \Model\GameModel\UserData;
                     */
                    $user1Data = $waitMatchUser[0];
                    /**
                     * @var $user1Data \Model\GameModel\UserData;
                     */
                    $user2Data = $waitMatchUser[1];

                    $table = MatchTable::createTable($user1Data, $user2Data);
                    $table->sendMatch($this->server);

                    $waitMatchUser = [];
                } elseif (count($waitMatchUser) == 1
                    && $waitMatchUser[0]->getConnectTime() + $userMaxWaitTime <= time()
                ) {
                    /**
                     * @var $userData \Model\GameModel\UserData
                     */
                    $userData = $waitMatchUser[0];
                    $mockUserData = MockUserData::popMockUserList();
                    //todo userid一致也抛弃掉
                    if (empty($mockUserData)) {
                        $sendMessage = [
                            'status' => 'matchAlphaHua',
                            'data' => MatchAlphaHuaTable::getMatchedData($userData->getUserInfo(), 2),
                        ];
                        $userData->sendToUser($sendMessage, $this->server);
                    } elseif ($mockUserData->getUserInfo()['userId'] == $userData->getUserInfo()['userId']) {
                        MockUserData::pushMockUserList($mockUserData);
                        $sendMessage = [
                            'status' => 'matchAlphaHua',
                            'data' => MatchAlphaHuaTable::getMatchedData($userData->getUserInfo(), 2),
                        ];
                        $userData->sendToUser($sendMessage, $this->server);
                        $userData->clearFromRedis();
                    } else{
                        $table = MockTable::createTable($userData, $mockUserData);
                        $table->sendMatch($this->server);
                    }

                    $waitMatchUser = [];
                } else {
                    \co::sleep(1.0);
                }
            }
        });
    }

    public function onOpen(swoole_websocket_server $server, swoole_http_request $request)
    {
        \Helper\Log::setLog('onOpen|fd ' .$request->fd . '|' . json_encode($request->get), 'socketStream');
        $userId = $request->get['userId'];
        $op = isset($request->get['op']) ? $request->get['op'] : 'match';
        $version = isset($request->get['version']) ? $request->get['version'] : 1;

        #region userInfo
        $userScore = \Model\ScoreRank::getScoreByUerId($userId);
        $maxLevelScore = \Model\ScoreRank::getMaxLevelScore();
        $userLevel = \Model\UserInfo::getLevelByScore($userScore, $maxLevelScore);
        $baseUserData = \Model\UserInfo::getUserInfoList([$userId])[0];
        $userInfo = [
            'userId' => $userId,
            'userName' => $baseUserData['userName'],
            'avatar' => $baseUserData['avatar'],
            'actions' => [],
            'level' => $userLevel,
        ];
        #endregion
        if ($version == 1) {
            $sendData = [
                'status' => 'matchAlphaHua',
                'data' => MatchAlphaHuaTable::getMatchedData($userInfo, $version),
            ];
            $server->push($request->fd, json_encode(array('status' => 'wait')));
            go(function () use ($sendData, $server, $request) {
                co::sleep(rand(1, 3));
                $server->push($request->fd, json_encode($sendData));
            });
        } elseif ($version == 2) {
            switch ($op) {
                case 'match':
                    $server->push($request->fd, json_encode(array('status' => 'wait')));
                    $userData = new \Model\GameModel\UserData($userInfo, $request->fd);
                    $this->matchChannel->push($userData);
                    break;
                case 'reconnect':
                    $tableId = isset($request->get['tableId']) ? $request->get['tableId'] : false;
                    if ($tableId) {
                        $table = MatchTable::getTableById($tableId);
                        if (empty($table)) {
                            $this->server->push(
                                $request->fd,
                                json_encode(
                                    [
                                        'status' => 'destroy',
                                    ]
                                )
                            );
                        } else {
                            $table->reconnect($userId, $request->fd, $server);
                        }
                    }
                    break;
                case 'friend':
                    $tableId = $request->get['tableId'];
                    $userData = new \Model\GameModel\UserData($userInfo, $request->fd);
                    $table = FriendTable::createTable($userData, null, $tableId);
                    $table->sendMatch($server);
                    break;
                case 'joinFriend':
                    $tableId = $request->get['tableId'];
                    $table = FriendTable::getTableById($tableId);
                    if (empty($table) || !($table instanceof FriendTable)) {
                        $this->server->push(
                            $request->fd,
                            json_encode([
                                'status' => 'destroy',
                            ])
                        );
                    } else {
                        $table->addUser($userInfo, $request->fd, $server);
                    }
                    break;

            }
        }
    }

    public function onMessage(swoole_websocket_server $server, swoole_websocket_frame $frame)
    {
        \Helper\Log::setLog('onMessage|fd ' .$frame->fd . '|' . $frame->data, 'socketStream');
        $request = json_decode($frame->data, true);
        $op = isset($request['op']) ? $request['op'] : '';

        switch ($op) {
            case 'ping':
                $server->push($frame->fd, json_encode(['status' => 'pong']));
                break;
            case 'ready':
                $userGameId = \Model\GameModel\UserData::getUserGameIdByFd($frame->fd);
                $table = MatchTable::getTableByUserGameId($userGameId);
                if ($table === false || $userGameId === false) {
                    //todo
                } else {
                    $table->setReady($userGameId, $server);
                }
                break;
            case 'start':
                $userGameId = \Model\GameModel\UserData::getUserGameIdByFd($frame->fd);
                $table = MatchTable::getTableByUserGameId($userGameId);
                if (!empty($table) && is_callable([get_class($table), 'setStart'])) {
                    /**
                     * @var $table FriendTable
                     */
                    $table->setStart($userGameId, $server);
                }
                break;
            case 'playAction':
                $action = isset($request['data']['action']) ? $request['data']['action'] : false;
                $times = isset($request['data']['times']) ? $request['data']['times'] : false;
                if (!$action) {
                    break;
                }
                $userGameId = \Model\GameModel\UserData::getUserGameIdByFd($frame->fd);
                $table = MatchTable::getTableByUserGameId($userGameId);
                if ($table === false || $userGameId === false) {
                } else {
                    $table->setAction($action, $times, $userGameId, $server);
                }
                break;
            case 'quit':
                $userGameId = \Model\GameModel\UserData::getUserGameIdByFd($frame->fd);
                $table = MatchTable::getTableByUserGameId($userGameId);
                if (!empty($table) && is_callable([get_class($table), 'quit'])) {
                    $table->quit($userGameId, $server);
                }
                break;
            case 'restore':
                $userGameId = \Model\GameModel\UserData::getUserGameIdByFd($frame->fd);
                $table = MatchTable::getTableByUserGameId($userGameId);
                if (!empty($table) && is_callable([get_class($table), 'restore'])) {
                    $table->restore($userGameId, $server);
                }
                break;
            default:
                break;
        }
    }

    public function onClose(swoole_websocket_server $server, $fd)
    {
        \Model\GameModel\UserData::clearFdToUserGameId($fd);
    }
}

$webSocketServer = new WebSocketServer();