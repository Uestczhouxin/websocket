<?php
/**
 * Created by PhpStorm.
 * User: songjingjing
 * Date: 2017/3/13
 * Time: 16:29
 */
require_once __DIR__ . '/vendor/autoload.php';
spl_autoload_register(function($class) {
    $path = __DIR__ . '/lib/' . str_replace("\\", '/', $class) . '.php';
    if (file_exists($path)) {
        require_once $path;
    } else if ($class = 'Ths_Verify_Tool') {
        require_once "/var/www/phplib/Ths_Verify_Tool/Ths_Verify_Tool.php";
    }
});
