<?php

namespace DouDiZhuData;

/**
 * Created by PhpStorm.
 * User: songjingjing
 * Date: 2017/2/15
 * Time: 17:04
 */
class Table
{
    //桌号自增id
    static $REDIS_KEY_TABLE_ID = REDIS_KEY_PREFIX . 'table_id';

    //redis中table的前缀
    static $REDIS_KEY_TABLE_PREFIX = REDIS_KEY_PREFIX . 'table_hash_';

    //redis中score数据的前缀
    static $REDIS_KEY_SCORE_PREFIX = REDIS_KEY_PREFIX . 'score_list_';

    //redis中log数据的前缀
    static $REDIS_KEY_LOG_PREFIX = REDIS_KEY_PREFIX . 'log_list_';

    //发牌时间长度 5000ms
    static $SEND_CARD_TIME = 5000;

    /** @var  string 当前阶段 */
    public $status;
    /** 当前阶段-发牌 */
    const TABLE_STATUS_DEAL_CARDS = 'dealCards';
    /** 当前阶段-出牌 */
    const TABLE_STATUS_PLAY_CARDS = 'playCards';
    /** 当前阶段-叫地主 */
    const TABLE_STATUS_JIAODIZHU = 'jiaoDiZhu';
    /** 当前阶段-结束 */
    const TABLE_STATUS_FINISH = 'finish';

    /** @var  $className string 当前类名称,从redis里获取出来时用到*/
    protected $className;

    public $id;
    public $allUser;
    public $actionUserIndex;//当前哪个用户出牌
    public $diZhuCards;
    public $lastActionTime;
    public $diZhuIndex;

    private $scoreListId;
    private $logId;


    /**
     * Table constructor.
     * @var $id int
     */
    public function __construct($id)
    {
        $this->id = $id;
        $this->className = static::class;
    }

    /**
     *
     * @param $allUser array
     * @param $redis \Redis
     * @return Table
     */
    public static function getNewTable(&$allUser, $redis)
    {
        $tableId = $redis->incr(Table::$REDIS_KEY_TABLE_ID);
        $table = new static($tableId);
        $table->allUser = $allUser;
        foreach ($table->allUser as $index => $user) {
            $user->tableId = $table->id;
            $user->index = $index;
        }
        $table->actionUserIndex = null;
        $table->scoreListId = Table::$REDIS_KEY_SCORE_PREFIX . $table->id;
        $table->logId = Table::$REDIS_KEY_LOG_PREFIX . $table->id;
        $table->saveVarToRedis($redis);


        return $table;
    }

    /**
     * @param $tableId string
     * @param $redis \Redis
     * @return self
     */
    public static function getTableFromRedis($tableId, $redis)
    {
        $allVal = $redis->hGetAll(Table::$REDIS_KEY_TABLE_PREFIX . $tableId);
        if (empty($allVal)) {
            throw new \Exception('empty table id' . $tableId, -1);
        }
        $className = unserialize($allVal['className']);
        $table = new $className($tableId);

        foreach ($allVal as $key => $value) {
            $value = unserialize($value);
            switch ($key) {
                case 'allUserId' :
                    $allUser = static::getAllUserFromRedis($value, $redis);
                    $table->allUser = $allUser;
                    break;
                default :
                    $table->{$key} = $value;
                    break;
            }
        }

        return $table;
    }

    public static function getAllUserFromRedis($userIdList, $redis)
    {
        $allUser = [];
        foreach ($userIdList as $userId) {
            $user = User::getUserFromRedis($userId, $redis);
            $allUser[$user->index] = $user;
        }
        return $allUser;
    }

    public function cleanTable($redis)
    {
        $this->cleanLog($redis);
        $this->cleanScore($redis);
        $this->actionUserIndex = 0;
    }


    /**
     * @var $table Table
     * @var $server \swoole_websocket_server
     */
    public static function dealCards($table, $server)
    {
        $table->status = Table::TABLE_STATUS_DEAL_CARDS;
        $allCard = array_keys(array_fill(0, 54, 0));
        shuffle($allCard);

        $allCard = array_chunk($allCard, 17);
        for ($i = 0; $i < 3; $i++) {
            $table->allUser[$i]->cards = $allCard[$i];
            $table->allUser[$i]->status = $table->allUser[$i]->getVarFromRedis($server->redis, 'status');
        }
        $table->diZhuCards = $allCard[3];
        $table->saveVarToRedis($server->redis);

        $returnData = array();
        $returnData['allUserData'] = array();
        $returnData['status'] = 'dealCards';
        $returnData['score'] = $table->getScore($server->redis);
        $returnData['tableId'] = $table->id;
        foreach ($table->allUser as $index => $user) {
            $userData = array(
                'index' => $index,
                'name' => $user->name
            );
            if (isset($user->isShowCard) && $user->isShowCard == 1) {
                $returnData['score'] = $table->addScore($server->redis, 5);
                $userData['cards'] = $user->cards;
                $table->actionUserIndex = $user->index;

            } else {
                $userData['cards'] = count($user->cards);
            }
            $returnData['allUserData'][] = $userData;
        }
        foreach ($table->allUser as $index => $user) {
            $returnData['cards'] = $user->cards;
            $returnData['index'] = $index;

            $user->sendToUser($server, $returnData, $table);
        }

        $table->lastActionTime = microtime(true);
        $table->saveVarToRedis($server->redis, array('lastActionTime', 'actionUserIndex'));

        //5s以后把table的状态改为叫地主,并通知所有用户现在进入了叫地主阶段
        $timerId = swoole_timer_after(self::$SEND_CARD_TIME, function () use ($server, $table) {
            $table = Table::getTableFromRedis($table->id, $server->redis);
            $table->status = Table::TABLE_STATUS_JIAODIZHU;
            $table->saveVarToRedis($server->redis, array('status'));
            $returnData = array();
            $returnData['status'] = 'jiaoDiZhu';
            $returnData['actionIndex'] = ($table->actionUserIndex == null) ? 0 : $table->actionUserIndex;
            foreach ($table->allUser as $user) {
                $user->sendToUser($server, $returnData, $table);
            }

            if ($table->allUser[$returnData['actionIndex']]->needAutoAction($server->redis)) {
                $table->allUser[$returnData['actionIndex']]->autoAction($server, $table, $returnData);
            }
        });

        \Tools::writeLog(
            0,
            [
                'timerId' => $timerId,
                'table' => json_encode($table)
            ],
            'dealCardsTimer.log'
        );
    }

    /**
     * @param $redis \Redis
     * @param array|null $valNameArr
     */
    public function saveVarToRedis($redis, $valNameArr = null)
    {
        if ($valNameArr == null) {
            $valNameArr = array_keys(get_object_vars($this));
        }

        $tableDataKey = self::$REDIS_KEY_TABLE_PREFIX . $this->id;
        $redis->setTimeout($tableDataKey, REDIS_KEY_TIMEOUT);

        foreach ($valNameArr as $valName) {
            switch ($valName) {
                case 'allUser' :
                    $allUserId = array();
                    /** @var User $user */
                    foreach ($this->allUser as $user) {
                        $allUserId[] = $user->id;
                        $user->saveVarToRedis($redis);
                    }
                    $redis->hSet($tableDataKey, 'allUserId', serialize($allUserId));
                    break;
                default:
                    $redis->hSet($tableDataKey, $valName, serialize($this->{$valName}));
                    break;
            }
        }
    }

    /**
     * @param $redis \Redis|\RedisClusterClass
     * @param $score int
     * @return int
     */
    public function addScore($redis, $score)
    {
        $redis->setTimeout($this->scoreListId, REDIS_KEY_TIMEOUT);
        $listLength = $redis->lPush($this->scoreListId, $score);

        $nowScore = $this->getScoreByLength($redis, $listLength);
        return $nowScore;
    }

    /**
     * @param $redis \Redis|\RedisClusterClass
     * @return int
     */
    public function getScore($redis)
    {
        $listLength = $redis->lLen($this->scoreListId);
        $nowScore = $this->getScoreByLength($redis, $listLength);

        return $nowScore;
    }

    /**
     * @param $redis \Redis|\RedisClusterClass
     */
    public function cleanScore($redis)
    {
        $redis->del($this->scoreListId);
    }

    /**
     * @param $redis \Redis|\RedisClusterClass
     * @param $listLength
     * @return int
     */
    private function getScoreByLength($redis, $listLength)
    {
        $listArr = $redis->lRange($this->scoreListId, 0, $listLength - 1);
        $nowScore = 1;
        foreach ($listArr as $score) {
            $score = intval($score);
            $nowScore *= $score;
        }

        return $nowScore;
    }

    /**
     * 获取table的操作日志
     *
     * @param $redis \Redis|\RedisClusterClass
     * @param $filter array 过滤条件
     * @return array 所有操作日志
     */
    public function getLog($redis, $filter = null)
    {
        $logArr = $redis->lRange($this->logId, 0, -1);
        foreach ($logArr as $key => $log) {
            $logArr[$key] = unserialize($log);
        }

        if (!empty($filter)) {
            foreach ($filter as $filterKey => $filterVal) {
                foreach ($logArr as $logKey => $log) {
                    if ($log[$filterKey] != $filterVal) {
                        unset($logArr[$logKey]);
                    }
                }
            }
            $logArr = array_values($logArr);
        }

        return $logArr;
    }

    /**
     * 添加一条table的操作日志
     *
     * @param $redis \Redis|\RedisClusterClass
     * @param $data array
     * @return int 日志总长度
     */
    public function addLog($redis, $data)
    {
        $redis->setTimeout($this->logId, REDIS_KEY_TIMEOUT);
        return $redis->rpush($this->logId, serialize($data));
    }


    /**
     * 获取这一回合上一家出的牌
     * 如果这次是这回合第一个出牌，返回Null
     *
     * @param $redis \Redis|\RedisClusterClass
     * @return null|CardList
     */
    public function getLastPlayCardList($redis)
    {
        $lastCardList = null;
        $logArr = array_reverse($this->getLog($redis, ['op' => 'playCards']));
        for ($i = 0; $i < 2; $i++) {
            if (isset($logArr[$i]) && $logArr[$i]['action'] != 'pass') {
                $lastCardList = $logArr[$i]['action'];
                break;
            }
        }
        return $lastCardList;

    }

    /**
     * @param $redis \Redis|\RedisClusterClass
     */
    public function cleanLog($redis)
    {
        $redis->del($this->logId);
    }

    public static function unsetTable($tableId, $redis)
    {
        $table = Table::getTableFromRedis($tableId, $redis);
        $logArr = [];
        $logArr['log'] = $table->getLog($redis);
        $logArr['table'] = $table;
        \Tools::writeLog(1, $logArr, 'unset.log');

        foreach ($table->allUser as $user) {
            User::unsetUser($user->id, $redis);
        }
        $table->cleanScore($redis);
        $table->cleanLog($redis);
        $redis->del(Table::$REDIS_KEY_TABLE_PREFIX . $table->id);
    }

    /**
     * 判断是否是春天
     * 春天：农民一次没出牌或者地主只出了一次牌
     *
     * @param $type string nongming|dizhu 赢的是农民还是地主
     * @param $redis \Redis
     * @return bool
     */
    public function isSpring($winner, $redis)
    {
        $isSpring = true;
        $logArr = $this->getLog(
            $redis,
            [
                'op' => 'playCards'
            ]
        );
        switch ($winner) {
            case 'nongmin':
                $dizhuActionTimes = 0;
                foreach ($logArr as $log) {
                    if ($log['action'] != 'pass' && $log['userIndex'] === $this->diZhuIndex) {
                        $dizhuActionTimes++;
                    }
                    if ($dizhuActionTimes >= 2) {
                        $isSpring = false;
                        break;
                    }
                }
                break;
            case 'dizhu':
                foreach ($logArr as $log) {
                    if ($log['action'] != 'pass' && $log['userIndex'] !== $this->diZhuIndex) {
                        $isSpring = false;
                        break;
                    }
                }
                break;
        }
        return $isSpring;
    }

    /**
     * 给桌上所有人发送相同的消息
     *
     * @param $server \swoole_server
     * @param $data array
     */
    public function sendToAllUser($server, $data)
    {
        foreach ($this->allUser as $user) {
            /**
             * @var $user User
             */
            $user->sendToUser($server, $data, $this);
        }
    }

}