<?php

/**
 * Created by PhpStorm.
 * User: songjingjing
 * Date: 2017/6/9
 */
class Filter
{
    /**
     * @var string 需要过滤的关键字文件
     */
    private $_filterFilePath = DATA_PATH . '/filter.txt';

    /**
     * @var string sns 获取普通敏感词
     */
    private $_filterBasicUrl = 'http://post.10jqka.com.cn/ps/admin/api.php?method=sensitive.getSensitiveCache&return=json';
    /**
     * @var string 获取网站黑名单敏感词
     */
    private $_filterSiteUrl = 'http://post.10jqka.com.cn/ps/admin/api.php?method=sensitive.getSiteCache&return=json';

    private $_filterArr;

    public function __construct()
    {
        if ($this->needUpdate()) $this->updateFilterFile();

        $this->_filterArr = $this->getFile($this->_filterFilePath);
    }

    /**
     * 过滤内容
     *
     * @param $inputStr String 输入需要过滤语句
     */
    public function ReplaceContent($inputStr)
    {
        foreach ($this->_filterArr as $filterStr) {
            //转义'/'符号
            $filterCount = mb_strlen($filterStr, 'UTF-8');
            $replacement = str_repeat('*', $filterCount);
            $inputStr = str_replace($filterStr, $replacement, $inputStr);
        }

        return $inputStr;
    }

    /**
     * 判断文件是否需要更新
     * 每天更新一次
     *
     * @return bool
     */
    private function needUpdate()
    {
        if (!file_exists($this->_filterFilePath))
            return true;
        return filectime($this->_filterFilePath) < strtotime('-1 day');
    }

    /**
     * 更新要过滤的关键词
     */
    private function updateFilterFile()
    {
        $basicDataArr = $this->getDataFromSnsInterface($this->_filterBasicUrl);
        foreach ($basicDataArr as &$basicData) {
            $basicData = $basicData['name'];
        }

        $siteDataArr = $this->getDataFromSnsInterface($this->_filterSiteUrl);

        $filterArr = array_merge($basicDataArr, $siteDataArr);

        $this->setFile($this->_filterFilePath, $filterArr);
    }


    /**
     * 从sns的接口获取数据
     *
     * @param $url
     * @return array
     */
    private function getDataFromSnsInterface($url)
    {
        $curl = new Curl\Curl();
        $curl->get($url);
        if ($curl->error) {
            return [];
        }
        $responseArr = json_decode($curl->response, true);
        if (!isset($responseArr['errorCode']) || $responseArr['errorCode'] != 0) {
            return [];
        }

        return $responseArr['result'];
    }

    private function setFile($path, $data)
    {
        if (!file_exists(dirname($path))) {
            mkdir(dirname($path));
        }

        file_put_contents($path, json_encode($data));
    }

    private function getFile($path)
    {
        return json_decode(file_get_contents($path), true);
    }

}

