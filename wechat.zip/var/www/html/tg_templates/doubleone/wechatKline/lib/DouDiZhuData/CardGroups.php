<?php
/**
 * Created by PhpStorm.
 * User: songjingjing
 * Date: 2017/3/18
 * Time: 17:39
 */

namespace DouDiZhuData;

/**
 * 用来放用户的一手牌，构造时候把各个牌型拆出来，现在只拆了单张、三条、炸弹、王炸
 * todo 感觉现在这个结构不好处理
 *
 * Class CardGroups
 * @package DouDiZhuData
 */
class CardGroups
{
    public $groups;
    public $allCard;

    public function __construct(CardList $userCardsList)
    {
        $this->allCard = $userCardsList->list;
        //拆牌
        $kings = [];
        foreach ($userCardsList->valueCount as $value => $num) {
            $cardArr = [];
            foreach ($userCardsList->list as $card) {
                if ($card->value == $value) {
                    /**
                     * @var $card Card
                     */
                    if ($value >= 13) {
                        //大小王单独处理
                        $kings[] = $card->cardToNum();
                    } else {
                        $cardArr[] = $card->cardToNum();
                    }
                }
            }
            if ($value < 13) {
                $cardList = new CardList($cardArr);
                $this->groups[$cardList->listType][] = $cardList;
            }
        }

        if (count($kings) != 0) {
            $cardList = new CardList($kings);
            $this->groups[$cardList->listType][] = $cardList;
        }

        foreach ($this->groups as $key => $group) {
            usort($this->groups[$key], function ($a, $b) {
                return $a->list[0]->value < $b->list[0]->value ? -1 : 1;
            });
        }
    }

    public function getSingle(CardList $lastCardList = null)
    {
        $data = [];

        if (isset($this->groups[CardList::TYPE_SINGLE])) {
            //先找单牌有没有可以打的
            foreach ($this->groups[CardList::TYPE_SINGLE] as $cardList) {
                /**
                 * @var $cardList CardList
                 */
                if ($lastCardList == null || $cardList->list[0]->value > $lastCardList->list[0]->value) {
                    $data = $cardList->cardListToArray();
                    return $data;
                }
            }
        }
        if (isset($this->groups[CardList::TYPE_DOUBLE])) {
            //拆对子
            foreach ($this->groups[CardList::TYPE_DOUBLE] as $cardList) {
                /**
                 * @var $cardList CardList
                 */
                if ($lastCardList == null || $cardList->list[0]->value > $lastCardList->list[0]->value) {
                    $data = [];
                    $data[] = $cardList->list[0]->cardToNum();
                    return $data;
                }
            }
        }
        if (isset($this->groups[CardList::TYPE_THREE])) {
            //拆三条
            foreach ($this->groups[CardList::TYPE_THREE] as $cardList) {
                /**
                 * @var $cardList CardList
                 */
                if ($lastCardList == null || $cardList->list[0]->value > $lastCardList->list[0]->value) {
                    $data = [];
                    $data[] = $cardList->list[0]->cardToNum();
                    return $data;
                }
            }
        }
        if (isset($this->groups[CardList::TYPE_BOMB])) {
            //拆炸弹
            foreach ($this->groups[CardList::TYPE_BOMB] as $cardList) {
                /**
                 * @var $cardList CardList
                 */
                if ($lastCardList == null || $cardList->list[0]->value > $lastCardList->list[0]->value) {
                    $data = [];
                    $data[] = $cardList->list[0]->cardToNum();
                    return $data;
                }
            }
        }
        if (isset($this->groups[CardList::TYPE_KING_BOMB])) {
            //拆王炸
            foreach ($this->groups[CardList::TYPE_KING_BOMB] as $cardList) {
                /**
                 * @var $cardList CardList
                 */
                if ($lastCardList == null || $cardList->list[0]->value > $lastCardList->list[0]->value) {
                    $data = [];
                    $data[] = $cardList->list[0]->cardToNum();
                    return $data;
                }
            }
        }

        return $data;
    }

    public function getDouble(CardList $lastCardList = null)
    {
        $data = [];
        if (isset($this->groups[CardList::TYPE_DOUBLE])) {
            //先找对子有没有可以打的
            foreach ($this->groups[CardList::TYPE_DOUBLE] as $cardList) {
                /**
                 * @var $cardList CardList
                 */
                if ($lastCardList == null || $cardList->list[0]->value > $lastCardList->list[0]->value) {
                    $data = $cardList->cardListToArray();
                    return $data;
                }
            }
        }
        if (isset($this->groups[CardList::TYPE_THREE])) {
            //拆三条
            foreach ($this->groups[CardList::TYPE_THREE] as $cardList) {
                /**
                 * @var $cardList CardList
                 */
                if ($lastCardList == null || $cardList->list[0]->value > $lastCardList->list[0]->value) {
                    $data = [];
                    for ($i = 0; $i < 2; $i++) {
                        $data[] = $cardList->list[$i]->cardToNum();
                    }
                    return $data;
                }
            }
        }
        if (isset($this->groups[CardList::TYPE_BOMB])) {
            //拆炸弹
            foreach ($this->groups[CardList::TYPE_BOMB] as $cardList) {
                /**
                 * @var $cardList CardList
                 */
                if ($lastCardList == null || $cardList->list[0]->value > $lastCardList->list[0]->value) {
                    $data = [];
                    for ($i = 0; $i < 2; $i++) {
                        $data[] = $cardList->list[$i]->cardToNum();
                    }
                    return $data;
                }
            }
        }
        return $data;
    }

    public function getThree(CardList $lastCardList = null)
    {
        $data = [];
        if (isset($this->groups[CardList::TYPE_THREE])) {
            //三条
            foreach ($this->groups[CardList::TYPE_THREE] as $cardList) {
                /**
                 * @var $cardList CardList
                 */
                if ($lastCardList == null || $cardList->list[0]->value > $lastCardList->list[0]->value) {
                    $data = $cardList->cardListToArray();
                    return $data;
                }
            }
        }
        if (isset($this->groups[CardList::TYPE_BOMB])) {
            //拆炸弹
            foreach ($this->groups[CardList::TYPE_BOMB] as $cardList) {
                /**
                 * @var $cardList CardList
                 */
                if ($lastCardList == null || $cardList->list[0]->value > $lastCardList->list[0]->value) {
                    $data = [];
                    for ($i = 0; $i < 3; $i++) {
                        $data[] = $cardList->list[$i]->cardToNum();
                    }
                }
            }
        }
        return $data;
    }

    public function getBomb(CardList $lastCardList = null) {
        $data = [];
        if (isset($this->groups[CardList::TYPE_BOMB])) {
            //拆炸弹
            foreach ($this->groups[CardList::TYPE_BOMB] as $cardList) {
                /**
                 * @var $cardList CardList
                 */
                if ($lastCardList == null || $cardList->list[0]->value > $lastCardList->list[0]->value) {
                    $data =  $cardList->cardListToArray();
                }
            }
        }
        return $data;
    }

    public function getKingBomb() {
        $data = [];
        if (isset($this->groups[CardList::TYPE_KING_BOMB])) {
            $data = $this->groups[CardList::TYPE_KING_BOMB][0]->cardListToArray();
        }

        return $data;
    }

    /**
     * 根据单顺数量和顺牌最小那张，从手牌里取相应顺子
     *
     * @param $limitNum int 顺几张
     * @param null $lastStartValue int
     * @return array
     */
    public function getSingleConnectLimit($limitNum, $lastStartValue = null)
    {
        //todo 以后应该根据出牌的是否是自己人决定拆牌到哪级，比如不为了打自己人的牌拆了炸弹
        $cardValueArr = [];
        $cardValueArr = array_merge($cardValueArr, $this->getValue(CardList::TYPE_SINGLE));
        $cardValueArr = array_merge($cardValueArr, $this->getValue(CardList::TYPE_DOUBLE));
        $cardValueArr = array_merge($cardValueArr, $this->getValue(CardList::TYPE_THREE));
        $cardValueArr = array_merge($cardValueArr, $this->getValue(CardList::TYPE_BOMB));
        sort($cardValueArr);

        $connectNum = 0;
        foreach ($cardValueArr as $value) {
            if ($lastStartValue !== null && $value <= $lastStartValue) {
                continue;
            }
            $startValue = $value;
            $connectNum = 1;
            $endValue = $value;
            foreach ($cardValueArr as $index) {
                if ($index == $endValue + 1) {
                    $endValue = $index;
                    $connectNum += 1;
                }
                if ($connectNum == $limitNum) {
                    break(2);
                }
            }

        }
        //todo 根据value取单张牌
        $data = [];
        if ($connectNum == $limitNum) {
            for ($i = $startValue; $i <= $endValue; $i++) {
                foreach ($this->allCard as $card) {
                    if ($card->value == $i) {
                        $data[] = $card->cardToNum();
                        break;
                    }
                }
            }

        }

        return $data;
    }

    public function getDoubleConnectLimit($limitNum, $lastStartValue = null)
    {
        $cardValueArr = [];
        $cardValueArr = array_merge($cardValueArr, $this->getValue(CardList::TYPE_DOUBLE));
        $cardValueArr = array_merge($cardValueArr, $this->getValue(CardList::TYPE_THREE));
        $cardValueArr = array_merge($cardValueArr, $this->getValue(CardList::TYPE_BOMB));

        sort($cardValueArr);

        $connectNum = 0;
        foreach ($cardValueArr as $value) {
            if ($lastStartValue !== null && $value <= $lastStartValue) {
                continue;
            }
            $startValue = $value;
            $connectNum = 1;
            $endValue = $value;
            foreach ($cardValueArr as $index) {
                if ($index == $endValue + 1) {
                    $endValue = $index;
                    $connectNum += 1;
                }
                if ($connectNum == $limitNum) {
                    break(2);
                }
            }
        }
        $data = [];
        if ($connectNum == $limitNum) {
            for ($i = $startValue; $i <= $endValue; $i++) {
                $sameValueNum = 0;
                foreach ($this->allCard as $card) {
                    if ($card->value == $i) {
                        $data[] = $card->cardToNum();
                        $sameValueNum += 1;
                        if ($sameValueNum == 2) {
                            break;
                        }
                    }
                }
            }
        }

        return $data;
    }

    public function getThreeConnectLimit($limitNum, $lastStartValue = null)
    {
        $cardValueArr = [];
        $cardValueArr = array_merge($cardValueArr, $this->getValue(CardList::TYPE_THREE));
        $cardValueArr = array_merge($cardValueArr, $this->getValue(CardList::TYPE_BOMB));

        sort($cardValueArr);

        $connectNum = 0;
        foreach ($cardValueArr as $value) {
            if ($lastStartValue !== null && $value <= $lastStartValue) {
                continue;
            }
            $startValue = $value;
            $connectNum = 1;
            $endValue = $value;
            foreach ($cardValueArr as $index) {
                if ($index == $endValue + 1) {
                    $endValue = $index;
                    $connectNum += 1;
                }
                if ($connectNum == $limitNum) {
                    break(2);
                }
            }
        }
        $data = [];
        if ($connectNum == $limitNum) {
            for ($i = $startValue; $i <= $endValue; $i++) {
                $sameValueNum = 0;
                foreach ($this->allCard as $card) {
                    if ($card->value == $i) {
                        $data[] = $card->cardToNum();
                        $sameValueNum += 1;
                        if ($sameValueNum == 3) {
                            break;
                        }
                    }
                }
            }
        }

        return $data;
    }

    /**
     * 获取num张不同的单牌
     *
     * @param $num
     */
    public function getSingleByNum($num)
    {
        $data = [];
        $cardValueArr = $this->getValue(CardList::TYPE_SINGLE);
        if (count($cardValueArr) < $num) {
            $cardValueArr = array_merge($cardValueArr, $this->getValue(CardList::TYPE_DOUBLE));
        }
        if (count($cardValueArr) < $num) {
            $cardValueArr = array_merge($cardValueArr, $this->getValue(CardList::TYPE_THREE));
        }
        if (count($cardValueArr) < $num) {
            $cardValueArr = array_merge($cardValueArr, $this->getValue(CardList::TYPE_BOMB));
        }

        if (count($cardValueArr) >= $num) {
            $singleValue = array_splice($cardValueArr, 0, $num);
            foreach ($singleValue as $value) {
                foreach ($this->allCard as $card) {
                    if ($card->value == $value) {
                        $data[] = $card->cardToNum();
                        break;
                    }
                }
            }
        }

        return $data;
    }

    /**
     * 获取num张不同的对子
     *
     * @param $num
     */
    public function getDoubleByNum($num)
    {
        $data = [];
        $cardValueArr = $this->getValue(CardList::TYPE_DOUBLE);
        if (count($cardValueArr) < $num) {
            $cardValueArr = array_merge($cardValueArr, $this->getValue(CardList::TYPE_THREE));
        }
        if (count($cardValueArr) < $num) {
            $cardValueArr = array_merge($cardValueArr, $this->getValue(CardList::TYPE_BOMB));
        }

        if (count($cardValueArr) >= $num) {
            $singleValue = array_splice($cardValueArr, 0, $num);
            foreach ($singleValue as $value) {
                $sameValueNum = 0;
                foreach ($this->allCard as $card) {
                    if ($card->value == $value) {
                        $data[] = $card->cardToNum();
                        $sameValueNum += 1;
                        if ($sameValueNum == 2) {
                            break;
                        }
                    }
                }
            }
        }

        return $data;

    }

    /**
     * 获取num张不同的三条
     *
     * @param $num
     */
    public function getThreeByNum($num)
    {
        $data = [];
        $cardValueArr = $this->getValue(CardList::TYPE_THREE);
        if (count($cardValueArr) < $num) {
            $cardValueArr = array_merge($cardValueArr, $this->getValue(CardList::TYPE_BOMB));
        }

        if (count($cardValueArr) >= $num) {
            $singleValue = array_splice($cardValueArr, 0, $num);
            foreach ($singleValue as $value) {
                $sameValueNum = 0;
                foreach ($this->allCard as $card) {
                    if ($card->value == $value) {
                        $data[] = $card->cardToNum();
                        $sameValueNum += 1;
                        if ($sameValueNum == 2) {
                            break;
                        }
                    }
                }
            }
        }

        return $data;

    }

    public function getValue($type)
    {
        $data = [];
        if (isset ($this->groups[$type])) {
            foreach ($this->groups[$type] as $cardList) {
                if ($cardList->list[0]->value < 12) {
                    $data[] = $cardList->list[0]->value;
                }
            }
        }
        return $data;
    }

    /**
     * 判断判断这副牌是地主牌，能翻几倍
     * 带双王/三条/同花顺 3倍
     * 带顺子/同花色/单王 2倍
     */
    public function getDiZhuAddScore()
    {
        $addScore = 1;

        if (!empty($this->getKingBomb())) {
            $addScore = 3;
        } elseif (!empty($this->getThree())) {
            $addScore = 3;
        } elseif (!empty($this->getSingleConnectLimit(3))) {
            if ($this->allCard[0]->type == $this->allCard[1]
            && $this->allCard[1] == $this->allCard[2]) {
                $addScore = 3;
            } else {
                $addScore = 2;
            }
        } elseif ($this->allCard[0]->type == $this->allCard[1]->type
        && $this->allCard[1]->type == $this->allCard[2]->type) {
            $addScore = 2;
        } else if ($this->allCard[0]->type == 5
        || $this->allCard[1]->type == 5
        || $this->allCard[2]->type == 5) {
            $addScore = 2;
        }

        return $addScore;
    }


}