<?php

/**
 * Created by PhpStorm.
 * User: songjingjing
 * Date: 2017/2/14
 * Time: 10:56
 */
class Tools
{
    /**
     * 根据redis配置获取一个redis对象
     *
     * @param $redisConfig
     * @param bool $isCluster
     * @return Redis|RedisClusterClass
     */
    public static function getRedis($redisConfig, $isCluster = false)
    {
        if ($isCluster) {
            $redis = new RedisClusterClass(
                null,
                $redisConfig['node'],
                $redisConfig['password']
            );
        } else {
            $redis = new Redis();
            $redis->connect(
                $redisConfig['host'],
                $redisConfig['port']
            );
            $redis->auth($redisConfig['password']);
        }

        return $redis;
    }

    /**
     * 记录错误日志
     *
     * @param $code int
     * @param string|array $msg
     * @param $logName
     * @return bool
     */
    public static function writeLog($code, $msg, $logName)
    {
        if (!dir(LOG_PATH)) {
            mkdir(LOG_PATH);
        }
        $logPath = LOG_PATH . '/' . $logName . date('Ymd');
        $contents = date('Y-m-d H:i:s') . '|' . $code . '|' . json_encode($msg) . "\n";
        file_put_contents($logPath, $contents, FILE_APPEND);
        return true;
    }

    /**
     * @param $msg string|array
     */
    public static function echoLog($msg)
    {
        if (!is_string($msg)) {
            $msg = json_encode($msg);
        }
        echo date('H:i:s') . '|' . json_encode($msg) . "\n";
    }

    public static function filterUserName($userName) {
        $nameLength = mb_strlen($userName);
        $firstStr = mb_substr($userName, 0, 1);
        $lastStr = mb_substr($userName, -1, 1);
        if ($nameLength == 1) {
            $resUserName = '*' . $firstStr;
        } else if ($nameLength == 2) {
            $resUserName = '*' . $lastStr;
        } else {
            $resUserName = $firstStr . '**' . $lastStr;
        }

        return $resUserName;
    }

    public static function getPdo($dbConfig) {
        $dsn = "{$dbConfig['type']}:dbname={$dbConfig['db']};host={$dbConfig['host']};charset=UTF8";
        $pdo = new PDO($dsn, $dbConfig['user'], $dbConfig['password']);
        return $pdo;
    }

    public static function getUser($user, $ticket) {
        if (!Ths_Verify_Tool::verifyCookie($user, $ticket)) {
            return false;
        }
        $user = base64_decode($user);
        $user = explode(':', $user);
        return $user;
    }

    public static function getUserId($cookie) {
        $userId = null;
        $user = Tools::getUser($cookie['user'], $cookie['ticket']);
        if (is_array($user) && mb_substr($user[1], 0, 3) != 'mt_') {
            //登陆的用户
            $userId = $user[10];
        }

        return $userId;
    }

    public static function getUserName($cookie) {
        $userName = null;
        $user = Tools::getUser($cookie['user'], $cookie['ticket']);
        if (is_array($user) && mb_substr($user[1], 0, 3) != 'mt_') {
            //登陆的用户
            $userName = $user[1];
        }

        return $userName;
    }
}