<?php
/**
 * Created by PhpStorm.
 * User: songjingjing
 * Date: 2017/2/20
 * Time: 14:18
 */

namespace DouDiZhuData;


class Card
{
    /**
     * 牌号，0-10对应扑克牌中的3-K，11、12对应A和2，13、14对应小王，大王
     *
     * @var int
     */
    public $value;
    /**
     * 花色，1-4对应方块，梅花，红桃，黑桃，大小鬼为5
     *
     * @var int
     */
    public $type;

    /**
     * Card constructor.
     * @param $num int 0-53 一张牌的值
     * @throws \Exception
     */
    public function __construct($num)
    {
        if ($num < 52 && $num >= 0) {
            $this->value = ($num % 13);
            $this->type = intval($num / 13) + 1;
        } else if ($num == 52) {
            $this->value = 13;
            $this->type = 5;
        } else if ($num == 53) {
            $this->value = 14;
            $this->type = 5;
        } else {
            throw new \Exception(
                "num应该在0-53之间，当前为$num\n",
                -1
            );
        }
    }

    /**
     * 根据由0-53表示牌组的数组获取一个card的数组
     * 数组中card值顺序：出现频次高的牌靠前；频次相同时小的靠前
     *
     * @param $numArr array 一个由0-53的数字表示牌组的数组
     * @return array
     */
    public static function getCardList($numArr)
    {
        $cardList = array();
        foreach ($numArr as $num) {
            $cardList[] = new Card($num);
        }

        return $cardList;
    }

    public function cardToNum()
    {
        if ($this->type != 5) {
            $num = (($this->type - 1) * 13) + $this->value;
        } else if ($this->value == 13) {
            $num = 52;
        } else{
            $num = 53;
        }

        return $num;
    }
}
