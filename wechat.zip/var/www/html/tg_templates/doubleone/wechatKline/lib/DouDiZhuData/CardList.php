<?php
/**
 * Created by PhpStorm.
 * User: songjingjing
 * Date: 2017/2/20
 * Time: 16:48
 */

namespace DouDiZhuData;


class CardList
{
    /**
     * 牌组
     *
     * @var array
     */
    public $list;

    /**
     * 牌组中每个value出现的次数，key为扑克的value，value为出现的次数
     *
     * @var array
     */
    public $valueCount;

    /**
     * 这手牌的类型
     *
     * @var
     */
    public $listType;

    //牌型
    const TYPE_SINGLE = 1;//单张
    const TYPE_DOUBLE = 2;//对子
    const TYPE_THREE = 3;//三张
    const TYPE_THREE_ONE = 4;//三带一
    const TYPE_THREE_DOUBLE = 5;//三带对子
    const TYPE_SINGLE_CONNECT = 6;//单顺
    const TYPE_DOUBLE_CONNECT = 7;//双顺
    const TYPE_THREE_CONNECT = 8;//三顺
    const TYPE_AIRCRAFT_WING = 9;//飞机带翅膀
    const TYPE_FOUR_TWO = 10;//四带二
    const TYPE_BOMB = 11;//炸弹
    const TYPE_KING_BOMB = 12;//王炸
    const TYPE_ERROR = -1;


    function __construct($numArr)
    {
        $this->list = array();
        $this->valueCount = array();

        foreach ($numArr as $num) {
            $card = new Card($num);
            $this->list[] = $card;
            $this->valueCount[$card->value] =
                empty($this->valueCount[$card->value])
                    ? 1
                    : $this->valueCount[$card->value] + 1;
        }

        //出现频次多的牌靠前
        arsort($this->valueCount);
        //出现频次一样多的牌，牌面大的靠前
        $tmpArr = array();
        foreach ($this->valueCount as $key => $value) {
            $tmpArr[$value][$key] = $value;
        }
        $this->valueCount = array();
        foreach ($tmpArr as $value) {
            krsort($value);
            $this->valueCount += $value;
        }

        //判断牌型
        if ($this->isSingle()) {
            $this->listType = self::TYPE_SINGLE;
        } elseif ($this->isDouble()) {
            $this->listType = self::TYPE_DOUBLE;
        } elseif ($this->isThree()) {
            $this->listType = self::TYPE_THREE;
        } elseif ($this->isThreeOne()) {
            $this->listType = self::TYPE_THREE_ONE;
        } elseif ($this->isThreeDouble()) {
            $this->listType = self::TYPE_THREE_DOUBLE;
        } elseif ($this->isSingleConnect()) {
            $this->listType = self::TYPE_SINGLE_CONNECT;
        } elseif ($this->isDoubleConnect()) {
            $this->listType = self::TYPE_DOUBLE_CONNECT;
        } elseif ($this->isThreeConnect()) {
            $this->listType = self::TYPE_THREE_CONNECT;
        } elseif ($this->isAirCraftWing()) {
            $this->listType = self::TYPE_AIRCRAFT_WING;
        } elseif ($this->isFourTwo()) {
            $this->listType = self::TYPE_FOUR_TWO;
        } elseif ($this->isBomb()) {
            $this->listType = self::TYPE_BOMB;
        } else if ($this->isKingBomb()){
            $this->listType = self::TYPE_KING_BOMB;
        } else {
            $this->listType = self::TYPE_ERROR;
        }
    }

    /**
     * 对比两个cardList的大小
     *
     * @param CardList $a
     * @param CardList $b
     * @return int|boolean -1:a比b小，1:a比b大，false：a和b不能比较
     */
    public static function compare(CardList $a, CardList $b)
    {
        if ($a->listType == self::TYPE_ERROR || $b->listType == self::TYPE_ERROR) {
            $compareResult = false;
        } elseif ($a->listType === $b->listType) {
            //类型相同
            if (count($a->list) !== count($b->list)) {
                //相同类型，牌数量不同,不能比较
                    $compareResult = false;

            } else {
                //相同类型
                $aMaxKey = key($a->valueCount);
                $bMaxKey = key($b->valueCount);
                if ($aMaxKey == $bMaxKey) {
                    //数量不同时不能比较
                    $compareResult = false;
                } else {
                    //对比出现频次最大那张牌里最大的
                    $compareResult = $aMaxKey > $bMaxKey ? 1 : -1;
                }

            }
        } else {
            //类型不同,炸弹大，如果没有炸弹，不能比较
//            if ($a->listType == self::TYPE_BOMB ) {
//                $compareResult = 1;
//            } else if ($b->listType == self::TYPE_BOMB) {
//                $compareResult = -1;
//            } else {
//                $compareResult = false;
//            }
            if ($a->listType == CardList::TYPE_KING_BOMB || $b->listType == CardList::TYPE_KING_BOMB) {
                //有王炸，王炸比较大
                $compareResult = $a->listType == CardList::TYPE_KING_BOMB ? 1 : -1;
            } else if ($a->listType == CardList::TYPE_BOMB || $b->listType == CardList::TYPE_BOMB) {
                //没有王炸但是有炸弹，炸弹的那个比较大
                $compareResult = $a->listType == CardList::TYPE_BOMB ? 1 : -1;
            } else {
                //没王炸没炸弹牌型还不通，不能比较
                $compareResult = false;
            }
        }

        return $compareResult;
    }

    public function isSingle()
    {
        if (count($this->list) == 1) {
            return true;
        }
        return false;
    }

    public function isDouble()
    {
        if (count($this->list) == 2 && current($this->valueCount) == 2) {
            return true;
        }

        return false;
    }

    public function isThree()
    {
        if (count($this->list) == 3 && current($this->valueCount) == 3) {
            return true;
        }

        return false;
    }

    public function isThreeOne()
    {
        if (count($this->list) == 4 && current($this->valueCount) == 3) {
            return true;
        }

        return false;
    }

    public function isThreeDouble()
    {
        $isThreeDouble = false;

        if (count($this->list) == 5) {
            next($this->valueCount);
            if (current($this->valueCount) == 2 && count($this->valueCount) == 2) {
                $isThreeDouble = true;
            }
        }
        reset($this->valueCount);

        return $isThreeDouble;
    }

    public function isSingleConnect()
    {
        $isSingleConnect = false;

        $connectNum = $this->haveConnect(1);
        if ($connectNum == count($this->list) && $connectNum >= 5) {
            $isSingleConnect = true;
        }

        return $isSingleConnect;
    }

    public function isDoubleConnect()
    {
        $isDoubleConnect = false;

        $connectNum = $this->haveConnect(2);
        if ($connectNum == (count($this->list) / 2) && $connectNum >= 3) {
            $isDoubleConnect = true;
        }

        return $isDoubleConnect;
    }

    public function isThreeConnect()
    {
        $isThreeConnect = false;

        $connectNum = $this->haveConnect(3);
        if ($connectNum == (count($this->list) / 3) && $connectNum >= 2) {
            $isThreeConnect = true;
        }

        return $isThreeConnect;
    }

    public function isAirCraftWing()
    {
        $isAirCraftWing = false;

        $connectNum = $this->haveConnect(3);
        $sameValueNum = count($this->valueCount);

        if ($connectNum >= 2 && ($sameValueNum - $connectNum) == $connectNum) {//根据牌的value判断合法
            //带的单张还是对子
            $valueCountKeys = array_keys($this->valueCount);
            $wingNum = $this->valueCount[$valueCountKeys[$connectNum]];
            $countCardNum = ($wingNum * $connectNum) + $connectNum * 3;
            if ($countCardNum == count($this->list)) {
                $isAirCraftWing = true;
            }
        }

        return $isAirCraftWing;
    }

    public function isFourTwo()
    {
        $isFourTwo = false;

        $valueCountKeys = array_keys($this->valueCount);
        $sameValueNum = count($this->valueCount);
        if ($this->valueCount[$valueCountKeys[0]] == 4 && $sameValueNum == 3) {
            $wingNum = $this->valueCount[$valueCountKeys[1]];
            if (count($this->list) == (4 + ($wingNum * 2))) {
                $isFourTwo = true;
            }
        }

        return $isFourTwo;
    }

    public function isBomb()
    {
        $isBomb = false;
        if (count($this->valueCount) == 1 && current($this->valueCount) == 4) {
            $isBomb = true;
        }

        return $isBomb;
    }

    public function isKingBomb() {
        $isKingBomb = false;
        if (count($this->list) == 2 && count($this->valueCount) == 2) {
            $cardValues = array_keys($this->valueCount);
            if ($cardValues[0] == 14 && $cardValues[1] == 13) {
                $isKingBomb = true;
            }
        }
        return $isKingBomb;
    }

    /**
     * 判断这副牌里有没有顺子
     *
     * @param $sameCardNum 1-单顺 2-双顺 3-三顺
     * @return int 顺了几份
     */
    public function haveConnect($sameCardNum)
    {
        //顺了多少
        $connectNum = 0;
        while ($eachValueCount = each($this->valueCount)) {
            if ($eachValueCount['value'] == $sameCardNum && $eachValueCount['key'] < 12) {//2和双王不在顺里
                break;
            }
        }

        if ($eachValueCount !== false) {
            $nowValue = $eachValueCount['key'] - 1;
            $connectNum = 1;
            while ($eachValueCount = each($this->valueCount)) {
                //已经顺不下去了
                if ($eachValueCount['key'] != $nowValue || $eachValueCount['value'] != $sameCardNum) {
                    break;
                }

                $connectNum++;
                $nowValue--;//valueCount中value的排序是从小到大
            }
        }

        reset($this->valueCount);
        return $connectNum;
    }

    public function cardListToArray() {
        $numArr = array();
        foreach ($this->list as $card) {
            $numArr[] = $card->cardToNum();
        }

        return $numArr;
    }

}
