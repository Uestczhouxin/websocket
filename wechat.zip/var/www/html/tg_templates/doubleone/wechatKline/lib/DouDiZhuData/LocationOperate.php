<?php
/**
 * Created by PhpStorm.
 * User: songjingjing
 * Date: 2017/7/17
 * Describe: 处理本地客户端发来的消息
 */

namespace DouDiZhuData;


class LocationOperate
{
    /**
     * @var array ip白名单，白名单内的ip才能操作
     */
    private $allowIp = ['127.0.0.1'];

    /**
     * @var \Redis|\RedisCluster
     */
    private $redis;

    /**
     * @var string 保存fd的key
     */
    private $fdSetKey = REDIS_LOCAL_FD;

    /**
     * LocationOperate constructor.
     * @param \Redis $redis
     */
    public function __construct($redis)
    {
        $this->redis = $redis;
    }

    public function isLocationRemoteAddress($remoteAddress)
    {
        return in_array($remoteAddress, $this->allowIp);
    }

    /**
     * @param $fd int 把fd加入到本地fd列表
     */
    public function addFd($fd)
    {
        $this->redis->sAdd($this->fdSetKey, serialize($fd));
    }

    /**
     * @param $fd int 把fd从本地fd列表移除
     */
    public function removeFd($fd)
    {
        $this->redis->sRem($this->fdSetKey, serialize($fd));
    }

    /**
     * @param $fd int 判断这个fd是不是本地的客户端
     * @return bool
     */
    public function isLocationFd($fd)
    {
        return $this->redis->sIsMember($this->fdSetKey, serialize($fd));
    }

    /**
     * @param $data string
     * @param $server swoole_server
     */
    public function onMessage($data, $server, $fd)
    {
        $message = LocationMessage::decodeLocationMessage($data);

        if (!method_exists($this, $message->op)) {
            \Tools::writeLog(-1, ['locationMessage' => $message], 'locationError.log');
        }
        
        $this->{$message->op}($server, $message->data);
        $server->push($fd, $message->msgId);
    }

    /**
     * @param $server
     * @param $userInOneTable
     */
    public function matchUser($server, $userInOneTable)
    {
        $table = Table::getNewTable($userInOneTable, $server->redis);
        Table::dealCards($table, $server);
    }
}