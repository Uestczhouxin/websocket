<?php

namespace DouDiZhuData;

/**
 * Created by PhpStorm.
 * User: songjingjing
 * Date: 2017/2/14
 * Time: 14:49
 */
class User
{
    //reids中user的前缀
    static $REDIS_KEY_USER_PREFIX = REDIS_KEY_PREFIX . 'user_hash_';

    /**
     * 叫地主阶段等待时长
     * 单位 ms
     *
     * @var int
     */
    static $WAIT_TIME_JIAODIZHU = 15000;

    /**
     * 地主第一次出牌等待时长,
     * 单位 ms
     *
     * @var int
     */
    static $WAIT_TIME_FIRST_PLAY_CARD = 27000;

    /**
     * 正常出牌等待时长
     * 单位 ms
     *
     * @var int
     */
    static $WAIT_TIME_NORMAL_PLAY_CARD = 15000;


    /** @var  string 游戏里的user id 格式为 userid_第几次参与游戏 */
    public $id;

    /** @var  int 用来发送websocket消息 */
    public $fd;

    /** @var  string 昵称 */
    public $name;

    /** @var  int 在桌上的位置 */
    public $index;

    /** @var  int 进入游戏的时间 */
    public $enterTime;

    /** @var  bool 用户是否明牌 */
    public $isShowCard;

    /** @var  int 所在桌号 */
    public $tableId;

    /** @var  int 游戏时多少次没有操作了,用来判断是否需要托管 */
    public $noActionTimes;

    /** @var  string|null 用户当前的状态 */
    public $status;

    /** @var  int 同花顺账号userId */
    public $thsUserId;

    /** 用户当前状态 在线 */
    const USER_STATUS_ONLINE = 'online';
    /** 用户当前状态 托管 */
    const USER_STATUS_HOSTING = 'hosting';
    /** 用户当前状态 用户主动离开 */
    const USER_STATUS_LEAVE = 'leave';
    /** 用户当前状态 掉线 */
    const USER_STATUS_OFFLINE = 'offline';

    /** @var  array 用户手上的牌 */
    public $cards;

    /** @var  string 用户类型 */
    public $type;

    /**  用户类型 普通用户 */
    const USER_TYPE_USER = 'user';
    /**  用户类型 机器人 */
    const USER_TYPE_ROBOT = 'robot';

    /** @var  $className string 当前类名称,从redis里获取出来时用到*/
    protected $className;

    function __construct($id)
    {
        $this->id = $id;
        $this->className = static::class;
    }

    /**
     * @param $id
     * @param $name
     * @param $type
     * @param $fd
     * @param $isShowCard
     * @param $redis \Redis
     * @return static
     */
    public static function getNewUser($id, $name, $type, $fd, $isShowCard, $redis)
    {
        $user = new static($id);
        $user->name = $name;
        $user->type = $type;
        $user->fd = $fd;
        $user->noActionTimes = 0;
        $user->status = static::USER_STATUS_ONLINE;
        $user->enterTime = time();
        $user->isShowCard = $isShowCard;
        $user->thsUserId = explode('_', $id)[0];
        $user->saveVarToRedis($redis);
        return $user;
    }

    /**
     * 将某些属性保存到redis中
     *
     * @param $redis \Redis
     * @param $valNameArr array  需要保存的属性名,为空时会保存所有设置了的属性
     * @return boolean 保存是否成功
     */
    public function saveVarToRedis($redis, $valNameArr = null)
    {
        //没有设置id, 不能进行保存啊
        if (!isset($this->id)) {
            return false;
        }

        if ($valNameArr == null) {
            $valNameArr = array_keys(get_object_vars($this));
        }

        $userDataKey = User::$REDIS_KEY_USER_PREFIX . $this->id;
        $redis->setTimeout($userDataKey, REDIS_KEY_TIMEOUT);
        foreach ($valNameArr as $valName) {
            if ($valName == 'cards' && is_array($this->cards)) {
                $this->cards = array_merge($this->cards);
                \Tools::writeLog(0, ['flag' => 'save cards', 'userid' => $this->id, 'cardNum' => count($this->cards)],
                    'debugging.log');
            }
            $redis->hSet($userDataKey, $valName, serialize($this->{$valName}));
        }
        return true;
    }

    /**
     * @param $redis \Redis
     * @param $varName string
     * @return mixed
     */
    public function getVarFromRedis($redis, $varName)
    {
        $userDataKey = User::$REDIS_KEY_USER_PREFIX . $this->id;

        switch ($varName) {
            default :
                $value = unserialize($redis->hGet($userDataKey, $varName));
        }

        return $value;
    }

    /**
     * @param $userId
     * @param $redis \Redis
     * @return User|false
     */
    public static function getUserFromRedis($userId, $redis)
    {
        $allVal = $redis->hGetAll(User::$REDIS_KEY_USER_PREFIX . $userId);
        if (empty($allVal)) {
            throw new \Exception('empty user id' . $userId, -1);
        }
        $className = unserialize($allVal['className']);
        $user = new $className($userId);
        foreach ($allVal as $key => $value) {
            $user->{$key} = unserialize($value);
        }
        return $user;
    }

    /**
     * @param \Redis $redis
     * @return User
     */
    public static function getRobotUser($redis)
    {
        $name = self::getRandUserName();
        //这个id最大2^63那么大，不会挂吧
        $id = ROBOT_ID_PREFIX . $redis->incr(REDIS_KEY_ROBOT_ID);
        $user = new User($id, $name, 'robot', null);
        $user->name = $name;
        $user->type = 'robot';
        $user->fd = null;
        return $user;
    }

    /**
     * 返回一个随机的用户名，用户名有三个形式：
     * 1. mx_后跟9位数字
     * 2. mo_后跟9位随机数字
     * 3. 5个随机字母
     *
     * @return string 用户名
     */
    private static function getRandUserName()
    {
        switch (rand(0, 2)) {
            case 0:
//                $name = 'mx_' . rand(100000000, 999999999);
                $name = 'm';
                $name .= "**" . rand(0, 9);
                break;
            case 2:
            default:
                $chars = 'abcdefghijklmnopqrstuvwxyz1234567890';
                $name = $chars[rand(0, 35)] . '**' . $chars[rand(0, 35)];
                break;
        }

        return $name;
    }

    /**
     * 将用户操作发给table上所有的用户，如果下一个行动的用户是电脑，则电脑进行对应的操作
     *
     * @param $server \swoole_server
     * @param $data array
     * @param $table Table
     */
    public function sendToUser($server, $data, $table)
    {
        $this->status = $this->getVarFromRedis($server->redis, 'status');
        $this->fd = $this->getVarFromRedis($server->redis, 'fd');


        \Tools::writeLog(
            0,
            [
                'sendTo' => $this->index,
                'data' => $data,
                'fd' => $this->fd,
                'userId' => $this->id,
                'type' => 'try'
            ],
            'sendLog.log'
        );

        if (isset($data['actionIndex']) && $data['actionIndex'] == $this->index) {
            $table->actionUserIndex = $this->index;
            $table->saveVarToRedis($server->redis, ['actionUserIndex']);
        }

        if ($this->type != 'robot') {

            $pushRes = $server->push($this->fd, json_encode($data));
            $exist = $server->exist($this->fd);
            \Tools::writeLog(
                0,
                [
                    'sendTo' => $this->index,
                    'data' => $data,
                    'fd' => $this->fd,
                    'userId' => $this->id,
                    'type' => 'real',
                    'res' => $pushRes,
                    'exist' => $exist
                ],
                'sendLog.log'
            );
        }

        //超时未操作，设置为托管
        if (isset($data['actionIndex']) && $data['actionIndex'] == $this->index) {
            $table->lastActionTime = time();

            $nextIndex = $this->index;
            $tableId = $table->id;
            $lastActionTime = $table->lastActionTime;
            $table->saveVarToRedis($server->redis, array('lastActionTime'));
            $waitTime = $this->getWaitTime($server->redis, $table);

            swoole_timer_after($waitTime, function () use ($server, $tableId, $nextIndex, $lastActionTime) {
                try {
                    if (!$server->redis->exists(Table::$REDIS_KEY_TABLE_PREFIX . $tableId)) {
                        return;
                    }


                    $table = Table::getTableFromRedis($tableId, $server->redis);
                    if ($table && $table->status != TABLE::TABLE_STATUS_FINISH && $lastActionTime == $table->lastActionTime) {
                        foreach ($table->allUser as $index => $user) {
                            /**
                             * @var $user User
                             */
                            if ($nextIndex == $user->index) {
                                $user->status = $this->getVarFromRedis($server->redis, 'status');
                                if ($user->status == 'leave') {
                                    break;
                                }

                                $lastPlayCardList = $table->getLastPlayCardList($server->redis);

                                if (($lastPlayCardList === null && $table->status == 'playCards') || $user->noActionTimes == 1) {
                                    $saveUserId = $server->redis->hGet(REDIS_KEY_FD_TO_USER_ID, $this->fd);
                                    if ($saveUserId == $this->id) {
                                        //还没把fd对应的userid删除，说明用户没有掉线,用户状态改为托管
                                        $user->changeUserToAI($server, $table, 'hosting');
                                    } else {
                                        $user->changeUserToAI($server, $table, 'offline');
                                    }
                                } else {
                                    if (in_array($table->status, [TABLE::TABLE_STATUS_JIAODIZHU, TABLE::TABLE_STATUS_PLAY_CARDS])) {
                                        if ($table->status == Table::TABLE_STATUS_PLAY_CARDS) {
                                            $user->noActionTimes++;
                                            $user->saveVarToRedis($server->redis, ['noActionTimes']);
                                            $user->sendToUser(
                                                $server,
                                                [
                                                    'status' => 'notice',
                                                    'lastAction' => 'readyHosting',
                                                    'lastIndex' => $user->index
                                                ],
                                                $table
                                            );
                                        }
                                        $user->autoAction($server, $table, ['status' => $table->status], 'pass');
                                    }
                                }
                                break;
                            }
                        }
                    }
                } catch (\Exception $e) {
                    if (isset($getLock) && $getLock) {
                        $user->delLock($server->redis);
                    }
                    echo $e->getCode() . $e->getMessage();
                }
            });
        }

    }

    /**
     * 用户叫地主操作，判断用户当前操作是否合法，合法就保存起来并通知其他用户这个操作
     *
     * @param $server \swoole_server
     * @param $data array 用户出牌数据
     * @param $table Table
     */
    public function jiaoDiZhu($server, $data, $table)
    {
        $userAction = $data['action'];
        $op = 'jiaoDiZhu';

        if ($userAction == 'jiaoDiZhu') {
            $nowScore = $table->addScore($server->redis, 2);
            $table->diZhuIndex = $this->index;
            $table->saveVarToRedis($server->redis, array('diZhuIndex'));
        } else {
            $nowScore = $table->getScore($server->redis);
        }
        $returnData['lastAction'] = $userAction;
        $returnData['lastIndex'] = $this->index;
        $returnData['lastStatus'] = 'jiaoDiZhu';
        $returnData['nowScore'] = $nowScore;
        $returnData['diZhuIndex'] = $table->diZhuIndex;

        $logData = array(
            'op' => $op,
            'action' => $userAction,
            'userIndex' => $this->index
        );
        $table->addLog($server->redis, $logData);
        $jiaoDiZhuLog = $table->getLog($server->redis, array('op' => 'jiaoDiZhu'));

        $logNum = count($jiaoDiZhuLog);
        $firstDiZhu = null;
        foreach ($jiaoDiZhuLog as $index => $log) {
            if ($log['action'] == 'jiaoDiZhu') {
                $firstDiZhu = $log['userIndex'];
                break;
            }
        }

        //判断接下来的操作
        if ($logNum == 4) {
            //4次操作，进入打牌阶段
            $table->status = TABLE::TABLE_STATUS_PLAY_CARDS;
            $table->actionUserIndex = $table->diZhuIndex;
            $table->saveVarToRedis($server->redis, array('status', 'actionUserIndex'));
            $table->allUser[$table->diZhuIndex]->cards = array_merge($table->allUser[$table->diZhuIndex]->cards,
                $table->diZhuCards);
            $table->allUser[$table->diZhuIndex]->saveVarToRedis($server->redis, array('cards'));
            //判断地主牌是怎么样的，对应加分
            $cardGroup = new CardGroups(new CardList($table->diZhuCards));
            $addScore = $cardGroup->getDiZhuAddScore();
            if ($addScore > 1) {
                $returnData['nowScore'] = $table->addScore($server->redis, $addScore);
            }

            $returnData['status'] = $table->status;
            $returnData['actionIndex'] = $table->actionUserIndex;
            $returnData['diZhuCards'] = $table->diZhuCards;
        } else {
            if ($logNum == 3) {
                //3次操作，如果没有人叫地主，重新发牌
                if (!isset($table->diZhuIndex)) {
                    $table->cleanTable($server->redis);
                    Table::dealCards($table, $server);
                    return;
                } else {
                    if ($table->diZhuIndex == $firstDiZhu) {
                        //只有一个人叫地主，直接进入下个阶段
                        $table->status = TABLE::TABLE_STATUS_PLAY_CARDS;
                        $table->actionUserIndex = $table->diZhuIndex;
                        $table->saveVarToRedis($server->redis, array('status', 'actionUserIndex'));
                        $table->allUser[$table->diZhuIndex]->cards = array_merge($table->allUser[$table->diZhuIndex]->cards,
                            $table->diZhuCards);
                        $table->allUser[$table->diZhuIndex]->saveVarToRedis($server->redis, array('cards'));
                        //判断地主牌是怎么样的，对应加分
                        $cardGroup = new CardGroups(new CardList($table->diZhuCards));
                        $addScore = $cardGroup->getDiZhuAddScore();
                        if ($addScore > 1) {
                            $returnData['nowScore'] = $table->addScore($server->redis, $addScore);
                        }

                        $returnData['status'] = TABLE::TABLE_STATUS_PLAY_CARDS;
                        $returnData['actionIndex'] = $table->actionUserIndex;
                        $returnData['diZhuCards'] = $table->diZhuCards;
                    } else {
                        //有不止一个人叫地主，第一次叫地主的人有次叫地主的机会
                        $table->actionUserIndex = $firstDiZhu;
                        $table->saveVarToRedis($server->redis, array('actionUserIndex'));
                        $returnData['status'] = TABLE::TABLE_STATUS_JIAODIZHU;
                        $returnData['actionIndex'] = $table->actionUserIndex;
                        $returnData['status'] = 'jiaoDiZhu';

                    }
                }
            } else {
                $returnData['status'] = 'jiaoDiZhu';
                $returnData['actionIndex'] = ($table->actionUserIndex + 1) % 3;
            }
        }
        if ($this->type != 'user') {
            $randWait = rand(2, 4);
            swoole_timer_after(1000 * $randWait, function () use ($server, $table, $returnData) {
                foreach ($table->allUser as $user) {
                    $user->sendToUser($server, $returnData, $table);
                }

                if ($table->allUser[$returnData['actionIndex']]->needAutoAction($server->redis)) {
                    $table->allUser[$returnData['actionIndex']]->autoAction($server, $table, $returnData);
                }
            });
        } else {
            foreach ($table->allUser as $user) {
                $user->sendToUser($server, $returnData, $table);
            }

            if ($table->allUser[$returnData['actionIndex']]->needAutoAction($server->redis)) {
                $table->allUser[$returnData['actionIndex']]->autoAction($server, $table, $returnData);
            }
        }
    }

    /**
     * @param $server \swoole_server
     * @param $data array
     * @param $table Table
     */
    public function playCards($server, $data, $table)
    {
        $table = Table::getTableFromRedis($table->id, $server->redis);
        if ($table->actionUserIndex != $this->index
            || $table->status != TABLE::TABLE_STATUS_PLAY_CARDS
            || !isset($data['action'])
        ) {
            throw new \Exception('当前不能出牌', -31);
        }
        //根据日志获取最近一次出牌, 如果前两手都是pass，则最近一次出牌为null
        $this->cards = $this->getVarFromRedis($server->redis, 'cards');
        $lastCardList = $table->getLastPlayCardList($server->redis);
        $userAction = $data['action'];

        $returnData = array();
        $saveData = array();
        $returnData['lastAction'] = $userAction;
        $returnData['lastIndex'] = $this->index;
        $returnData['lastStatus'] = TABLE::TABLE_STATUS_PLAY_CARDS;
        $returnData['nowScore'] = $table->getScore($server->redis);
        $returnData['releaseNum'] = count($this->cards);

        if ($userAction == 'pass') {
            //不出
            //前两个用户都为不出时，不能选择不出
            if ($lastCardList === null) {
                throw new \Exception('牌型错误', -32);
            }

            //通知所有用户这个操作，并通知下个用户出牌
            $logData = array('op' => 'playCards', 'action' => $userAction, 'userIndex' => $this->index);
            $table->addLog($server->redis, $logData);
        } else {
            //用户选择出牌
            //判断有没有这些牌
            if (!is_array($this->cards)) {
                \Tools::writeLog(-1, $this->cards, 'userCardsError.log');
            }
            if (count($userAction) != count(array_unique($userAction))) {
                //不能有重复的牌
                throw new \Exception('牌型错误', -33);
            }
            if (!empty(array_diff($userAction, array_intersect($userAction, $this->cards)))) {
                throw new \Exception('牌型错误', -34);
            }

            $cardList = new CardList($userAction);
            if ($cardList->listType < 0) {
                throw new \Exception('牌型错误', -35);
            }
            if ($lastCardList !== null) {
                $compareRes = CardList::compare($cardList, $lastCardList);
                if ($compareRes !== 1) {
                    throw new \Exception('牌型错误', -36);
                }
            }

            //终于确定这货能出牌了
            $this->cards = array_diff($this->cards, $userAction);
            $returnData['releaseNum'] = count($this->cards);

            $this->saveVarToRedis($server->redis, array('cards'));
            $logData = array(
                'op' => 'playCards',
                'action' => $cardList,
                'userIndex' => $this->index
            );
            $table->addLog($server->redis, $logData);

            if ($cardList->listType == CardList::TYPE_BOMB || $cardList->listType == CardList::TYPE_KING_BOMB) {
                $returnData['nowScore'] = $table->addScore($server->redis, 2);
            } else {
                $returnData['nowScore'] = $table->getScore($server->redis);
            }
            $returnData['cardListType'] = $cardList->listType;

            if (count($this->cards) == 0) {
                //赢的是地主还是农民
                if ($this->index == $table->diZhuIndex) {
                    $winner = array($this->index);
                    //判断农民是不是一张牌没出，没出的话加2倍
                    $isSpring = $table->isSpring('dizhu', $server->redis);
                } else {
                    $winner = array_diff(array(0, 1, 2), array($table->diZhuIndex));
                    $winner = array_values($winner);
                    $isSpring = $table->isSpring('nongmin', $server->redis);
                }
                //todo 
                if ($isSpring) {
                    $returnData['nowScore'] = $table->addScore($server->redis, 2);
                }

                foreach ($table->allUser as $index => $user) {
                    $scoreData = [];
                    $scoreData['userIndex'] = $index;
                    $scoreData['baseScore'] = 1;
                    $scoreData['nowScore'] = $returnData['nowScore'];
                    $scoreData['resScore'] = $scoreData['baseScore'] * $scoreData['nowScore'];
                    if (in_array($index, $winner)) {
                        if ($user->status == 'leave' || $user->status == 'offline') {
                            //掉线的用户赢了不得分
                            $scoreData['resScore'] = 0;
                        }
                    } else {
                        //输的人扣分
                        $scoreData['resScore'] -= $scoreData['resScore'] * 2;
                        if ($user->status == 'leave' || $user->status == 'offline') {
                            //逃跑输了的人双倍扣分
                            $scoreData['resScore'] = $scoreData['resScore'] * 2;
                        }
                    }
                    //地主双倍
                    if ($index == $table->diZhuIndex) {
                        $scoreData['resScore'] = $scoreData['resScore'] * 2;
                    }

                    $scoreData['leftCards'] = ($user->index == $this->index) ? [] : $user->cards;

                    $returnData['scoreData'][] = $scoreData;
                    //保存的数据要加上用户状态
                    $scoreData['user'] = $user;
                    $saveData[] = $scoreData;
                }
                $returnData['winUser'] = $winner;
                $returnData['isSpring'] = $isSpring;
                $returnData['status'] = 'finish';
                $table->status = Table::TABLE_STATUS_FINISH;
                $table->saveVarToRedis($server->redis, array('status'));
            }
        }
        if (!isset($returnData['status'])) {
            //设置了这局就结束了！
            $returnData['status'] = 'playCards';
            $table->actionUserIndex = ($table->actionUserIndex + 1) % 3;
            //todo 用户在这里保存操作用户，解决托管可以重复出牌bug；机器人不保存，防止出现机器人出牌顺序bug
            //需要把用户和机器人延迟出牌由现在的发送消息延迟改为真正延迟，才能去掉这个判断和去掉sendData里的保存，去掉sendData里的保存时，记得其他操作要加上这个保存
            if ($this->type == 'user') {
                $table->saveVarToRedis($server->redis, ['actionUserIndex']);
            }
            $returnData['actionIndex'] = $table->actionUserIndex;
        }
        if ($this->type != 'user') {
            $randWait = rand(2, 4);
            swoole_timer_after(1000 * $randWait, function () use ($server, $table, $returnData, $saveData) {
                $table->sendToAllUser($server, $returnData);

                if (isset($returnData['actionIndex'])
                    && $table->allUser[$returnData['actionIndex']]->needAutoAction($server->redis)
                ) {
                    $table->allUser[$returnData['actionIndex']]->autoAction($server, $table, $returnData);
                }

                if (!empty($saveData)) {
                    $server->task(array(
                            'op' => 'saveUserScore',
                            'saveData' => $saveData,
                            'table' => $table
                        )
                    );
                }
            });
        } else {
            foreach ($table->allUser as $user) {
                $user->sendToUser($server, $returnData, $table);

            }

            if (isset($returnData['actionIndex'])
                && $table->allUser[$returnData['actionIndex']]->needAutoAction($server->redis)
            ) {
                swoole_timer_after(500, function () use ($server, $table, $returnData) {
                    //不加这个定时器托管出牌太快了
                    $table->allUser[$returnData['actionIndex']]->autoAction($server, $table, $returnData);
                });
            }

            if (!empty($saveData)) {
                $server->task(array(
                        'op' => 'saveUserScore',
                        'saveData' => $saveData,
                        'table' => $table
                    )
                );
            }
        }
    }

    /**返回给前端一条错误信息
     * @param $server \swoole_websocket_server
     * @param $code int
     * @param $msg string
     * @param $status string
     *
     */
    public function sendCode($server, $code, $msg, $status = 'error')
    {
        \Tools::writeLog(1,
            'sendTo :'
            . $this->index
            . json_encode(array('code' => $code, 'msg' => $msg, 'status' => $status))
            . 'fd:' . $this->fd
            . '|'
            . $this->id,
            'sendLog.log'
        );
        if ($server->exist($this->fd)) {
            $server->push($this->fd, json_encode(array('code' => $code, 'msg' => $msg, 'status' => $status)));
        }

    }

    /**
     * @param $redis \Redis|\RedisCluster
     * @param $table Table
     * @return array|string
     */
    public function getRobotPlayCards($redis, $table)
    {
        $lastCardList = null;
        //上个出牌的人是农民且自己也是农民
        $lastIsCompanion = false;
        $this->cards = $this->getVarFromRedis($redis, 'cards');
        $logArr = $table->getLog($redis, array('op' => 'playCards'));
        $logArrReverse = array_reverse($logArr);
        for ($i = 0; $i < 2; $i++) {
            if (isset($logArrReverse[$i]) && $logArrReverse[$i]['action'] != 'pass') {
                $lastCardList = $logArrReverse[$i]['action'];
                if ($logArrReverse[$i]['userIndex'] != $table->diZhuIndex && $this->index != $table->diZhuIndex) {
                    $lastIsCompanion = true;
                }
                break;
            }
        }


        $cardGroups = new CardGroups(new CardList($this->cards));

        if ($lastCardList == null) {
            //第一次出牌
            $action = $cardGroups->getSingle();
        } else {
            //上家有牌
            $action = 'pass';
            switch ($lastCardList->listType) {
                case CardList::TYPE_SINGLE :
                    $data = $cardGroups->getSingle($lastCardList);
                    if ($data != false) {
                        $action = $data;
                        break;
                    }
                    break;
                case CardList::TYPE_DOUBLE:
                    $data = $cardGroups->getDouble($lastCardList);
                    if ($data != false) {
                        $action = $data;
                        break;
                    }
                    break;
                case CardList::TYPE_THREE:
                    $data = $cardGroups->getThree($lastCardList);
                    if ($data != false) {
                        $action = $data;
                        break;
                    }
                    break;
                case CardList::TYPE_BOMB:
                    //todo
                    $data = $cardGroups->getBomb($lastCardList);
                    if (!empty($data)) {
                        $action = $data;
                        break;
                    }
                    break;
                case CardList::TYPE_THREE_ONE :
                    $lastThreeValue = key($lastCardList->valueCount);
                    //找出这三条，用这三条从groups里找出比他大的三条
                    $lastThreeArr = [];
                    foreach ($lastCardList->list as $lastCard) {
                        /**
                         * @var $lastCard Card
                         */
                        if ($lastCard->value == $lastThreeValue) {
                            $lastThreeArr[] = $lastCard->cardToNum();
                        }
                    }
                    $threeData = $cardGroups->getThree(new CardList($lastThreeArr));
                    if ($threeData) {
                        $remainCardGroups = new CardGroups(new CardList(array_values(array_diff($this->cards,
                            $threeData))));
                        $singleData = $remainCardGroups->getSingle();
                        if ($singleData) {
                            $action = array_merge($singleData, $threeData);
                            break;
                        }
                    }
                    break;
                case CardList::TYPE_THREE_DOUBLE:
                    $lastThreeValue = key($lastCardList->valueCount);
                    //找出这三条，用这三条从groups里找出比他大的三条
                    $lastThreeArr = [];
                    foreach ($lastCardList->list as $lastCard) {
                        /**
                         * @var $lastCard Card
                         */
                        if ($lastCard->value == $lastThreeValue) {
                            $lastThreeArr[] = $lastCard->cardToNum();
                        }
                    }
                    $threeData = $cardGroups->getThree(new CardList($lastThreeArr));
                    if (!empty($threeData)) {
                        $remainCardGroups = new CardGroups(new CardList(array_values(array_diff($this->cards,
                            $threeData))));
                        $doubleData = $remainCardGroups->getDouble();
                        if ($doubleData) {
                            $action = array_merge($doubleData, $threeData);
                            break;
                        }
                    }
                    break;
                case CardList::TYPE_SINGLE_CONNECT:
                    $connectNum = count($lastCardList->valueCount);
                    foreach ($lastCardList->list as $card) {
                        if (!isset($lastStartValue) || $lastStartValue > $card->value) {
                            $lastStartValue = $card->value;
                        }
                    }
                    $data = $cardGroups->getSingleConnectLimit($connectNum, $lastStartValue);
                    if (!empty($data)) {
                        $action = $data;
                    }
                    break;
                case CardList::TYPE_DOUBLE_CONNECT:
                    $connectNum = count($lastCardList->valueCount);
                    foreach ($lastCardList->list as $card) {
                        if (!isset($lastStartValue) || $lastStartValue > $card->value) {
                            $lastStartValue = $card->value;
                        }
                    }
                    $data = $cardGroups->getDoubleConnectLimit($connectNum, $lastStartValue);
                    if (!empty($data)) {
                        $action = $data;
                    }
                    break;
                case CardList::TYPE_THREE_CONNECT:
                    $connectNum = count($lastCardList->valueCount);
                    foreach ($lastCardList->list as $card) {
                        if (!isset($lastStartValue) || $lastStartValue > $card->value) {
                            $lastStartValue = $card->value;
                        }
                    }
                    $data = $cardGroups->getThreeConnectLimit($connectNum, $lastStartValue);
                    if (!empty($data)) {
                        $action = $data;
                    }
                    break;
                case CardList::TYPE_AIRCRAFT_WING:
                    $connectNum = 0;
                    $lastStartValue = 0;
                    $wingNum = 0;//带的是单张还是对子
                    foreach ($lastCardList->valueCount as $value => $num) {
                        if ($num == 3) {
                            $lastStartValue = $value;
                            $connectNum += 1;
                        } else {
                            $wingNum = $num;
                            break;
                        }
                    }
                    $threeConnectData = $cardGroups->getThreeConnectLimit($connectNum, $lastStartValue);
                    if (!empty($threeConnectData)) {
                        $remainCardArr = array_values(array_diff($this->cards, $threeConnectData));
                        $remainCardGroups = new CardGroups(new CardList($remainCardArr));
                        if ($wingNum == 1) {
                            $wingData = $remainCardGroups->getSingleByNum($connectNum);
                        } else {
                            $wingData = $remainCardGroups->getDoubleByNum($connectNum);
                        }
                        if (count($wingData) != 0) {
                            $action = array_merge($wingData, $threeConnectData);
                        }
                    }
                    break;
                case CardList::TYPE_FOUR_TWO:
                    $lastFourValue = key($lastCardList->valueCount);
                    $lastFourArr = [];
                    foreach ($lastCardList->list as $lastCard) {
                        if ($lastCard->value == $lastFourValue) {
                            $lastFourArr[] = $lastCard->cardToNum();
                        }
                    }
                    $fourData = $cardGroups->getBomb(new CardList($lastFourArr));
                    if (!empty($fourData)) {
                        //带的是顺子、单张
                        $wingNum = (count($lastCardList->list) - 4) / 2;

                        $remainCardArr = array_values(array_diff($this->cards, $fourData));
                        $remainCardGroups = new CardGroups(new CardList($remainCardArr));

                        if ($wingNum == 1) {
                            $wingData = $remainCardGroups->getSingleByNum(2);
                        } else {
                            if ($wingNum == 2) {
                                $wingData = $remainCardGroups->getDoubleByNum(2);
                            } else {
                                $wingData = $remainCardGroups->getThreeByNum(2);
                            }
                        }
                        if (count($wingData) != 0) {
                            $action = array_merge($wingData, $fourData);
                        }
                    }
                    break;
            }
        }
        if (is_string($action)
            && $action == 'pass'
            && $lastCardList->listType != CardList::TYPE_KING_BOMB
            && $lastCardList->listType != CardList::TYPE_BOMB
        ) {
            $data = $cardGroups->getBomb();
            if (!empty($data)) {
                $action = $data;
            }
        }
        if (is_string($action) && $action == 'pass') {
            $data = $cardGroups->getKingBomb();
            if (!empty($data)) {
                $action = $data;
            }
        }

        if ($lastIsCompanion and $action != 'pass') {
            $actionCardList = new CardList($action);
            if ($actionCardList->listType == CardList::TYPE_BOMB
                || $actionCardList->listType == CardList::TYPE_KING_BOMB
                || ($actionCardList->listType == CardList::TYPE_SINGLE && $actionCardList->list[0]->type == 5)
            ) {
                $action = 'pass';
            }
        }

        \Tools::writeLog(0, array(
            'userId' => $this->id,
            'userIndex' => $this->index,
            'lastCardList' => $lastCardList,
            'action' => $action,
            'tableId' => $table->id
        ), 'getRobotPlayCards.log');

        return $action;
    }

    /**
     * @param $server \swoole_server
     * @param $table Table
     * @param $toStatus string
     */
    public function changeUserToAI($server, $table, $toStatus)
    {
        $this->status = $this->getVarFromRedis($server->redis, 'status');
        $this->noActionTimes = 0;
        $this->saveVarToRedis($server->redis, ['noActionTimes']);


        $returnData['lastAction'] = $toStatus;
        $returnData['lastIndex'] = $this->index;
        $returnData['status'] = 'notice';
        $table->sendToAllUser($server, $returnData);
        if ($this->status == $toStatus) {
            return;
        }
        $this->status = $toStatus;
        $this->saveVarToRedis($server->redis, array('status'));

        if ($table->actionUserIndex == $this->index) {
            $this->autoAction($server, $table, ['status' => $table->status]);
        }
    }

    /**
     * @param $redis \Redis|\RedisClusterClass
     * @return int
     */
    public function getLock($redis)
    {
        $userDataKey = self::$REDIS_KEY_USER_PREFIX . $this->id;
        return $redis->hSetNx($userDataKey, 'dataLock', serialize(1));
    }

    /**
     * @param $redis \Redis|\RedisClusterClass
     */
    public function delLock($redis)
    {
        $userDataKey = self::$REDIS_KEY_USER_PREFIX . $this->id;
        $redis->hDel($userDataKey, 'dataLock');
    }

    public static function unsetUser($userId, $redis)
    {
        $redis->del(User::$REDIS_KEY_USER_PREFIX . $userId);
    }

    /**
     * 判断这个用户是否需要调用自动操作
     *
     * @return bool
     */
    public function needAutoAction($redis)
    {
        $res = false;
        $isExist = $this->getVarFromRedis($redis, 'status');
        if ($isExist !== false
            && ($this->type != 'user' || $this->status != 'online')
        ) {
            $res = true;
        }
        return $res;
    }

    /**
     * 调用自动操作
     *
     * @param $server
     * @param $table
     */
    public function autoAction($server, $table, $data, $action = null)
    {
        $getLock = $this->getLock($server->redis);
        if (!$getLock) {
            swoole_timer_after(100, function () use ($server, $table, $data, $action) {
                $this->autoAction($server, $table, $data, $action);
            });
            return;
        }

        $op = isset($data['status']) ? $data['status'] : '';
        try {
            switch ($op) {
                case 'jiaoDiZhu' :
                    //todo 要是能根据牌型权重判断就好了~
                    if ($this->type == 'robot') {
                        $action = rand(0, 1) == 0 ? 'pass' : 'jiaoDiZhu';
                    } else {
                        //自动帮用户喊地主时，都是不叫
                        $action = 'pass';
                    }
                    $this->jiaoDiZhu(
                        $server,
                        array(
                            'op' => 'jiaoDiZhu',
                            'action' => $action
                        ),
                        $table
                    );
                    break;
                case 'playCards':
                    $action = ($action === null) ? $this->getRobotPlayCards($server->redis, $table) : $action;
                    $this->playCards(
                        $server,
                        array(
                            'op' => 'playCards',
                            'action' => $action
                        ),
                        $table
                    );
                    break;
            }
            $this->delLock($server->redis);
        } catch (\Exception $e) {
            $this->delLock($server->redis);
            \Tools::writeLog($e->getCode(), $e->getMessage(), 'debugging.log');
        }
    }

    /**
     * @param $pdo \PDO
     *
     * return array
     */
    public function getUserInfo($dbConfig)
    {
        if ($this->type == 'robot') {
            $robotId = explode('_', $this->id);
            $robotId = intval($robotId[4]);
            srand($robotId);
            $userInfo['score'] = rand(100, 3000);
            $userInfo['playNum'] = rand(100, 500);
            $userInfo['runNum'] = rand(2, 10);
            $userInfo['winNum'] = intval($userInfo['playNum'] / 2) - 10;
        } else {
            $dsn = "{$dbConfig['type']}:dbname={$dbConfig['db']};host={$dbConfig['host']};charset=UTF8";
            $pdo = new \PDO($dsn, $dbConfig['user'], $dbConfig['password']);
            $queryInfoSql = <<<sql
SELECT `score`, `playNum`, `runNum`, `winNum`
 FROM `doudizhu_score` WHERE userId=:userId;
sql;
            $sth = $pdo->prepare($queryInfoSql);
            $userId = explode('_', $this->id);
            $userId = $userId[0];
            $sth->execute(['userId' => $userId]);
            $userInfo = $sth->fetch(\PDO::FETCH_ASSOC);
            if (empty($userInfo)) {
                $userInfo = [
                    'score' => 0,
                    'playNum' => 0,
                    'runNum' => 0,
                    'winNum' => 0
                ];
            }
        }

        $userInfo['name'] = $this->name;
        return $userInfo;
    }


    /**
     * @param $redis \Redis|\RedisCluster
     * @param $table Table
     * @return int
     */
    private function getWaitTime($redis, $table)
    {
        $waitTime = USER::$WAIT_TIME_NORMAL_PLAY_CARD;
        if ($table->status == Table::TABLE_STATUS_JIAODIZHU) {
            $waitTime = user::$WAIT_TIME_JIAODIZHU;
        } else {
            $logArr = $table->getLog($redis, ['op' => 'playCards']);
            if (count($logArr) === 0) {
                $waitTime = USER::$WAIT_TIME_FIRST_PLAY_CARD;
            }
        }
        return $waitTime;
    }

    /**
     * 更改用户fd
     * @param $fd
     * @param $redis \Redis
     */
    public function changeFd($fd, $redis)
    {
        $redis->hSet(REDIS_KEY_FD_TO_USER_ID, $fd, $this->id);
        $this->fd = $fd;
        $this->saveVarToRedis($redis, ['fd']);
    }

//todo 这个方法要不要保存？
    static function __set_state($an_array)
    {
        $user = new User($an_array['id']);
        foreach ($an_array as $key => $value) {
            $user->{$key} = $value;
        }
        return $user;
    }
}
