<?php

/**
 * Created by PhpStorm.
 * User: songjingjing
 * Date: 2017/6/12
 */
class BasicController
{
    private $_nowUser;
    private $_table;

    public function __construct(\DouDiZhuData\User $nowUser, \DouDiZhuData\Table $table)
    {
        $this->_nowUser = $nowUser;
        $this->_table = $table;
    }
}