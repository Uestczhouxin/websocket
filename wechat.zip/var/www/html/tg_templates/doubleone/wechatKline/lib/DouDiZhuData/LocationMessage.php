<?php
/**
 * Created by PhpStorm.
 * User: songjingjing
 * Date: 2017/7/17
 */

namespace DouDiZhuData;


class LocationMessage
{
    public $op;
    public $data;
    public $msgId;

    public function __construct($op, $data)
    {
        $this->op = $op;
        $this->data = $data;
        $this->msgId = time() . rand(0, 10000);
    }

    /**
     * @param $serializeString
     * @return LocationMessage
     */
    public static function decodeLocationMessage($serializeString)
    {
        $location = unserialize($serializeString);
        if (!($location instanceof LocationMessage)) {
            $location = new LocationMessage('error', $serializeString);
        }
        return $location;
    }
}