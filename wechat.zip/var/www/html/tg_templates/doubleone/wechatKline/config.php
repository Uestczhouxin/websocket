<?php
/**
 * Created by PhpStorm.
 * User: songjingjing
 * Date: 2017/2/13
 * Time: 20:22
 */
define('ROOT', __DIR__);

$redisConfig = array(
    'password' => '10jqka@123',
    'host' => '10.204.0.28',
    'port' => '31579'
);

$dbConfig = array(
    'host' => '127.0.0.1',
    'user' => 'root',
    'password' => '10jqka',
    'db' => 'doudizhu',
    'type' => 'mysql'
);
define('WEB_SOCKET_PORT', '23333');
//redis中key的前缀
$redisPrefix = file_get_contents(ROOT . '/redisPrefix.txt');
$redisPrefix = 'doudizhu_' . trim($redisPrefix) . '_';
define('REDIS_KEY_PREFIX', $redisPrefix);

//用List来匹配
//define('REDIS_KEY_MATCH_LIST', REDIS_KEY_PREFIX . 'match_list');
define('REDIS_KEY_MATCH_SET', REDIS_KEY_PREFIX . 'match_set');

//机器人自增id
define('REDIS_KEY_ROBOT_ID', REDIS_KEY_PREFIX . 'robot_id');

//机器人id前缀
define('ROBOT_ID_PREFIX', REDIS_KEY_PREFIX . 'robot_id_');

//fd和userid对应关系
define('REDIS_KEY_FD_TO_USER_ID', REDIS_KEY_PREFIX . 'userid_hash');

//在线人数
define('REDIS_ONLINE_NUM_KEY', REDIS_KEY_PREFIX . 'online_num');

define('REDIS_LOCAL_FD', REDIS_KEY_PREFIX . 'local_fd_set');

//日志目录
define("LOG_PATH", '/tmp/doudizhuLog');

//数据目录
define('DATA_PATH', ROOT . '/data');

//叫地主倒计时时长
define('WAIT_TIME_JIAODIZHU', 15);
//地主第一次出牌倒计时时长
define('WAIT_TIME_FIRST_PLAY_CARD', 25);
//普通出牌倒计时时长
define('WAIT_TIME_NORMAL_PLAY_CARD', 15);

//redis数据超时时间 s
define('REDIS_KEY_TIMEOUT', 1200);

//维护配置
$maintenanceConfig = [
    'startTime' => strtotime('2017-06-26 12:00:00'),
    'endTime' => strtotime('2017-06-26 13:00:00'),
    'allowUser' => [
        '133223647'
    ]
];
