#!/bin/sh
#监控用脚本 当swoole的master程序不在的时候重启

path="/var/www/html/thsgames"
now=$(date "+%H%M")

logPath="/tmp/doudizhuLog"

count=`ps -fe |grep -i "doudizhu" | grep -v "grep" | grep "Master" | wc -l`
echo $count
if [ $count = 0 ] ;then
	echo now
	echo "master not found"
    #杀应用
    ps aux | grep -i doudizhu | grep -v grep | awk '{print $2}' | xargs kill -9
    sleep 1
    #调用清缓存脚本
    /usr/local/bin/php $path/cron/clear.php >> $logPath/clear.log 2>&1
    #重启
    /usr/local/bin/php $path/WSServer.php >> $logPath/cron.log 2>&1
    echo 'restart end'
fi
