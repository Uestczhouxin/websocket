<?php
/**
 * Created by PhpStorm.
 * User: songjingjing
 * Date: 2017/5/9
 */
require '/var/www/html/thsgames/cron/process_lock.php';
include_once '/var/www/html/thsgames/config.php';
include_once ROOT . '/included.php';

$redis = Tools::getRedis($redisConfig);
echo date('Y-m-d H:i:s') . "\n";
$it = NULL;
do {
    $arrKeys = $redis->scan($it);

    if ($arrKeys !== FALSE) {
        foreach($arrKeys as $strKey) {
			if ($strKey == REDIS_KEY_ROBOT_ID) {
				continue;
			}
            $prefixArr = explode('_', $strKey);
            if ($prefixArr[0] == 'doudizhu'){
                $idelTime = $redis->object('idletime', $strKey);
                if ($idelTime > 120) {
					$logData = array(
						'key' => $strKey,
					);
					if ($prefixArr[1] == 'user') {
						$logData['user'] = $redis->hGetAll($strKey);
					}
					Tools::writeLog(-1,$logData,'clearData');
                    $redis->del($strKey);
                }
            }
        }
    }
} while ($it > 0);