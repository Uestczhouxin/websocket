<?php
include_once '/var/www/html/songjingjing/thsgames/config.php';
include_once ROOT . '/included.php';

/** 清空redis start*/
$redis = Tools::getRedis($redisConfig);
echo date('Y-m-d H:i:s') . "\n";
$it = NULL;
do {
    $arrKeys = $redis->scan($it);

    if ($arrKeys !== FALSE) {
        foreach($arrKeys as $strKey) {
            $prefixArr = explode('_', $strKey);
            $num = file_get_contents(dirname(__DIR__) . '/redisPrefix.txt');
            $num = trim($num);
            if ($prefixArr[0] == 'doudizhu' && $prefixArr[1] == $num){
                $redis->del($strKey);
            }
        }
    }
} while ($it > 0);
