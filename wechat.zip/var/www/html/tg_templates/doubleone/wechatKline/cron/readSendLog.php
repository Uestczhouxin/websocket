<?php
/**
 * Created by PhpStorm.
 * User: songjingjing
 * Date: 2017/8/14
 */
require __DIR__ . '/process_lock.php';
include_once '/var/www/html/thsgames/config.php';
include_once ROOT . '/included.php';
$lastDate = date('Ymd', strtotime('-1 days'));
$fileName = LOG_PATH . '/sendLog.log' . $lastDate;

$fileHandel = fopen(LOG_PATH . '/sendLog.log' . $lastDate, 'r');

use Tools;
$logArr = [];
while($fileHandel && !feof($fileHandel)) {
    $line = explode("|", fgets($fileHandel));
    $data = json_decode($line[2], true);
    $fd = $data['fd'];
    if ($fd == null || $data['type'] == 'real'){
        continue;
    }
    $data = $data['data'];
    if ($data['lastStatus']  == 'playCards') {
        $lastIndex = $data['lastIndex'];
        if (!isset($logArr[$fd])) {
            $logArr[$fd] = $lastIndex;
        } else if ($logArr[$fd] == $lastIndex) {
            Tools::writeLog(-1, 'fd $fd', 'actionRepeat.log');
        } else {
            $logArr[$fd] = $lastIndex;
        }
    }
}