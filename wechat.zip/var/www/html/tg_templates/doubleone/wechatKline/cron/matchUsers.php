<?php
/**
 * Created by PhpStorm.
 * User: songjingjing
 * Date: 2017/7/17
 */
require __DIR__ . '/process_lock.php';
require dirname(__DIR__) . "/config.php";
require dirname(__DIR__) . "/included.php";

use DouDiZhuData\User;
use DouDiZhuData\LocationMessage;

define('LOCAL_HOST_IP', '127.0.0.1');
$redis = Tools::getRedis($redisConfig);

$client = new WebSocketClient(LOCAL_HOST_IP, WEB_SOCKET_PORT);
if (!$client->connect()) {
    Tools::writeLog(-1, ['msg' => 'connect websocket error'], 'matchUsersCron.log');
    exit;
}
while (1) {

    $userInOneTable = [];
    $matchedNum = 0;
    $leftTime = 50;
    $minUserTime = null;

    do {
        $userId = $redis->blPop(REDIS_KEY_MATCH_LIST, $leftTime);
        if (!isset($userId[1])) {
            if ($matchedNum != 0) {
                $leftTime = 10 - (time() - $minUserTime);
            }
            continue;
        }
        $user = User::getUserFromRedis($userId[1], $redis);

        $userInOneTable[] = $user;
        if (!isset($minUserTime) || $minUserTime > $user->enterTime) {
            $minUserTime = $user->enterTime;
        }
        $leftTime = 10 - (time() - $minUserTime);
        $matchedNum++;
    } while ($leftTime > 0 && $matchedNum < 3);

    for (; $matchedNum < 3; $matchedNum++) {
        $robotUser = User::getRobotUser($redis);
        $userInOneTable[] = $robotUser;
    }

    $locationMessage = new LocationMessage('matchUser', $userInOneTable);

    $sendRes = send($client, $locationMessage);
    if (!$sendRes) {
        foreach ($userInOneTable as $user) {
            if ($user->type == 'user') {
                Tools::writeLog(-1, ['msg' => 'push to list', 'data' => $user->id], 'matchUsersCron.log');
                $redis->lPush(REDIS_KEY_MATCH_LIST, $user->id);
                exit;
            }
        }
    }
}

function send(WebSocketClient &$client, LocationMessage $message)
{
    Tools::writeLog(0, ['op' => 'send', 'id' => $message->msgId], 'matchSend.log');
    $res = $client->send(serialize($message));
    $receive = $client->recv();

    if (!$res || $receive != $message->msgId) {
        $client = new WebSocketClient(LOCAL_HOST_IP, WEB_SOCKET_PORT);
        Tools::writeLog(-1, ['msg' => 'send fail', 'data' => $message], 'matchUsersCron.log');
        echo "reconnect\n";
        if (!$client->connect()) {
            Tools::writeLog(-1, ['msg' => 'connect websocket error2'], 'matchUsersCron.log');
            return false;
        }

        $res = $client->send(serialize($message));
        $receive = $client->recv();

        if (!$res || $receive != $message->msgId) {
            Tools::writeLog(-1, ['msg' => 'send fail2', 'data' => $message], 'matchUsersCron.log');
            return false;
        }
    }
    Tools::writeLog(0, ['op' => 'receive', 'id' => $message->msgId], 'matchSend.log');
    return true;
}