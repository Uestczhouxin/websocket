<?php
/**
 * Created by PhpStorm.
 * User: songjingjing
 * Date: 2017/3/16
 * Time: 20:54
 */
require '/var/www/html/thsgames/config.php';
require ROOT . '/included.php';
require '/var/www/html/thsgames/cron/process_lock.php';

$pdo = Tools::getPdo($dbConfig);

$sql = <<<sql
DELETE FROM `doudizhu_score` WHERE userName='mt_';
sql;
$sth = $pdo->prepare($sql);
$sth->execute();


