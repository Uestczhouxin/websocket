<?php
/**
 *
 *
 * @user: songjingjing
 * @date: 2018/6/28
 */
require_once __DIR__ . '/ClassLoader.php';
require_once '/var/www/MobilePHPLib/autoload.php';

use Conf\Redis;
use Helper\RedisHelper;

       $redisHelper = RedisHelper::getRedisHelperInstance();

for ($i = 0; $i < 300; $i++) {
    $score = "0." . rand(0, 100);
    $redisHelper->zAdd('mobile_web_kline_wechat_rank_soredSet', $score, $i);
}
