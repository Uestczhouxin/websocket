<?php
/**
 * Created by PhpStorm.
 * User: songjingjing
 * Date: 2017/12/2
 */
use Helper\Log;
use MobilePHPLib\Cron\ProcessLocker;

require_once '/var/www/MobilePHPLib/autoload.php';
require __DIR__ . '/ClassLoader.php';
$lock = new ProcessLocker();
$cronName = str_replace('/', '\\', 'Cron/' . $argv[1]);
$lock->doLock('limitUp', true);


ini_set("memory_limit", "512M");
if (is_callable([$cronName, 'cronHandle'])) {
    try {
        /**
         * @var $class \Cron\BaseCron
         */
        $class = new $cronName;
        $class->cronHandle($argv);
    } catch (\Exception $e) {
        Log::setErrorLog($cronName . ' 定时脚本中断' . '|' . $e->getMessage(), Log::ERROR_LEVEL_ERROR);
    }
} else {
    Log::setErrorLog($cronName . ' 没有定时执行函数');
}
