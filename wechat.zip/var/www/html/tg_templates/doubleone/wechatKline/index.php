<?php
/**
 *
 *
 * @user: songjingjing
 * @date: 2018/6/28
 */
require_once '/var/www/MobilePHPLib/autoload.php';
require_once __DIR__ . '/ClassLoader.php';

$op = $_REQUEST['op'];
try {
    switch ($op) {
        case 'getUserData':
            $controller = new Controller\IndexController();
            $controller->getUserInfo();
            break;
        case 'getRank':
            $controller = new Controller\IndexController();
            $controller->getRank();
            break;
        case 'getUserId':
            $controller = new Controller\IndexController();
            $controller->getUserId();
            break;
        case 'sendUserData':
            $controller = new Controller\IndexController();
            $controller->updateUserBaseData();
            break;
        case 'sendAlphaHuaResult':
            $controller = new Controller\IndexController();
            $controller->sendAlphaHuaResult();
            break;
        case 'getFriendRank':
            $controller = new Controller\IndexController();
            $controller->getFriendRank();
            $message = new \Helper\Message(0, $data);
            $message->doReturn();
            break;
        default:
            throw new \Helper\InterfaceException('op参数错误', 404);
            break;
    }
} catch (\Exception $e) {
    $statusCode = $e instanceof \Helper\InterfaceException ? $e->getCode() : 500;
    $message = new \Helper\Message($statusCode);
    \Helper\Log::setErrorLog(
        'interface|message:'
        . $e->getMessage() . '|code:' . $e->getCode() . '|' . $e->getTraceAsString()
    );
    $message->doReturn();
}
